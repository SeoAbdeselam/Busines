import { createContext, useContext, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./AuthContext";

interface Wedding {
  id: string;
  name: string;
  wedding_date: string | null;
  location: string | null;
  cover_image_url: string | null;
  primary_color: string;
  secondary_color: string;
  wedding_code: string;
  created_by: string;
}

interface WeddingMembership {
  id: string;
  wedding_id: string;
  role: "couple" | "guest";
  wedding: Wedding;
}

interface WeddingContextType {
  activeWedding: Wedding | null;
  memberships: WeddingMembership[];
  userRole: "couple" | "guest" | null;
  loading: boolean;
  setActiveWedding: (wedding: Wedding | null) => void;
  refreshWeddings: () => Promise<void>;
}

const WeddingContext = createContext<WeddingContextType>({
  activeWedding: null,
  memberships: [],
  userRole: null,
  loading: true,
  setActiveWedding: () => {},
  refreshWeddings: async () => {},
});

export const useWedding = () => useContext(WeddingContext);

export const WeddingProvider = ({ children }: { children: React.ReactNode }) => {
  const { user } = useAuth();
  const [activeWedding, setActiveWedding] = useState<Wedding | null>(null);
  const [memberships, setMemberships] = useState<WeddingMembership[]>([]);
  const [userRole, setUserRole] = useState<"couple" | "guest" | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchWeddings = async () => {
    if (!user) {
      setMemberships([]);
      setActiveWedding(null);
      setUserRole(null);
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from("wedding_memberships")
        .select(`
          id,
          wedding_id,
          role,
          wedding:weddings(*)
        `)
        .eq("user_id", user.id);

      if (error) throw error;

      const formattedMemberships = (data || []).map((m: any) => ({
        id: m.id,
        wedding_id: m.wedding_id,
        role: m.role,
        wedding: m.wedding,
      }));

      setMemberships(formattedMemberships);

      // Auto-select first wedding if none selected
      if (!activeWedding && formattedMemberships.length > 0) {
        const firstMembership = formattedMemberships[0];
        setActiveWedding(firstMembership.wedding);
        setUserRole(firstMembership.role);
      }
    } catch (error) {
      console.error("Error fetching weddings:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWeddings();
  }, [user]);

  // Update role when active wedding changes
  useEffect(() => {
    if (activeWedding) {
      const membership = memberships.find(
        (m) => m.wedding_id === activeWedding.id
      );
      setUserRole(membership?.role || null);
    } else {
      setUserRole(null);
    }
  }, [activeWedding, memberships]);

  const handleSetActiveWedding = (wedding: Wedding | null) => {
    setActiveWedding(wedding);
  };

  return (
    <WeddingContext.Provider
      value={{
        activeWedding,
        memberships,
        userRole,
        loading,
        setActiveWedding: handleSetActiveWedding,
        refreshWeddings: fetchWeddings,
      }}
    >
      {children}
    </WeddingContext.Provider>
  );
};
