import { createContext, useContext, useEffect, useState } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

interface Professional {
  id: string;
  user_id: string;
  business_name: string;
  slug: string;
  primary_category: string;
  city: string | null;
  description: string | null;
  is_active: boolean;
  is_verified: boolean;
  is_profile_complete: boolean;
  views_count: number;
  contacts_count: number;
  total_contracts: number;
  total_reviews: number;
  average_rating: number;
}

interface Subscription {
  id: string;
  plan: "free" | "premium";
  status: "active" | "expired" | "cancelled";
  expires_at: string | null;
}

interface ProfessionalAuthContextType {
  user: User | null;
  session: Session | null;
  professional: Professional | null;
  subscription: Subscription | null;
  loading: boolean;
  isPremium: boolean;
  signOut: () => Promise<void>;
  refreshProfessional: () => Promise<void>;
}

const ProfessionalAuthContext = createContext<ProfessionalAuthContextType>({
  user: null,
  session: null,
  professional: null,
  subscription: null,
  loading: true,
  isPremium: false,
  signOut: async () => {},
  refreshProfessional: async () => {},
});

export const useProfessionalAuth = () => useContext(ProfessionalAuthContext);

export const ProfessionalAuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [professional, setProfessional] = useState<Professional | null>(null);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfessionalData = async (userId: string) => {
    try {
      // Fetch professional profile
      const { data: profData, error: profError } = await supabase
        .from("professionals")
        .select("*")
        .eq("user_id", userId)
        .maybeSingle();

      if (profError) throw profError;
      
      if (profData) {
        setProfessional(profData as Professional);

        // Fetch subscription
        const { data: subData } = await supabase
          .from("professional_subscriptions")
          .select("*")
          .eq("professional_id", profData.id)
          .eq("status", "active")
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();

        if (subData) {
          setSubscription(subData as Subscription);
        }
      }
    } catch (error) {
      console.error("Error fetching professional data:", error);
    }
  };

  const refreshProfessional = async () => {
    if (user) {
      await fetchProfessionalData(user.id);
    }
  };

  useEffect(() => {
    const { data: { subscription: authSubscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          // Use setTimeout to avoid Supabase auth deadlock
          setTimeout(() => {
            fetchProfessionalData(session.user.id);
          }, 0);
        } else {
          setProfessional(null);
          setSubscription(null);
        }
        setLoading(false);
      }
    );

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchProfessionalData(session.user.id);
      }
      setLoading(false);
    });

    return () => authSubscription.unsubscribe();
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
    setProfessional(null);
    setSubscription(null);
  };

  const isPremium = subscription?.plan === "premium" && 
    subscription?.status === "active" &&
    (!subscription?.expires_at || new Date(subscription.expires_at) > new Date());

  return (
    <ProfessionalAuthContext.Provider 
      value={{ 
        user, 
        session, 
        professional, 
        subscription, 
        loading, 
        isPremium,
        signOut,
        refreshProfessional 
      }}
    >
      {children}
    </ProfessionalAuthContext.Provider>
  );
};
