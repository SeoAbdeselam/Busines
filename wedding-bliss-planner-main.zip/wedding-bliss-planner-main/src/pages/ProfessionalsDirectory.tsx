import { useState, useEffect } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  Heart,
  Filter
} from "lucide-react";
import { PROFESSIONAL_CATEGORIES } from "@/lib/professionalCategories";
import { ProfessionalCard } from "@/components/directory/ProfessionalCard";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Professional {
  id: string;
  business_name: string;
  slug: string;
  description: string | null;
  primary_category: string;
  city: string | null;
  average_rating: number;
  total_reviews: number;
  is_verified: boolean;
  is_premium: boolean;
  logo_url: string | null;
  cover_image_url: string | null;
}

export default function ProfessionalsDirectory() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get("category") || "all");
  const [selectedCity, setSelectedCity] = useState(searchParams.get("city") || "all");
  const [cities, setCities] = useState<string[]>([]);

  useEffect(() => {
    fetchProfessionals();
    fetchCities();
  }, [selectedCategory, selectedCity]);

  const fetchProfessionals = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from("professionals")
        .select("*")
        .eq("is_active", true)
        .eq("is_profile_complete", true) // Solo perfiles completos
        // Premium professionals first, then by rating
        .order("is_premium", { ascending: false })
        .order("is_verified", { ascending: false })
        .order("average_rating", { ascending: false });

      if (selectedCategory !== "all") {
        query = query.eq("primary_category", selectedCategory as any);
      }

      if (selectedCity !== "all") {
        query = query.eq("city", selectedCity);
      }

      const { data, error } = await query;
      if (error) throw error;

      let filtered = data || [];
      if (searchTerm) {
        filtered = filtered.filter(p => 
          p.business_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          p.description?.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }

      setProfessionals(filtered);
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCities = async () => {
    const { data } = await supabase
      .from("professionals")
      .select("city")
      .eq("is_active", true)
      .not("city", "is", null);

    if (data) {
      const uniqueCities = [...new Set(data.map(d => d.city).filter(Boolean))] as string[];
      setCities(uniqueCities.sort());
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchProfessionals();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Heart className="w-6 h-6 text-primary" fill="currentColor" />
            <span className="font-serif font-semibold text-lg">Loba Ball</span>
          </Link>
          <Link to="/pro/auth">
            <Button variant="outline" size="sm">
              Soy profesional
            </Button>
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-gradient-to-r from-primary/10 to-blush/20 py-12 md:py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-4xl font-serif font-semibold mb-4">
            Encuentra a los mejores profesionales
          </h1>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Fotógrafos, floristas, catering y más. Todos verificados y con reseñas reales.
          </p>

          {/* Search */}
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Buscar por nombre..."
                  className="pl-10"
                />
              </div>
              <Button type="submit">Buscar</Button>
            </div>
          </form>
        </div>
      </section>

      {/* Categories */}
      <section className="py-8 border-b overflow-x-auto">
        <div className="container mx-auto px-4">
          <div className="flex gap-2 min-w-max">
            <Button
              variant={selectedCategory === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("all")}
            >
              Todos
            </Button>
            {Object.entries(PROFESSIONAL_CATEGORIES).slice(0, 10).map(([key, cat]) => {
              const Icon = cat.icon;
              return (
                <Button
                  key={key}
                  variant={selectedCategory === key ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(key)}
                >
                  <Icon className="w-4 h-4 mr-2" />
                  {cat.label}
                </Button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Filters & Results */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
            <p className="text-muted-foreground">
              {professionals.length} profesionales encontrados
            </p>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <Select value={selectedCity} onValueChange={setSelectedCity}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Todas las ciudades" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las ciudades</SelectItem>
                  {cities.map(city => (
                    <SelectItem key={city} value={city}>{city}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {loading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="rounded-lg border bg-card animate-pulse">
                  <div className="aspect-[4/3] bg-secondary" />
                  <div className="p-4">
                    <div className="h-6 bg-secondary rounded mb-2" />
                    <div className="h-4 bg-secondary rounded w-2/3" />
                  </div>
                </div>
              ))}
            </div>
          ) : professionals.length === 0 ? (
            <div className="text-center py-16">
              <p className="text-muted-foreground mb-4">
                No hay profesionales que coincidan con tu búsqueda
              </p>
              <Button variant="outline" onClick={() => {
                setSelectedCategory("all");
                setSelectedCity("all");
                setSearchTerm("");
              }}>
                Limpiar filtros
              </Button>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {professionals.map((prof) => (
                <ProfessionalCard key={prof.id} professional={prof} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA for Professionals */}
      <section className="py-16 bg-primary/5">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-serif font-semibold mb-4">
            ¿Eres profesional del sector bodas?
          </h2>
          <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
            Únete gratis y empieza a recibir contactos de parejas interesadas en tus servicios.
          </p>
          <Link to="/pro/auth">
            <Button size="lg">
              Registrar mi negocio
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
