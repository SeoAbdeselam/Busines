import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Heart, Briefcase, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const CATEGORIES = [
  { value: "photography", label: "Fotografía" },
  { value: "video", label: "Vídeo" },
  { value: "florist", label: "Floristería" },
  { value: "catering", label: "Catering" },
  { value: "dj_music", label: "DJ / Música" },
  { value: "dresses", label: "Vestidos" },
  { value: "transport", label: "Transporte" },
  { value: "pastry", label: "Pastelería" },
  { value: "jewelry", label: "Joyería" },
  { value: "venues", label: "Salones de boda" },
  { value: "wedding_planner", label: "Wedding Planner" },
  { value: "makeup_hair", label: "Maquillaje y Peluquería" },
  { value: "decoration", label: "Decoración" },
  { value: "invitations", label: "Invitaciones" },
  { value: "other", label: "Otros" },
];

export default function ProfessionalAuth() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("login");

  // Login form
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");

  // Register form
  const [registerData, setRegisterData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    businessName: "",
    category: "",
    city: "",
  });

  useEffect(() => {
    // Check if already logged in as professional
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        const { data: professional } = await supabase
          .from("professionals")
          .select("id")
          .eq("user_id", session.user.id)
          .maybeSingle();
        
        if (professional) {
          navigate("/pro/dashboard");
        }
      }
    };
    checkSession();
  }, [navigate]);

  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "")
      + "-" + Math.random().toString(36).substring(2, 8);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: loginEmail,
        password: loginPassword,
      });

      if (error) throw error;

      // Check if user is a professional
      const { data: professional, error: profError } = await supabase
        .from("professionals")
        .select("id")
        .eq("user_id", data.user.id)
        .maybeSingle();

      if (profError) throw profError;

      if (!professional) {
        await supabase.auth.signOut();
        toast({
          title: "Cuenta no encontrada",
          description: "Este email no está registrado como profesional. ¿Quieres registrarte?",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "¡Bienvenido!",
        description: "Has iniciado sesión correctamente",
      });
      navigate("/pro/dashboard");
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Error al iniciar sesión",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    if (registerData.password !== registerData.confirmPassword) {
      toast({
        title: "Error",
        description: "Las contraseñas no coinciden",
        variant: "destructive",
      });
      setLoading(false);
      return;
    }

    if (!registerData.category) {
      toast({
        title: "Error",
        description: "Selecciona una categoría principal",
        variant: "destructive",
      });
      setLoading(false);
      return;
    }

    try {
      // Register user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: registerData.email,
        password: registerData.password,
        options: {
          emailRedirectTo: window.location.origin + "/pro/dashboard",
          data: {
            is_professional: true,
          },
        },
      });

      if (authError) throw authError;

      if (authData.user) {
        // Create professional profile
        const slug = generateSlug(registerData.businessName);
        
        const { error: profError } = await supabase
          .from("professionals")
          .insert({
            user_id: authData.user.id,
            business_name: registerData.businessName,
            slug,
            primary_category: registerData.category as any,
            city: registerData.city,
            email: registerData.email,
          });

        if (profError) throw profError;

        // Create free subscription
        const { data: profData } = await supabase
          .from("professionals")
          .select("id")
          .eq("user_id", authData.user.id)
          .single();

        if (profData) {
          await supabase
            .from("professional_subscriptions")
            .insert({
              professional_id: profData.id,
              plan: "free",
              status: "active",
            });
        }

        toast({
          title: "¡Registro exitoso!",
          description: "Revisa tu email para confirmar tu cuenta",
        });
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Error al registrarse",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-secondary via-background to-blush/20 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8">
          <ArrowLeft className="w-4 h-4" />
          Volver al inicio
        </Link>

        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Heart className="w-8 h-8 text-primary" fill="currentColor" />
            <span className="font-serif text-2xl font-semibold">Loba Ball</span>
          </div>
          <div className="flex items-center justify-center gap-2 text-muted-foreground">
            <Briefcase className="w-5 h-5" />
            <span>Portal de Profesionales</span>
          </div>
        </div>

        <Card>
          <CardHeader className="text-center">
            <CardTitle>Acceso Profesionales</CardTitle>
            <CardDescription>
              Gestiona tu perfil y conecta con parejas
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="login">Iniciar Sesión</TabsTrigger>
                <TabsTrigger value="register">Registrarse</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="login-email">Email</Label>
                    <Input
                      id="login-email"
                      type="email"
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      placeholder="tu@email.com"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="login-password">Contraseña</Label>
                    <Input
                      id="login-password"
                      type="password"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="••••••••"
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? "Cargando..." : "Iniciar Sesión"}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="register">
                <form onSubmit={handleRegister} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="business-name">Nombre del negocio *</Label>
                    <Input
                      id="business-name"
                      value={registerData.businessName}
                      onChange={(e) => setRegisterData({ ...registerData, businessName: e.target.value })}
                      placeholder="Tu empresa o marca"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="category">Categoría principal *</Label>
                    <Select
                      value={registerData.category}
                      onValueChange={(value) => setRegisterData({ ...registerData, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecciona una categoría" />
                      </SelectTrigger>
                      <SelectContent>
                        {CATEGORIES.map((cat) => (
                          <SelectItem key={cat.value} value={cat.value}>
                            {cat.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="city">Ciudad *</Label>
                    <Input
                      id="city"
                      value={registerData.city}
                      onChange={(e) => setRegisterData({ ...registerData, city: e.target.value })}
                      placeholder="Tu ciudad principal"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="register-email">Email *</Label>
                    <Input
                      id="register-email"
                      type="email"
                      value={registerData.email}
                      onChange={(e) => setRegisterData({ ...registerData, email: e.target.value })}
                      placeholder="tu@email.com"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="register-password">Contraseña *</Label>
                    <Input
                      id="register-password"
                      type="password"
                      value={registerData.password}
                      onChange={(e) => setRegisterData({ ...registerData, password: e.target.value })}
                      placeholder="Mínimo 6 caracteres"
                      minLength={6}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirmar contraseña *</Label>
                    <Input
                      id="confirm-password"
                      type="password"
                      value={registerData.confirmPassword}
                      onChange={(e) => setRegisterData({ ...registerData, confirmPassword: e.target.value })}
                      placeholder="Repite tu contraseña"
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? "Cargando..." : "Crear cuenta gratuita"}
                  </Button>

                  <p className="text-xs text-center text-muted-foreground">
                    Al registrarte aceptas nuestros términos de servicio y política de privacidad
                  </p>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
