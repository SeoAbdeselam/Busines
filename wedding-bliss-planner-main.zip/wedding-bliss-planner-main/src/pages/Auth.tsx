import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Heart, Mail, Lock, User, ArrowLeft, Phone } from "lucide-react";

type AuthMode = "login" | "register" | "guest-access";

interface ConsentState {
  termsOfService: boolean;
  privacyPolicy: boolean;
  marketingCommunications: boolean;
  providerOffers: boolean;
}

export default function Auth() {
  const [mode, setMode] = useState<AuthMode>("login");
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [weddingCode, setWeddingCode] = useState("");
  const [consents, setConsents] = useState<ConsentState>({
    termsOfService: false,
    privacyPolicy: false,
    marketingCommunications: false,
    providerOffers: false,
  });
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleConsentChange = (key: keyof ConsentState) => {
    setConsents((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const saveConsents = async (userId: string) => {
    const consentTypes = [
      { consent_type: "terms_of_service" as const, granted: consents.termsOfService },
      { consent_type: "privacy_policy" as const, granted: consents.privacyPolicy },
      { consent_type: "marketing_communications" as const, granted: consents.marketingCommunications },
      { consent_type: "provider_offers" as const, granted: consents.providerOffers },
      { consent_type: "event_notifications" as const, granted: true },
    ];

    for (const consent of consentTypes) {
      await supabase.from("consents").insert({
        user_id: userId,
        consent_type: consent.consent_type,
        granted: consent.granted,
        granted_at: consent.granted ? new Date().toISOString() : null,
        origin: "registration",
      });
    }
  };

  const updateProfilePhone = async (userId: string) => {
    await supabase.from("profiles").update({ phone }).eq("id", userId);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      toast({
        title: "Error al iniciar sesión",
        description: error.message,
        variant: "destructive",
      });
    } else {
      navigate("/dashboard");
    }

    setLoading(false);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required consents
    if (!consents.termsOfService || !consents.privacyPolicy) {
      toast({
        title: "Consentimiento requerido",
        description: "Debes aceptar los términos de servicio y la política de privacidad.",
        variant: "destructive",
      });
      return;
    }

    // Validate phone
    if (!phone.trim()) {
      toast({
        title: "Teléfono requerido",
        description: "Por favor, introduce tu número de teléfono.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: window.location.origin,
        data: {
          full_name: fullName,
          phone: phone,
        },
      },
    });

    if (error) {
      toast({
        title: "Error al registrarse",
        description: error.message,
        variant: "destructive",
      });
    } else if (data.user) {
      // Save phone to profile and consents
      await updateProfilePhone(data.user.id);
      await saveConsents(data.user.id);
      
      toast({
        title: "¡Cuenta creada!",
        description: "Bienvenido/a a Loba Ball. Ahora puedes crear tu boda.",
      });
      navigate("/dashboard");
    }

    setLoading(false);
  };

  const handleGuestAccess = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // First check if wedding code exists
    const { data: weddingId, error: codeError } = await supabase.rpc(
      "get_wedding_by_code",
      { p_code: weddingCode.toUpperCase() }
    );

    if (codeError || !weddingId) {
      toast({
        title: "Código inválido",
        description: "No encontramos ninguna boda con ese código.",
        variant: "destructive",
      });
      setLoading(false);
      return;
    }

    // Try to login or register the guest
    const { data: signInData, error: signInError } =
      await supabase.auth.signInWithPassword({
        email,
        password,
      });

    if (signInError) {
      // User doesn't exist, create account
      const { data: signUpData, error: signUpError } =
        await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: {
              full_name: fullName || email.split("@")[0],
              phone: phone,
            },
          },
        });

      if (signUpError) {
        toast({
          title: "Error",
          description: signUpError.message,
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      // Add guest membership and update profile
      if (signUpData.user) {
        await updateProfilePhone(signUpData.user.id);
        
        const { error: membershipError } = await supabase
          .from("wedding_memberships")
          .insert({
            user_id: signUpData.user.id,
            wedding_id: weddingId,
            role: "guest",
          });

        if (membershipError) {
          console.error("Error adding membership:", membershipError);
        }
      }
    } else {
      // User exists, check if already member
      const { data: existingMembership } = await supabase
        .from("wedding_memberships")
        .select("id")
        .eq("user_id", signInData.user.id)
        .eq("wedding_id", weddingId)
        .maybeSingle();

      if (!existingMembership) {
        // Add membership
        await supabase.from("wedding_memberships").insert({
          user_id: signInData.user.id,
          wedding_id: weddingId,
          role: "guest",
        });
      }
    }

    toast({
      title: "¡Bienvenido/a!",
      description: "Has accedido a la boda correctamente.",
    });
    navigate("/guest");
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
            <Heart className="w-8 h-8 text-primary" fill="currentColor" />
          </div>
          <h1 className="text-3xl font-serif font-bold text-foreground">
            Loba Ball
          </h1>
          <p className="text-muted-foreground mt-2">
            Tu organizador de bodas inteligente
          </p>
        </div>

        {/* Auth Card */}
        <div className="bg-card rounded-2xl shadow-elevated p-8 border border-border/50">
          {mode === "login" && (
            <form onSubmit={handleLogin} className="space-y-4">
              <h2 className="text-xl font-semibold text-center mb-6">
                Iniciar Sesión
              </h2>

              <div className="space-y-2">
                <label className="text-sm font-medium">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="email"
                    placeholder="tu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Contraseña</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full"
                variant="champagne"
                size="lg"
                disabled={loading}
              >
                {loading ? "Entrando..." : "Entrar"}
              </Button>

              <div className="text-center space-y-2 pt-4">
                <button
                  type="button"
                  onClick={() => setMode("register")}
                  className="text-sm text-primary hover:underline"
                >
                  ¿No tienes cuenta? Regístrate
                </button>
                <br />
                <button
                  type="button"
                  onClick={() => setMode("guest-access")}
                  className="text-sm text-muted-foreground hover:text-foreground"
                >
                  Soy invitado/a a una boda
                </button>
              </div>
            </form>
          )}

          {mode === "register" && (
            <form onSubmit={handleRegister} className="space-y-4">
              <button
                type="button"
                onClick={() => setMode("login")}
                className="flex items-center text-sm text-muted-foreground hover:text-foreground mb-4"
              >
                <ArrowLeft className="w-4 h-4 mr-1" /> Volver
              </button>

              <h2 className="text-xl font-semibold text-center mb-6">
                Crear Cuenta de Novios
              </h2>

              <div className="space-y-2">
                <label className="text-sm font-medium">Nombres de los novios</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="María y Carlos"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="pl-10"
                    required
                    maxLength={100}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="email"
                    placeholder="tu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    required
                    maxLength={255}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Teléfono</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="tel"
                    placeholder="+34 612 345 678"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="pl-10"
                    required
                    maxLength={20}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Contraseña</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="password"
                    placeholder="Mínimo 6 caracteres"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10"
                    minLength={6}
                    required
                  />
                </div>
              </div>

              {/* RGPD Consents */}
              <div className="space-y-3 pt-4 border-t border-border">
                <p className="text-xs text-muted-foreground font-medium">
                  Consentimientos legales (RGPD)
                </p>
                
                <div className="flex items-start gap-3">
                  <Checkbox
                    id="terms"
                    checked={consents.termsOfService}
                    onCheckedChange={() => handleConsentChange("termsOfService")}
                  />
                  <label htmlFor="terms" className="text-sm leading-tight cursor-pointer">
                    Acepto los{" "}
                    <a href="/terms" className="text-primary hover:underline">
                      términos de servicio
                    </a>{" "}
                    <span className="text-destructive">*</span>
                  </label>
                </div>

                <div className="flex items-start gap-3">
                  <Checkbox
                    id="privacy"
                    checked={consents.privacyPolicy}
                    onCheckedChange={() => handleConsentChange("privacyPolicy")}
                  />
                  <label htmlFor="privacy" className="text-sm leading-tight cursor-pointer">
                    Acepto la{" "}
                    <a href="/privacy" className="text-primary hover:underline">
                      política de privacidad
                    </a>{" "}
                    <span className="text-destructive">*</span>
                  </label>
                </div>

                <div className="flex items-start gap-3">
                  <Checkbox
                    id="marketing"
                    checked={consents.marketingCommunications}
                    onCheckedChange={() => handleConsentChange("marketingCommunications")}
                  />
                  <label htmlFor="marketing" className="text-sm leading-tight cursor-pointer">
                    Deseo recibir comunicaciones sobre la organización de mi boda
                  </label>
                </div>

                <div className="flex items-start gap-3">
                  <Checkbox
                    id="providers"
                    checked={consents.providerOffers}
                    onCheckedChange={() => handleConsentChange("providerOffers")}
                  />
                  <label htmlFor="providers" className="text-sm leading-tight cursor-pointer">
                    Quiero recibir ofertas de proveedores seleccionados
                  </label>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full"
                variant="champagne"
                size="lg"
                disabled={loading}
              >
                {loading ? "Creando cuenta..." : "Crear Cuenta"}
              </Button>
            </form>
          )}

          {mode === "guest-access" && (
            <form onSubmit={handleGuestAccess} className="space-y-4">
              <button
                type="button"
                onClick={() => setMode("login")}
                className="flex items-center text-sm text-muted-foreground hover:text-foreground mb-4"
              >
                <ArrowLeft className="w-4 h-4 mr-1" /> Volver
              </button>

              <h2 className="text-xl font-semibold text-center mb-6">
                Acceso para Invitados
              </h2>

              <div className="space-y-2">
                <label className="text-sm font-medium">Código de la boda</label>
                <Input
                  type="text"
                  placeholder="ABCD1234"
                  value={weddingCode}
                  onChange={(e) => setWeddingCode(e.target.value.toUpperCase())}
                  className="text-center text-lg tracking-widest font-mono"
                  maxLength={8}
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Tu nombre</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Tu nombre completo"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="pl-10"
                    required
                    maxLength={100}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Tu email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="email"
                    placeholder="tu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    required
                    maxLength={255}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Tu teléfono</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="tel"
                    placeholder="+34 612 345 678"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="pl-10"
                    required
                    maxLength={20}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Contraseña (crea una nueva o usa la existente)
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10"
                    minLength={6}
                    required
                  />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full"
                variant="champagne"
                size="lg"
                disabled={loading}
              >
                {loading ? "Accediendo..." : "Acceder a la Boda"}
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}