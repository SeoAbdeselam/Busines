import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useWedding } from "@/contexts/WeddingContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { 
  Star, 
  MapPin, 
  Globe, 
  Instagram, 
  Facebook, 
  Youtube,
  MessageSquare,
  ArrowLeft,
  Heart,
  CheckCircle2,
  Image as ImageIcon,
  Handshake,
  Loader2
} from "lucide-react";
import { getCategoryLabel, getCategoryIcon } from "@/lib/professionalCategories";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

interface Professional {
  id: string;
  business_name: string;
  slug: string;
  description: string | null;
  story: string | null;
  primary_category: string;
  city: string | null;
  province: string | null;
  website: string | null;
  instagram: string | null;
  facebook: string | null;
  youtube: string | null;
  tiktok: string | null;
  logo_url: string | null;
  cover_image_url: string | null;
  average_rating: number;
  total_reviews: number;
  is_verified: boolean;
}

interface GalleryItem {
  id: string;
  type: string;
  url: string;
  title: string | null;
}

interface Review {
  id: string;
  rating: number;
  title: string | null;
  content: string | null;
  response: string | null;
  created_at: string;
}

export default function ProfessionalProfile() {
  const { slug } = useParams<{ slug: string }>();
  const { user } = useAuth();
  const { activeWedding } = useWedding();
  const { toast } = useToast();
  
  const [professional, setProfessional] = useState<Professional | null>(null);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [showContactModal, setShowContactModal] = useState(false);
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [existingContract, setExistingContract] = useState<{ id: string; status: string } | null>(null);
  const [contracting, setContracting] = useState(false);

  useEffect(() => {
    if (slug) {
      fetchProfessional();
    }
  }, [slug]);

  useEffect(() => {
    if (professional && user && activeWedding) {
      checkExistingContract();
    }
  }, [professional, user, activeWedding]);

  const checkExistingContract = async () => {
    if (!professional || !activeWedding) return;
    
    const { data } = await supabase
      .from("professional_contracts")
      .select("id, status")
      .eq("professional_id", professional.id)
      .eq("wedding_id", activeWedding.id)
      .maybeSingle();
    
    setExistingContract(data);
  };

  const fetchProfessional = async () => {
    try {
      // Fetch professional
      const { data: profData, error: profError } = await supabase
        .from("professionals")
        .select("*")
        .eq("slug", slug)
        .eq("is_active", true)
        .single();

      if (profError) throw profError;
      setProfessional(profData as Professional);

      // Increment view count
      await supabase
        .from("professionals")
        .update({ views_count: (profData.views_count || 0) + 1 })
        .eq("id", profData.id);

      // Fetch gallery
      const { data: galleryData } = await supabase
        .from("professional_gallery")
        .select("*")
        .eq("professional_id", profData.id)
        .order("sort_order", { ascending: true })
        .limit(10);

      setGallery(galleryData || []);

      // Fetch reviews
      const { data: reviewsData } = await supabase
        .from("professional_reviews")
        .select("*")
        .eq("professional_id", profData.id)
        .eq("is_published", true)
        .order("created_at", { ascending: false })
        .limit(5);

      setReviews(reviewsData || []);
    } catch (error: any) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleContact = async () => {
    if (!user || !activeWedding || !professional || !message.trim()) {
      toast({
        title: "Error",
        description: "Debes estar logueado y tener una boda activa para contactar",
        variant: "destructive",
      });
      return;
    }

    setSending(true);
    try {
      // Check if conversation exists
      const { data: existing } = await supabase
        .from("professional_conversations")
        .select("id")
        .eq("professional_id", professional.id)
        .eq("wedding_id", activeWedding.id)
        .maybeSingle();

      let conversationId: string;

      if (existing) {
        conversationId = existing.id;
      } else {
        // Create conversation
        const { data: newConv, error: convError } = await supabase
          .from("professional_conversations")
          .insert({
            professional_id: professional.id,
            wedding_id: activeWedding.id,
            client_user_id: user.id,
          })
          .select("id")
          .single();

        if (convError) throw convError;
        conversationId = newConv.id;

        // Update professional contact count
        await supabase
          .from("professionals")
          .update({ contacts_count: (professional as any).contacts_count + 1 })
          .eq("id", professional.id);
      }

      // Send message
      const { error: msgError } = await supabase
        .from("professional_messages")
        .insert({
          conversation_id: conversationId,
          sender_type: "client",
          sender_id: user.id,
          content: message.trim(),
        });

      if (msgError) throw msgError;

      toast({
        title: "Mensaje enviado",
        description: "El profesional recibirá tu mensaje y te responderá pronto",
      });
      setShowContactModal(false);
      setMessage("");
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSending(false);
    }
  };

  const handleContract = async () => {
    if (!user || !activeWedding || !professional) {
      toast({
        title: "Error",
        description: "Debes estar logueado y tener una boda activa para contratar",
        variant: "destructive",
      });
      return;
    }

    setContracting(true);
    try {
      if (existingContract) {
        // Update existing contract to contracted
        const { error } = await supabase
          .from("professional_contracts")
          .update({ status: "contracted" })
          .eq("id", existingContract.id);
        
        if (error) throw error;
      } else {
        // Create new contract with contracted status
        const { error } = await supabase
          .from("professional_contracts")
          .insert({
            professional_id: professional.id,
            wedding_id: activeWedding.id,
            client_user_id: user.id,
            status: "contracted",
          });

        if (error) throw error;
      }

      toast({
        title: "¡Proveedor contratado!",
        description: "Se ha creado automáticamente una tarea y partida de presupuesto",
      });
      checkExistingContract();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setContracting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!professional) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h1 className="text-2xl font-semibold mb-4">Profesional no encontrado</h1>
        <Link to="/profesionales">
          <Button>Ver todos los profesionales</Button>
        </Link>
      </div>
    );
  }

  const CategoryIcon = getCategoryIcon(professional.primary_category);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/profesionales" className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4" />
            Volver
          </Link>
          <Link to="/" className="flex items-center gap-2">
            <Heart className="w-6 h-6 text-primary" fill="currentColor" />
            <span className="font-serif font-semibold">Loba Ball</span>
          </Link>
          <div className="w-20" />
        </div>
      </header>

      {/* Cover */}
      <div className="h-48 md:h-64 bg-gradient-to-r from-primary/20 to-blush/30 relative">
        {professional.cover_image_url && (
          <img 
            src={professional.cover_image_url} 
            alt="" 
            className="w-full h-full object-cover"
          />
        )}
      </div>

      <div className="container mx-auto px-4 -mt-16 relative z-10">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Profile Card */}
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-6">
                  {/* Avatar */}
                  <div className="w-24 h-24 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    {professional.logo_url ? (
                      <img 
                        src={professional.logo_url} 
                        alt={professional.business_name}
                        className="w-full h-full object-cover rounded-xl"
                      />
                    ) : (
                      <CategoryIcon className="w-12 h-12 text-primary" />
                    )}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-4 flex-wrap">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h1 className="text-2xl font-serif font-semibold">
                            {professional.business_name}
                          </h1>
                          {professional.is_verified && (
                            <CheckCircle2 className="w-5 h-5 text-primary" />
                          )}
                        </div>
                        <div className="flex items-center gap-3 mt-2 flex-wrap">
                          <Badge variant="secondary">
                            {getCategoryLabel(professional.primary_category)}
                          </Badge>
                          {professional.city && (
                            <span className="text-sm text-muted-foreground flex items-center gap-1">
                              <MapPin className="w-4 h-4" />
                              {professional.city}
                              {professional.province && `, ${professional.province}`}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Rating */}
                      <div className="flex items-center gap-2">
                        <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                        <span className="font-semibold">{professional.average_rating || "—"}</span>
                        <span className="text-muted-foreground text-sm">
                          ({professional.total_reviews} reseñas)
                        </span>
                      </div>
                    </div>

                    {professional.description && (
                      <p className="mt-4 text-muted-foreground">
                        {professional.description}
                      </p>
                    )}

                    {/* Social Links */}
                    <div className="flex items-center gap-3 mt-4">
                      {professional.website && (
                        <a 
                          href={professional.website} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
                        >
                          <Globe className="w-5 h-5" />
                        </a>
                      )}
                      {professional.instagram && (
                        <a 
                          href={`https://instagram.com/${professional.instagram.replace("@", "")}`}
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
                        >
                          <Instagram className="w-5 h-5" />
                        </a>
                      )}
                      {professional.facebook && (
                        <a 
                          href={professional.facebook}
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
                        >
                          <Facebook className="w-5 h-5" />
                        </a>
                      )}
                      {professional.youtube && (
                        <a 
                          href={professional.youtube}
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
                        >
                          <Youtube className="w-5 h-5" />
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Story */}
            {professional.story && (
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-lg font-semibold mb-4">Nuestra historia</h2>
                  <p className="text-muted-foreground whitespace-pre-line">
                    {professional.story}
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Gallery */}
            {gallery.length > 0 && (
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-lg font-semibold mb-4">Galería</h2>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {gallery.map((item) => (
                      <div key={item.id} className="aspect-square rounded-lg overflow-hidden bg-secondary">
                        {item.type === "image" ? (
                          <img 
                            src={item.url} 
                            alt={item.title || ""} 
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <ImageIcon className="w-8 h-8 text-muted-foreground" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Reviews */}
            <Card>
              <CardContent className="p-6">
                <h2 className="text-lg font-semibold mb-4">
                  Reseñas ({professional.total_reviews})
                </h2>
                {reviews.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">
                    Aún no hay reseñas verificadas
                  </p>
                ) : (
                  <div className="space-y-4">
                    {reviews.map((review) => (
                      <div key={review.id} className="border-b last:border-0 pb-4 last:pb-0">
                        <div className="flex items-center gap-2 mb-2">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < review.rating 
                                  ? "text-amber-500 fill-amber-500" 
                                  : "text-muted-foreground"
                              }`}
                            />
                          ))}
                        </div>
                        {review.title && (
                          <p className="font-medium">{review.title}</p>
                        )}
                        {review.content && (
                          <p className="text-muted-foreground text-sm mt-1">
                            {review.content}
                          </p>
                        )}
                        {review.response && (
                          <div className="mt-3 p-3 bg-secondary/50 rounded-lg">
                            <p className="text-xs font-medium mb-1">Respuesta del profesional:</p>
                            <p className="text-sm text-muted-foreground">{review.response}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardContent className="p-6 space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">¿Te interesa este profesional?</h3>
                  <p className="text-sm text-muted-foreground">
                    Envía un mensaje para consultar disponibilidad y precios.
                  </p>
                </div>
                
                <Button 
                  className="w-full"
                  onClick={() => setShowContactModal(true)}
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Contactar
                </Button>

                {/* Contract button - only for logged in users with active wedding */}
                {user && activeWedding && (
                  <>
                    {existingContract?.status === "contracted" || existingContract?.status === "completed" ? (
                      <div className="flex items-center justify-center gap-2 p-3 bg-green-500/10 rounded-lg text-green-700">
                        <CheckCircle2 className="w-4 h-4" />
                        <span className="text-sm font-medium">Contratado</span>
                      </div>
                    ) : (
                      <Button 
                        variant="outline"
                        className="w-full"
                        onClick={handleContract}
                        disabled={contracting}
                      >
                        {contracting ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Procesando...
                          </>
                        ) : (
                          <>
                            <Handshake className="w-4 h-4 mr-2" />
                            Marcar como contratado
                          </>
                        )}
                      </Button>
                    )}
                    <p className="text-xs text-muted-foreground text-center">
                      Al contratar se creará automáticamente una tarea y partida de presupuesto
                    </p>
                  </>
                )}

                {!user && (
                  <p className="text-xs text-muted-foreground text-center">
                    <Link to="/auth" className="text-primary hover:underline">
                      Inicia sesión
                    </Link>
                    {" "}para contactar
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Contact Modal */}
      <Dialog open={showContactModal} onOpenChange={setShowContactModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Contactar con {professional.business_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Envía un mensaje presentándote y consultando lo que necesites. 
              El profesional te responderá a través de la plataforma.
            </p>
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Hola, estamos organizando nuestra boda y nos gustaría..."
              rows={4}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowContactModal(false)}>
              Cancelar
            </Button>
            <Button onClick={handleContact} disabled={sending || !message.trim()}>
              {sending ? "Enviando..." : "Enviar mensaje"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
