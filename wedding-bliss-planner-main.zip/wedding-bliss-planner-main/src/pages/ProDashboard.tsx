import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useProfessionalAuth } from "@/contexts/ProfessionalAuthContext";
import { ProDashboardLayout } from "@/components/professional/ProDashboardLayout";
import { ProHomeSection } from "@/components/professional/sections/ProHomeSection";
import { ProProfileSection } from "@/components/professional/sections/ProProfileSection";
import { ProGallerySection } from "@/components/professional/sections/ProGallerySection";
import { ProMessagesSection } from "@/components/professional/sections/ProMessagesSection";
import { ProClientsSection } from "@/components/professional/sections/ProClientsSection";
import { ProReviewsSection } from "@/components/professional/sections/ProReviewsSection";
import { ProStatsSection } from "@/components/professional/sections/ProStatsSection";
import { ProSubscriptionSection } from "@/components/professional/sections/ProSubscriptionSection";
import { ProSettingsSection } from "@/components/professional/sections/ProSettingsSection";

export default function ProDashboard() {
  const { user, professional, loading } = useProfessionalAuth();
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState("home");

  useEffect(() => {
    if (!loading && !user) {
      navigate("/pro/auth");
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (!loading && user && !professional) {
      // User is logged in but not a professional
      navigate("/pro/auth");
    }
  }, [user, professional, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Cargando...</p>
        </div>
      </div>
    );
  }

  const renderSection = () => {
    switch (activeSection) {
      case "home":
        return <ProHomeSection />;
      case "profile":
        return <ProProfileSection />;
      case "gallery":
        return <ProGallerySection />;
      case "messages":
        return <ProMessagesSection />;
      case "clients":
        return <ProClientsSection />;
      case "reviews":
        return <ProReviewsSection />;
      case "stats":
        return <ProStatsSection />;
      case "subscription":
        return <ProSubscriptionSection />;
      case "settings":
        return <ProSettingsSection />;
      default:
        return <ProHomeSection />;
    }
  };

  return (
    <ProDashboardLayout
      activeSection={activeSection}
      onSectionChange={setActiveSection}
    >
      {renderSection()}
    </ProDashboardLayout>
  );
}
