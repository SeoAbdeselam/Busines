import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useWedding } from "@/contexts/WeddingContext";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { DashboardHome } from "@/components/dashboard/DashboardHome";
import { GuestsSection } from "@/components/dashboard/GuestsSection";
import { SeatingPlanner } from "@/components/dashboard/seating/SeatingPlanner";
import { TaskManager } from "@/components/dashboard/tasks/TaskManager";
import { BudgetSection } from "@/components/dashboard/BudgetSection";
import { GiftsSection } from "@/components/dashboard/GiftsSection";
import { AnnouncementsSection } from "@/components/dashboard/AnnouncementsSection";
import { ProvidersSection } from "@/components/dashboard/ProvidersSection";
import { SettingsSection } from "@/components/dashboard/SettingsSection";
import { CreateWeddingModal } from "@/components/dashboard/CreateWeddingModal";

export default function Dashboard() {
  const { user, loading: authLoading } = useAuth();
  const { activeWedding, memberships, loading: weddingLoading, refreshWeddings } = useWedding();
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState("home");
  const [showCreateModal, setShowCreateModal] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    // If user has no weddings, show create modal
    if (!weddingLoading && memberships.length === 0) {
      setShowCreateModal(true);
    }
  }, [weddingLoading, memberships]);

  if (authLoading || weddingLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Cargando...</p>
        </div>
      </div>
    );
  }

  const renderSection = () => {
    if (!activeWedding) {
      return (
        <div className="flex items-center justify-center h-full">
          <p className="text-muted-foreground">Selecciona o crea una boda para empezar</p>
        </div>
      );
    }

    switch (activeSection) {
      case "home":
        return <DashboardHome onNavigate={setActiveSection} />;
      case "tasks":
        return <TaskManager />;
      case "guests":
        return <GuestsSection />;
      case "tables":
        return <SeatingPlanner />;
      case "budget":
        return <BudgetSection />;
      case "providers":
        return <ProvidersSection />;
      case "gifts":
        return <GiftsSection />;
      case "announcements":
        return <AnnouncementsSection />;
      case "settings":
        return <SettingsSection />;
      default:
        return <DashboardHome />;
    }
  };

  return (
    <>
      <DashboardLayout
        activeSection={activeSection}
        onSectionChange={setActiveSection}
        onCreateWedding={() => setShowCreateModal(true)}
      >
        {renderSection()}
      </DashboardLayout>

      <CreateWeddingModal
        open={showCreateModal}
        onOpenChange={setShowCreateModal}
        onSuccess={() => {
          refreshWeddings();
          setShowCreateModal(false);
        }}
      />
    </>
  );
}
