import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { Features } from "@/components/Features";
import { Categories } from "@/components/Categories";
import { InspirationSection } from "@/components/home/InspirationSection";
import { WeddingArticles } from "@/components/home/WeddingArticles";
import { LeadForm } from "@/components/LeadForm";
import { Footer } from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <Hero />
        <Features />
        <Categories />
        <InspirationSection />
        <WeddingArticles />
        <LeadForm />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
