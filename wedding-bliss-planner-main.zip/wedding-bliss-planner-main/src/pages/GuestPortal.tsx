import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useWedding } from "@/contexts/WeddingContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { 
  Heart, 
  Calendar, 
  MapPin, 
  Users, 
  Bell,
  LogOut,
  CheckCircle2,
  XCircle,
  Clock
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

interface GuestInfo {
  id: string;
  name: string;
  rsvp_status: "pending" | "confirmed" | "declined";
  plus_ones: number;
  dietary_notes: string | null;
}

interface Announcement {
  id: string;
  title: string;
  content: string;
  created_at: string;
}

export default function GuestPortal() {
  const { user, loading: authLoading, signOut } = useAuth();
  const { activeWedding, userRole, loading: weddingLoading } = useWedding();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [guestInfo, setGuestInfo] = useState<GuestInfo | null>(null);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!weddingLoading && userRole === "couple") {
      navigate("/dashboard");
    }
  }, [userRole, weddingLoading, navigate]);

  useEffect(() => {
    if (activeWedding && user) {
      fetchGuestInfo();
      fetchAnnouncements();
    }
  }, [activeWedding, user]);

  const fetchGuestInfo = async () => {
    if (!activeWedding || !user) return;

    const { data, error } = await supabase
      .from("guests")
      .select("id, name, rsvp_status, plus_ones, dietary_notes")
      .eq("wedding_id", activeWedding.id)
      .eq("user_id", user.id)
      .maybeSingle();

    if (!error && data) {
      setGuestInfo(data);
    }
    setLoading(false);
  };

  const fetchAnnouncements = async () => {
    if (!activeWedding) return;

    const { data, error } = await supabase
      .from("announcements")
      .select("id, title, content, created_at")
      .eq("wedding_id", activeWedding.id)
      .order("created_at", { ascending: false })
      .limit(5);

    if (!error && data) {
      setAnnouncements(data);
    }
  };

  const updateRSVP = async (status: "confirmed" | "declined") => {
    if (!guestInfo) return;

    const { error } = await supabase
      .from("guests")
      .update({ rsvp_status: status })
      .eq("id", guestInfo.id);

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo actualizar tu confirmación",
        variant: "destructive",
      });
    } else {
      setGuestInfo({ ...guestInfo, rsvp_status: status });
      toast({
        title: status === "confirmed" ? "¡Confirmado!" : "Respuesta registrada",
        description: status === "confirmed" 
          ? "¡Nos vemos en la boda!"
          : "Lamentamos que no puedas asistir",
      });
    }
  };

  const handleLogout = async () => {
    await signOut();
    navigate("/auth");
  };

  if (authLoading || weddingLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Cargando...</p>
        </div>
      </div>
    );
  }

  if (!activeWedding) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6 text-center">
            <Heart className="w-12 h-12 text-primary mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">No tienes acceso a ninguna boda</h2>
            <p className="text-muted-foreground mb-4">
              Pide a los novios que te envíen el código de invitación
            </p>
            <Button onClick={handleLogout} variant="outline">
              <LogOut className="w-4 h-4 mr-2" />
              Cerrar sesión
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background">
      {/* Header */}
      <header className="bg-card/80 backdrop-blur-sm border-b border-border sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Heart className="w-6 h-6 text-primary" fill="currentColor" />
            <span className="font-serif text-lg font-semibold">
              {activeWedding.name}
            </span>
          </div>
          <Button variant="ghost" size="sm" onClick={handleLogout}>
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Wedding Info */}
        <Card className="mb-6 overflow-hidden">
          {activeWedding.cover_image_url && (
            <div className="h-48 overflow-hidden">
              <img
                src={activeWedding.cover_image_url}
                alt={activeWedding.name}
                className="w-full h-full object-cover"
              />
            </div>
          )}
          <CardContent className="pt-6">
            <h1 className="text-2xl font-serif font-bold text-center mb-4">
              {activeWedding.name}
            </h1>
            <div className="flex flex-col sm:flex-row gap-4 justify-center text-muted-foreground">
              {activeWedding.wedding_date && (
                <div className="flex items-center gap-2 justify-center">
                  <Calendar className="w-4 h-4" />
                  <span>
                    {format(new Date(activeWedding.wedding_date), "d 'de' MMMM, yyyy", { locale: es })}
                  </span>
                </div>
              )}
              {activeWedding.location && (
                <div className="flex items-center gap-2 justify-center">
                  <MapPin className="w-4 h-4" />
                  <span>{activeWedding.location}</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* RSVP Section */}
        {guestInfo && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Tu Confirmación
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-4">
                <p className="text-lg mb-2">Hola, {guestInfo.name}</p>
                <div className="flex items-center justify-center gap-2">
                  {guestInfo.rsvp_status === "confirmed" && (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-green-500" />
                      <span className="text-green-600 font-medium">Asistencia confirmada</span>
                    </>
                  )}
                  {guestInfo.rsvp_status === "declined" && (
                    <>
                      <XCircle className="w-5 h-5 text-red-500" />
                      <span className="text-red-600 font-medium">No asistirás</span>
                    </>
                  )}
                  {guestInfo.rsvp_status === "pending" && (
                    <>
                      <Clock className="w-5 h-5 text-amber-500" />
                      <span className="text-amber-600 font-medium">Pendiente de confirmar</span>
                    </>
                  )}
                </div>
              </div>

              {guestInfo.rsvp_status === "pending" && (
                <div className="flex gap-3 justify-center">
                  <Button
                    onClick={() => updateRSVP("confirmed")}
                    className="flex-1 max-w-[150px]"
                  >
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Confirmar
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => updateRSVP("declined")}
                    className="flex-1 max-w-[150px]"
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    No asisto
                  </Button>
                </div>
              )}

              {guestInfo.rsvp_status !== "pending" && (
                <p className="text-sm text-center text-muted-foreground">
                  ¿Cambiaste de opinión?{" "}
                  <button
                    onClick={() => updateRSVP(guestInfo.rsvp_status === "confirmed" ? "declined" : "confirmed")}
                    className="text-primary hover:underline"
                  >
                    Actualizar respuesta
                  </button>
                </p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Announcements */}
        {announcements.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Avisos de los Novios
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {announcements.map((announcement) => (
                <div
                  key={announcement.id}
                  className="p-4 rounded-lg bg-secondary/30 border border-border/50"
                >
                  <h3 className="font-medium mb-1">{announcement.title}</h3>
                  <p className="text-sm text-muted-foreground mb-2">
                    {announcement.content}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {format(new Date(announcement.created_at), "d MMM, yyyy", { locale: es })}
                  </p>
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
