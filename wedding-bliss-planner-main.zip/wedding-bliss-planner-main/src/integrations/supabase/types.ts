export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      announcements: {
        Row: {
          content: string
          created_at: string
          created_by: string
          id: string
          is_global: boolean
          target_group_id: string | null
          title: string
          updated_at: string
          wedding_id: string
        }
        Insert: {
          content: string
          created_at?: string
          created_by: string
          id?: string
          is_global?: boolean
          target_group_id?: string | null
          title: string
          updated_at?: string
          wedding_id: string
        }
        Update: {
          content?: string
          created_at?: string
          created_by?: string
          id?: string
          is_global?: boolean
          target_group_id?: string | null
          title?: string
          updated_at?: string
          wedding_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "announcements_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "announcements_target_group_id_fkey"
            columns: ["target_group_id"]
            isOneToOne: false
            referencedRelation: "guest_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "announcements_wedding_id_fkey"
            columns: ["wedding_id"]
            isOneToOne: false
            referencedRelation: "weddings"
            referencedColumns: ["id"]
          },
        ]
      }
      budget_items: {
        Row: {
          actual_amount: number | null
          category: string
          created_at: string
          estimated_amount: number
          id: string
          is_paid: boolean
          name: string
          notes: string | null
          updated_at: string
          wedding_id: string
        }
        Insert: {
          actual_amount?: number | null
          category: string
          created_at?: string
          estimated_amount?: number
          id?: string
          is_paid?: boolean
          name: string
          notes?: string | null
          updated_at?: string
          wedding_id: string
        }
        Update: {
          actual_amount?: number | null
          category?: string
          created_at?: string
          estimated_amount?: number
          id?: string
          is_paid?: boolean
          name?: string
          notes?: string | null
          updated_at?: string
          wedding_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "budget_items_wedding_id_fkey"
            columns: ["wedding_id"]
            isOneToOne: false
            referencedRelation: "weddings"
            referencedColumns: ["id"]
          },
        ]
      }
      consents: {
        Row: {
          consent_type: Database["public"]["Enums"]["consent_type"]
          created_at: string
          granted: boolean
          granted_at: string | null
          id: string
          ip_address: string | null
          origin: string
          revoked_at: string | null
          updated_at: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          consent_type: Database["public"]["Enums"]["consent_type"]
          created_at?: string
          granted?: boolean
          granted_at?: string | null
          id?: string
          ip_address?: string | null
          origin?: string
          revoked_at?: string | null
          updated_at?: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          consent_type?: Database["public"]["Enums"]["consent_type"]
          created_at?: string
          granted?: boolean
          granted_at?: string | null
          id?: string
          ip_address?: string | null
          origin?: string
          revoked_at?: string | null
          updated_at?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "consents_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      gifts: {
        Row: {
          amount: number | null
          created_at: string
          description: string | null
          guest_group_id: string | null
          guest_id: string | null
          id: string
          is_monetary: boolean
          notes: string | null
          received_at: string | null
          updated_at: string
          wedding_id: string
        }
        Insert: {
          amount?: number | null
          created_at?: string
          description?: string | null
          guest_group_id?: string | null
          guest_id?: string | null
          id?: string
          is_monetary?: boolean
          notes?: string | null
          received_at?: string | null
          updated_at?: string
          wedding_id: string
        }
        Update: {
          amount?: number | null
          created_at?: string
          description?: string | null
          guest_group_id?: string | null
          guest_id?: string | null
          id?: string
          is_monetary?: boolean
          notes?: string | null
          received_at?: string | null
          updated_at?: string
          wedding_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "gifts_guest_group_id_fkey"
            columns: ["guest_group_id"]
            isOneToOne: false
            referencedRelation: "guest_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "gifts_guest_id_fkey"
            columns: ["guest_id"]
            isOneToOne: false
            referencedRelation: "guests"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "gifts_wedding_id_fkey"
            columns: ["wedding_id"]
            isOneToOne: false
            referencedRelation: "weddings"
            referencedColumns: ["id"]
          },
        ]
      }
      guest_groups: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          updated_at: string
          wedding_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          updated_at?: string
          wedding_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          updated_at?: string
          wedding_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "guest_groups_wedding_id_fkey"
            columns: ["wedding_id"]
            isOneToOne: false
            referencedRelation: "weddings"
            referencedColumns: ["id"]
          },
        ]
      }
      guests: {
        Row: {
          created_at: string
          dietary_notes: string | null
          email: string | null
          guest_group_id: string | null
          id: string
          linked_guest_id: string | null
          name: string
          notes: string | null
          phone: string | null
          plus_ones: number
          rsvp_status: Database["public"]["Enums"]["rsvp_status"]
          table_id: string | null
          updated_at: string
          user_id: string | null
          wedding_id: string
        }
        Insert: {
          created_at?: string
          dietary_notes?: string | null
          email?: string | null
          guest_group_id?: string | null
          id?: string
          linked_guest_id?: string | null
          name: string
          notes?: string | null
          phone?: string | null
          plus_ones?: number
          rsvp_status?: Database["public"]["Enums"]["rsvp_status"]
          table_id?: string | null
          updated_at?: string
          user_id?: string | null
          wedding_id: string
        }
        Update: {
          created_at?: string
          dietary_notes?: string | null
          email?: string | null
          guest_group_id?: string | null
          id?: string
          linked_guest_id?: string | null
          name?: string
          notes?: string | null
          phone?: string | null
          plus_ones?: number
          rsvp_status?: Database["public"]["Enums"]["rsvp_status"]
          table_id?: string | null
          updated_at?: string
          user_id?: string | null
          wedding_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "guests_guest_group_id_fkey"
            columns: ["guest_group_id"]
            isOneToOne: false
            referencedRelation: "guest_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "guests_linked_guest_id_fkey"
            columns: ["linked_guest_id"]
            isOneToOne: false
            referencedRelation: "guests"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "guests_table_id_fkey"
            columns: ["table_id"]
            isOneToOne: false
            referencedRelation: "wedding_tables"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "guests_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "guests_wedding_id_fkey"
            columns: ["wedding_id"]
            isOneToOne: false
            referencedRelation: "weddings"
            referencedColumns: ["id"]
          },
        ]
      }
      professional_contracts: {
        Row: {
          actual_cost: number | null
          budget_item_id: string | null
          client_user_id: string
          completed_at: string | null
          contracted_at: string | null
          created_at: string
          deposit_amount: number | null
          deposit_paid: boolean | null
          estimated_cost: number | null
          id: string
          notes: string | null
          professional_id: string
          service_date: string | null
          service_description: string | null
          status: Database["public"]["Enums"]["contract_status"]
          task_id: string | null
          updated_at: string
          wedding_id: string
        }
        Insert: {
          actual_cost?: number | null
          budget_item_id?: string | null
          client_user_id: string
          completed_at?: string | null
          contracted_at?: string | null
          created_at?: string
          deposit_amount?: number | null
          deposit_paid?: boolean | null
          estimated_cost?: number | null
          id?: string
          notes?: string | null
          professional_id: string
          service_date?: string | null
          service_description?: string | null
          status?: Database["public"]["Enums"]["contract_status"]
          task_id?: string | null
          updated_at?: string
          wedding_id: string
        }
        Update: {
          actual_cost?: number | null
          budget_item_id?: string | null
          client_user_id?: string
          completed_at?: string | null
          contracted_at?: string | null
          created_at?: string
          deposit_amount?: number | null
          deposit_paid?: boolean | null
          estimated_cost?: number | null
          id?: string
          notes?: string | null
          professional_id?: string
          service_date?: string | null
          service_description?: string | null
          status?: Database["public"]["Enums"]["contract_status"]
          task_id?: string | null
          updated_at?: string
          wedding_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "professional_contracts_budget_item_id_fkey"
            columns: ["budget_item_id"]
            isOneToOne: false
            referencedRelation: "budget_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "professional_contracts_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "professionals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "professional_contracts_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "professional_contracts_wedding_id_fkey"
            columns: ["wedding_id"]
            isOneToOne: false
            referencedRelation: "weddings"
            referencedColumns: ["id"]
          },
        ]
      }
      professional_conversations: {
        Row: {
          client_unread: number | null
          client_user_id: string
          created_at: string
          id: string
          last_message_at: string | null
          professional_id: string
          professional_unread: number | null
          wedding_id: string
        }
        Insert: {
          client_unread?: number | null
          client_user_id: string
          created_at?: string
          id?: string
          last_message_at?: string | null
          professional_id: string
          professional_unread?: number | null
          wedding_id: string
        }
        Update: {
          client_unread?: number | null
          client_user_id?: string
          created_at?: string
          id?: string
          last_message_at?: string | null
          professional_id?: string
          professional_unread?: number | null
          wedding_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "professional_conversations_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "professionals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "professional_conversations_wedding_id_fkey"
            columns: ["wedding_id"]
            isOneToOne: false
            referencedRelation: "weddings"
            referencedColumns: ["id"]
          },
        ]
      }
      professional_gallery: {
        Row: {
          created_at: string
          description: string | null
          id: string
          professional_id: string
          sort_order: number | null
          thumbnail_url: string | null
          title: string | null
          type: string
          url: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          professional_id: string
          sort_order?: number | null
          thumbnail_url?: string | null
          title?: string | null
          type: string
          url: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          professional_id?: string
          sort_order?: number | null
          thumbnail_url?: string | null
          title?: string | null
          type?: string
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "professional_gallery_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "professionals"
            referencedColumns: ["id"]
          },
        ]
      }
      professional_messages: {
        Row: {
          content: string
          conversation_id: string
          created_at: string
          id: string
          is_read: boolean | null
          sender_id: string
          sender_type: string
        }
        Insert: {
          content: string
          conversation_id: string
          created_at?: string
          id?: string
          is_read?: boolean | null
          sender_id: string
          sender_type: string
        }
        Update: {
          content?: string
          conversation_id?: string
          created_at?: string
          id?: string
          is_read?: boolean | null
          sender_id?: string
          sender_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "professional_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "professional_conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      professional_reviews: {
        Row: {
          content: string | null
          contract_id: string
          created_at: string
          id: string
          is_published: boolean | null
          is_verified: boolean | null
          professional_id: string
          rating: number
          response: string | null
          response_at: string | null
          reviewer_user_id: string
          title: string | null
          updated_at: string
          wedding_id: string
        }
        Insert: {
          content?: string | null
          contract_id: string
          created_at?: string
          id?: string
          is_published?: boolean | null
          is_verified?: boolean | null
          professional_id: string
          rating: number
          response?: string | null
          response_at?: string | null
          reviewer_user_id: string
          title?: string | null
          updated_at?: string
          wedding_id: string
        }
        Update: {
          content?: string | null
          contract_id?: string
          created_at?: string
          id?: string
          is_published?: boolean | null
          is_verified?: boolean | null
          professional_id?: string
          rating?: number
          response?: string | null
          response_at?: string | null
          reviewer_user_id?: string
          title?: string | null
          updated_at?: string
          wedding_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "professional_reviews_contract_id_fkey"
            columns: ["contract_id"]
            isOneToOne: true
            referencedRelation: "professional_contracts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "professional_reviews_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "professionals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "professional_reviews_wedding_id_fkey"
            columns: ["wedding_id"]
            isOneToOne: false
            referencedRelation: "weddings"
            referencedColumns: ["id"]
          },
        ]
      }
      professional_subscriptions: {
        Row: {
          created_at: string
          expires_at: string | null
          id: string
          notes: string | null
          payment_method: string | null
          payment_reference: string | null
          plan: Database["public"]["Enums"]["subscription_plan"]
          professional_id: string
          started_at: string
          status: Database["public"]["Enums"]["subscription_status"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          id?: string
          notes?: string | null
          payment_method?: string | null
          payment_reference?: string | null
          plan?: Database["public"]["Enums"]["subscription_plan"]
          professional_id: string
          started_at?: string
          status?: Database["public"]["Enums"]["subscription_status"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          id?: string
          notes?: string | null
          payment_method?: string | null
          payment_reference?: string | null
          plan?: Database["public"]["Enums"]["subscription_plan"]
          professional_id?: string
          started_at?: string
          status?: Database["public"]["Enums"]["subscription_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "professional_subscriptions_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "professionals"
            referencedColumns: ["id"]
          },
        ]
      }
      professionals: {
        Row: {
          average_rating: number | null
          business_name: string
          city: string | null
          contacts_count: number | null
          cover_image_url: string | null
          created_at: string
          description: string | null
          email: string | null
          facebook: string | null
          id: string
          instagram: string | null
          is_active: boolean | null
          is_premium: boolean | null
          is_profile_complete: boolean | null
          is_verified: boolean | null
          location: string | null
          logo_url: string | null
          phone: string | null
          primary_category: Database["public"]["Enums"]["professional_category"]
          province: string | null
          secondary_categories:
            | Database["public"]["Enums"]["professional_category"][]
            | null
          slug: string
          story: string | null
          tiktok: string | null
          total_contracts: number | null
          total_reviews: number | null
          updated_at: string
          user_id: string
          views_count: number | null
          website: string | null
          youtube: string | null
        }
        Insert: {
          average_rating?: number | null
          business_name: string
          city?: string | null
          contacts_count?: number | null
          cover_image_url?: string | null
          created_at?: string
          description?: string | null
          email?: string | null
          facebook?: string | null
          id?: string
          instagram?: string | null
          is_active?: boolean | null
          is_premium?: boolean | null
          is_profile_complete?: boolean | null
          is_verified?: boolean | null
          location?: string | null
          logo_url?: string | null
          phone?: string | null
          primary_category: Database["public"]["Enums"]["professional_category"]
          province?: string | null
          secondary_categories?:
            | Database["public"]["Enums"]["professional_category"][]
            | null
          slug: string
          story?: string | null
          tiktok?: string | null
          total_contracts?: number | null
          total_reviews?: number | null
          updated_at?: string
          user_id: string
          views_count?: number | null
          website?: string | null
          youtube?: string | null
        }
        Update: {
          average_rating?: number | null
          business_name?: string
          city?: string | null
          contacts_count?: number | null
          cover_image_url?: string | null
          created_at?: string
          description?: string | null
          email?: string | null
          facebook?: string | null
          id?: string
          instagram?: string | null
          is_active?: boolean | null
          is_premium?: boolean | null
          is_profile_complete?: boolean | null
          is_verified?: boolean | null
          location?: string | null
          logo_url?: string | null
          phone?: string | null
          primary_category?: Database["public"]["Enums"]["professional_category"]
          province?: string | null
          secondary_categories?:
            | Database["public"]["Enums"]["professional_category"][]
            | null
          slug?: string
          story?: string | null
          tiktok?: string | null
          total_contracts?: number | null
          total_reviews?: number | null
          updated_at?: string
          user_id?: string
          views_count?: number | null
          website?: string | null
          youtube?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string
          full_name: string | null
          id: string
          phone: string
          role: Database["public"]["Enums"]["user_role"] | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email: string
          full_name?: string | null
          id: string
          phone?: string
          role?: Database["public"]["Enums"]["user_role"] | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string
          full_name?: string | null
          id?: string
          phone?: string
          role?: Database["public"]["Enums"]["user_role"] | null
          updated_at?: string
        }
        Relationships: []
      }
      task_templates: {
        Row: {
          budget_category: string | null
          category: string
          description: string | null
          has_cost: boolean
          id: string
          key: string
          months_before: number
          priority: number
          sort_order: number
          title: string
        }
        Insert: {
          budget_category?: string | null
          category: string
          description?: string | null
          has_cost?: boolean
          id?: string
          key: string
          months_before: number
          priority?: number
          sort_order?: number
          title: string
        }
        Update: {
          budget_category?: string | null
          category?: string
          description?: string | null
          has_cost?: boolean
          id?: string
          key?: string
          months_before?: number
          priority?: number
          sort_order?: number
          title?: string
        }
        Relationships: []
      }
      tasks: {
        Row: {
          actual_cost: number | null
          budget_category: string | null
          category: string
          completed_at: string | null
          created_at: string
          description: string | null
          due_date: string | null
          estimated_cost: number | null
          has_cost: boolean
          id: string
          is_from_template: boolean
          payment_status: string | null
          priority: number
          sort_order: number
          status: string
          template_key: string | null
          title: string
          updated_at: string
          wedding_id: string
        }
        Insert: {
          actual_cost?: number | null
          budget_category?: string | null
          category?: string
          completed_at?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          estimated_cost?: number | null
          has_cost?: boolean
          id?: string
          is_from_template?: boolean
          payment_status?: string | null
          priority?: number
          sort_order?: number
          status?: string
          template_key?: string | null
          title: string
          updated_at?: string
          wedding_id: string
        }
        Update: {
          actual_cost?: number | null
          budget_category?: string | null
          category?: string
          completed_at?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          estimated_cost?: number | null
          has_cost?: boolean
          id?: string
          is_from_template?: boolean
          payment_status?: string | null
          priority?: number
          sort_order?: number
          status?: string
          template_key?: string | null
          title?: string
          updated_at?: string
          wedding_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tasks_wedding_id_fkey"
            columns: ["wedding_id"]
            isOneToOne: false
            referencedRelation: "weddings"
            referencedColumns: ["id"]
          },
        ]
      }
      wedding_memberships: {
        Row: {
          created_at: string
          id: string
          invited_by: string | null
          role: Database["public"]["Enums"]["wedding_role"]
          user_id: string
          wedding_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          invited_by?: string | null
          role?: Database["public"]["Enums"]["wedding_role"]
          user_id: string
          wedding_id: string
        }
        Update: {
          created_at?: string
          id?: string
          invited_by?: string | null
          role?: Database["public"]["Enums"]["wedding_role"]
          user_id?: string
          wedding_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wedding_memberships_invited_by_fkey"
            columns: ["invited_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wedding_memberships_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wedding_memberships_wedding_id_fkey"
            columns: ["wedding_id"]
            isOneToOne: false
            referencedRelation: "weddings"
            referencedColumns: ["id"]
          },
        ]
      }
      wedding_tables: {
        Row: {
          capacity: number
          created_at: string
          id: string
          name: string
          position_x: number | null
          position_y: number | null
          table_type: Database["public"]["Enums"]["table_type"]
          updated_at: string
          wedding_id: string
        }
        Insert: {
          capacity?: number
          created_at?: string
          id?: string
          name: string
          position_x?: number | null
          position_y?: number | null
          table_type?: Database["public"]["Enums"]["table_type"]
          updated_at?: string
          wedding_id: string
        }
        Update: {
          capacity?: number
          created_at?: string
          id?: string
          name?: string
          position_x?: number | null
          position_y?: number | null
          table_type?: Database["public"]["Enums"]["table_type"]
          updated_at?: string
          wedding_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wedding_tables_wedding_id_fkey"
            columns: ["wedding_id"]
            isOneToOne: false
            referencedRelation: "weddings"
            referencedColumns: ["id"]
          },
        ]
      }
      weddings: {
        Row: {
          cover_image_url: string | null
          created_at: string
          created_by: string
          id: string
          location: string | null
          name: string
          primary_color: string | null
          secondary_color: string | null
          updated_at: string
          wedding_code: string
          wedding_date: string | null
        }
        Insert: {
          cover_image_url?: string | null
          created_at?: string
          created_by: string
          id?: string
          location?: string | null
          name: string
          primary_color?: string | null
          secondary_color?: string | null
          updated_at?: string
          wedding_code: string
          wedding_date?: string | null
        }
        Update: {
          cover_image_url?: string | null
          created_at?: string
          created_by?: string
          id?: string
          location?: string | null
          name?: string
          primary_color?: string | null
          secondary_color?: string | null
          updated_at?: string
          wedding_code?: string
          wedding_date?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "weddings_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      calculate_professional_profile_complete: {
        Args: { p_professional_id: string }
        Returns: boolean
      }
      get_professional_id: { Args: { p_user_id: string }; Returns: string }
      get_wedding_by_code: { Args: { p_code: string }; Returns: string }
      is_couple_in_wedding: { Args: { p_wedding_id: string }; Returns: boolean }
      is_professional: { Args: { p_user_id: string }; Returns: boolean }
      is_wedding_member: { Args: { p_wedding_id: string }; Returns: boolean }
      is_wedding_owner: { Args: { p_wedding_id: string }; Returns: boolean }
      professional_has_premium: {
        Args: { p_professional_id: string }
        Returns: boolean
      }
    }
    Enums: {
      consent_type:
        | "terms_of_service"
        | "privacy_policy"
        | "marketing_communications"
        | "provider_offers"
        | "event_notifications"
      contract_status:
        | "interested"
        | "contacted"
        | "contracted"
        | "completed"
        | "cancelled"
      professional_category:
        | "photography"
        | "video"
        | "florist"
        | "catering"
        | "dj_music"
        | "dresses"
        | "transport"
        | "pastry"
        | "jewelry"
        | "venues"
        | "wedding_planner"
        | "makeup_hair"
        | "decoration"
        | "invitations"
        | "other"
      rsvp_status: "pending" | "confirmed" | "declined"
      subscription_plan: "free" | "premium"
      subscription_status: "active" | "expired" | "cancelled"
      table_type: "round" | "rectangular" | "imperial"
      user_role: "couple" | "guest" | "professional" | "admin"
      wedding_role: "couple" | "guest"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      consent_type: [
        "terms_of_service",
        "privacy_policy",
        "marketing_communications",
        "provider_offers",
        "event_notifications",
      ],
      contract_status: [
        "interested",
        "contacted",
        "contracted",
        "completed",
        "cancelled",
      ],
      professional_category: [
        "photography",
        "video",
        "florist",
        "catering",
        "dj_music",
        "dresses",
        "transport",
        "pastry",
        "jewelry",
        "venues",
        "wedding_planner",
        "makeup_hair",
        "decoration",
        "invitations",
        "other",
      ],
      rsvp_status: ["pending", "confirmed", "declined"],
      subscription_plan: ["free", "premium"],
      subscription_status: ["active", "expired", "cancelled"],
      table_type: ["round", "rectangular", "imperial"],
      user_role: ["couple", "guest", "professional", "admin"],
      wedding_role: ["couple", "guest"],
    },
  },
} as const
