import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { WeddingProvider } from "@/contexts/WeddingContext";
import { ProfessionalAuthProvider } from "@/contexts/ProfessionalAuthContext";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import GuestPortal from "./pages/GuestPortal";
import ProfessionalAuth from "./pages/ProfessionalAuth";
import ProDashboard from "./pages/ProDashboard";
import ProfessionalsDirectory from "./pages/ProfessionalsDirectory";
import ProfessionalProfile from "./pages/ProfessionalProfile";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <WeddingProvider>
        <ProfessionalAuthProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/auth" element={<Auth />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/guest" element={<GuestPortal />} />
                <Route path="/pro/auth" element={<ProfessionalAuth />} />
                <Route path="/pro/dashboard" element={<ProDashboard />} />
                <Route path="/profesionales" element={<ProfessionalsDirectory />} />
                <Route path="/profesionales/:slug" element={<ProfessionalProfile />} />
                {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </TooltipProvider>
        </ProfessionalAuthProvider>
      </WeddingProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
