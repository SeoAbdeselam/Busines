import { 
  CalendarHeart, 
  Users, 
  ListChecks, 
  MessageCircleHeart,
  Wallet,
  MapPin 
} from "lucide-react";

const features = [
  {
    icon: CalendarHeart,
    title: "Cuenta Atrás",
    description: "Visualiza cuántos días faltan para tu gran día con un contador elegante y personalizable."
  },
  {
    icon: ListChecks,
    title: "Lista de Tareas",
    description: "Organiza todas las tareas pendientes con recordatorios para no olvidar ningún detalle."
  },
  {
    icon: Users,
    title: "Lista de Invitados",
    description: "Gestiona confirmaciones, menús especiales y distribución de mesas fácilmente."
  },
  {
    icon: Wallet,
    title: "Control de Presupuesto",
    description: "Mantén tus gastos bajo control con seguimiento de presupuesto en tiempo real."
  },
  {
    icon: MapPin,
    title: "Directorio de Proveedores",
    description: "Encuentra y compara los mejores profesionales cerca de ti."
  },
  {
    icon: MessageCircleHeart,
    title: "Inspiración",
    description: "Ideas y tendencias para que tu boda sea única e inolvidable."
  }
];

export const Features = () => {
  return (
    <section className="section-padding bg-gradient-to-b from-background to-secondary/30">
      <div className="container-wedding">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-champagne font-medium text-sm uppercase tracking-wider">
            Todo lo que necesitas
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-semibold mt-4 mb-6">
            Planifica cada detalle
          </h2>
          <p className="text-muted-foreground text-lg">
            Herramientas intuitivas diseñadas para que organizar tu boda sea un placer, no un estrés.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {features.map((feature, index) => (
            <div 
              key={feature.title}
              className="card-wedding p-8 group"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="w-14 h-14 rounded-2xl bg-champagne/10 flex items-center justify-center mb-6 group-hover:bg-champagne/20 transition-colors">
                <feature.icon className="w-7 h-7 text-champagne" />
              </div>
              <h3 className="text-xl font-serif font-semibold mb-3">
                {feature.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
