import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Newspaper, 
  Calendar, 
  ArrowRight,
  ExternalLink
} from "lucide-react";

interface Article {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  imageUrl: string;
  date: string;
  readTime: string;
  url: string;
}

// Sample wedding industry articles
const SAMPLE_ARTICLES: Article[] = [
  {
    id: "1",
    title: "Tendencias en decoración de bodas 2026",
    excerpt: "Descubre los estilos más demandados este año: desde el minimalismo elegante hasta las bodas botánicas con toques de color.",
    category: "Tendencias",
    imageUrl: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?w=600&h=400&fit=crop",
    date: "28 Ene 2026",
    readTime: "5 min",
    url: "#",
  },
  {
    id: "2",
    title: "Cómo elegir el catering perfecto",
    excerpt: "Guía completa para acertar con el servicio gastronómico de tu boda: desde el presupuesto hasta el menú ideal.",
    category: "Planificación",
    imageUrl: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=600&h=400&fit=crop",
    date: "25 Ene 2026",
    readTime: "8 min",
    url: "#",
  },
  {
    id: "3",
    title: "Vestidos de novia: lo que viene en primavera",
    excerpt: "Las colecciones de las principales diseñadoras apuestan por siluetas fluidas, escotes halter y telas vaporosas.",
    category: "Moda",
    imageUrl: "https://images.unsplash.com/photo-1519741497674-611481863552?w=600&h=400&fit=crop",
    date: "22 Ene 2026",
    readTime: "4 min",
    url: "#",
  },
  {
    id: "4",
    title: "Fotografía de boda: estilos y precios",
    excerpt: "Comparativa de los diferentes estilos fotográficos y qué puedes esperar según tu presupuesto.",
    category: "Fotografía",
    imageUrl: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=600&h=400&fit=crop",
    date: "20 Ene 2026",
    readTime: "6 min",
    url: "#",
  },
];

export function WeddingArticles() {
  return (
    <section id="articulos" className="section-padding bg-background">
      <div className="container-wedding">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 mb-4">
            <Newspaper className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Blog</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-serif font-semibold mb-4">
            Últimos artículos del sector
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Mantente al día con las últimas tendencias, consejos y novedades del mundo nupcial.
          </p>
        </div>

        {/* Articles Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SAMPLE_ARTICLES.map((article, index) => (
            <Card 
              key={article.id} 
              className="group overflow-hidden card-wedding h-full flex flex-col"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="relative aspect-[16/10] overflow-hidden">
                <img 
                  src={article.imageUrl} 
                  alt={article.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <Badge 
                  className="absolute top-3 left-3 bg-primary/90 hover:bg-primary"
                >
                  {article.category}
                </Badge>
              </div>
              <CardContent className="p-4 flex-1 flex flex-col">
                <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                  <Calendar className="w-3 h-3" />
                  <span>{article.date}</span>
                  <span>·</span>
                  <span>{article.readTime} lectura</span>
                </div>
                <h3 className="font-serif font-semibold mb-2 group-hover:text-primary transition-colors line-clamp-2">
                  {article.title}
                </h3>
                <p className="text-sm text-muted-foreground line-clamp-3 flex-1">
                  {article.excerpt}
                </p>
                <Button 
                  variant="link" 
                  className="p-0 h-auto mt-3 justify-start text-primary"
                  asChild
                >
                  <a href={article.url}>
                    Leer más
                    <ArrowRight className="w-3 h-3 ml-1" />
                  </a>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-10">
          <Button variant="outline" size="lg" className="rounded-full">
            Ver todos los artículos
            <ExternalLink className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </section>
  );
}
