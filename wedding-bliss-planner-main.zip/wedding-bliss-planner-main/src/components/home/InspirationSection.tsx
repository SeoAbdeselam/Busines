import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Sparkles, 
  Flower2, 
  Palette, 
  Shirt, 
  Cake, 
  Camera,
  ChevronRight
} from "lucide-react";

interface InspirationItem {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  tags: string[];
}

const INSPIRATION_CATEGORIES = [
  { id: "all", label: "Todo", icon: Sparkles },
  { id: "decoration", label: "Decoración", icon: Palette },
  { id: "flowers", label: "Flores", icon: Flower2 },
  { id: "dresses", label: "Vestidos", icon: Shirt },
  { id: "cake", label: "Tartas", icon: Cake },
  { id: "photography", label: "Fotografía", icon: Camera },
];

// Sample inspiration content
const SAMPLE_INSPIRATIONS: InspirationItem[] = [
  {
    id: "1",
    title: "Mesa imperial con flores silvestres",
    category: "decoration",
    imageUrl: "https://images.unsplash.com/photo-1519741497674-611481863552?w=600&h=400&fit=crop",
    tags: ["Romántico", "Rústico", "Verano"],
  },
  {
    id: "2",
    title: "Ramo de novia con eucalipto",
    category: "flowers",
    imageUrl: "https://images.unsplash.com/photo-1522057306606-8d84776e10b8?w=600&h=400&fit=crop",
    tags: ["Natural", "Elegante", "Verde"],
  },
  {
    id: "3",
    title: "Vestido minimalista de seda",
    category: "dresses",
    imageUrl: "https://images.unsplash.com/photo-1594552072238-b8a33785b261?w=600&h=400&fit=crop",
    tags: ["Minimalista", "Moderno", "Elegante"],
  },
  {
    id: "4",
    title: "Tarta naked con frutos rojos",
    category: "cake",
    imageUrl: "https://images.unsplash.com/photo-1535254973040-607b474cb50d?w=600&h=400&fit=crop",
    tags: ["Rústico", "Natural", "Delicioso"],
  },
  {
    id: "5",
    title: "Fotografía golden hour",
    category: "photography",
    imageUrl: "https://images.unsplash.com/photo-1606216794074-735e91aa2c92?w=600&h=400&fit=crop",
    tags: ["Romántico", "Atardecer", "Pareja"],
  },
  {
    id: "6",
    title: "Centro de mesa con velas",
    category: "decoration",
    imageUrl: "https://images.unsplash.com/photo-1478146059778-26028b07395a?w=600&h=400&fit=crop",
    tags: ["Elegante", "Íntimo", "Nocturno"],
  },
];

export function InspirationSection() {
  const [activeCategory, setActiveCategory] = useState("all");

  const filteredItems = activeCategory === "all" 
    ? SAMPLE_INSPIRATIONS 
    : SAMPLE_INSPIRATIONS.filter(item => item.category === activeCategory);

  return (
    <section id="inspiracion" className="section-padding bg-secondary/30">
      <div className="container-wedding">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 mb-4">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Inspiración</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-serif font-semibold mb-4">
            Ideas para tu boda perfecta
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Descubre las últimas tendencias y encuentra la inspiración que necesitas para crear el día de tus sueños.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {INSPIRATION_CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            return (
              <Button
                key={cat.id}
                variant={activeCategory === cat.id ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveCategory(cat.id)}
                className="rounded-full"
              >
                <Icon className="w-4 h-4 mr-2" />
                {cat.label}
              </Button>
            );
          })}
        </div>

        {/* Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item, index) => (
            <Card 
              key={item.id} 
              className="group overflow-hidden cursor-pointer card-wedding"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img 
                  src={item.imageUrl} 
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute bottom-4 left-4 right-4 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                  <h3 className="text-white font-serif font-semibold mb-2">
                    {item.title}
                  </h3>
                  <div className="flex flex-wrap gap-1">
                    {item.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs bg-white/20 text-white border-0">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-10">
          <Button variant="outline" size="lg" className="rounded-full">
            Ver más inspiración
            <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </section>
  );
}
