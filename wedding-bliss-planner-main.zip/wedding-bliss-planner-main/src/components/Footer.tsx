import { Heart } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="py-12 bg-secondary/50 border-t border-border/50">
      <div className="container-wedding">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <Heart className="w-6 h-6 text-champagne" fill="currentColor" />
            <span className="font-serif text-xl font-semibold">MiBoda</span>
          </div>

          {/* Links */}
          <nav className="flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
            <a href="/profesionales" className="hover:text-champagne transition-colors">Profesionales</a>
            <a href="/pro/auth" className="hover:text-champagne transition-colors">Área Profesional</a>
            <a href="#" className="hover:text-champagne transition-colors">Blog</a>
            <a href="#" className="hover:text-champagne transition-colors">Contacto</a>
            <a href="#" className="hover:text-champagne transition-colors">Privacidad</a>
          </nav>

          {/* Copyright */}
          <p className="text-sm text-muted-foreground">
            © 2025 MiBoda. Hecho con <Heart className="w-3 h-3 inline text-rose-gold" fill="currentColor" /> en España
          </p>
        </div>
      </div>
    </footer>
  );
};
