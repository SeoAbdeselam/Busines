import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  MapPin, 
  Star,
  CheckCircle2,
  Crown,
  Heart
} from "lucide-react";
import { getCategoryLabel, getCategoryIcon } from "@/lib/professionalCategories";

interface Professional {
  id: string;
  business_name: string;
  slug: string;
  description: string | null;
  primary_category: string;
  city: string | null;
  average_rating: number;
  total_reviews: number;
  is_verified: boolean;
  is_premium: boolean;
  logo_url: string | null;
  cover_image_url: string | null;
}

interface ProfessionalCardProps {
  professional: Professional;
}

export function ProfessionalCard({ professional }: ProfessionalCardProps) {
  const CategoryIcon = getCategoryIcon(professional.primary_category);
  
  return (
    <Link to={`/profesionales/${professional.slug}`}>
      <Card 
        className={`
          group overflow-hidden h-full transition-all duration-300 
          hover:shadow-xl hover:-translate-y-1
          ${professional.is_premium ? "ring-2 ring-amber-400/50 shadow-amber-100" : ""}
        `}
      >
        {/* Cover Image */}
        <div className="relative aspect-[4/3] overflow-hidden bg-gradient-to-br from-primary/20 to-blush/30">
          {professional.cover_image_url ? (
            <img 
              src={professional.cover_image_url} 
              alt={professional.business_name}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <CategoryIcon className="w-16 h-16 text-primary/30" />
            </div>
          )}
          
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {/* Badges */}
          <div className="absolute top-3 right-3 flex flex-col gap-2">
            {professional.is_premium && (
              <Badge className="bg-gradient-to-r from-amber-400 to-amber-500 text-white border-0 shadow-lg">
                <Crown className="w-3 h-3 mr-1" />
                Premium
              </Badge>
            )}
            {professional.is_verified && (
              <Badge className="bg-primary text-primary-foreground border-0 shadow-lg">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Verificado
              </Badge>
            )}
          </div>

          {/* Quick action */}
          <button 
            className="absolute top-3 left-3 p-2 rounded-full bg-white/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-white hover:scale-110"
            onClick={(e) => {
              e.preventDefault();
              // TODO: Add to favorites
            }}
          >
            <Heart className="w-4 h-4 text-rose-500" />
          </button>

          {/* Logo overlay */}
          {professional.logo_url && (
            <div className="absolute bottom-3 left-3 w-12 h-12 rounded-xl bg-white shadow-lg p-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <img 
                src={professional.logo_url} 
                alt=""
                className="w-full h-full object-cover rounded-lg"
              />
            </div>
          )}
        </div>

        {/* Content */}
        <CardContent className="p-4">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="font-serif font-semibold text-lg group-hover:text-primary transition-colors line-clamp-1">
              {professional.business_name}
            </h3>
            <div className="flex items-center gap-1 flex-shrink-0">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
              <span className="font-medium text-sm">
                {professional.average_rating?.toFixed(1) || "—"}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap mb-3">
            <Badge variant="outline" className="text-xs font-normal">
              <CategoryIcon className="w-3 h-3 mr-1" />
              {getCategoryLabel(professional.primary_category)}
            </Badge>
            {professional.city && (
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <MapPin className="w-3 h-3" />
                {professional.city}
              </span>
            )}
          </div>

          {professional.description && (
            <p className="text-sm text-muted-foreground line-clamp-2">
              {professional.description}
            </p>
          )}

          {professional.total_reviews > 0 && (
            <p className="text-xs text-muted-foreground mt-2">
              {professional.total_reviews} reseñas verificadas
            </p>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
