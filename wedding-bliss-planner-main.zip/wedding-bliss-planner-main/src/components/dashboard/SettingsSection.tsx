import { useState } from "react";
import { useWedding } from "@/contexts/WeddingContext";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Settings, Copy, Check, Calendar, MapPin, Save } from "lucide-react";

export function SettingsSection() {
  const { activeWedding, refreshWeddings } = useWedding();
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [codeCopied, setCodeCopied] = useState(false);
  const [formData, setFormData] = useState({
    name: activeWedding?.name || "",
    wedding_date: activeWedding?.wedding_date || "",
    location: activeWedding?.location || "",
    primary_color: activeWedding?.primary_color || "#C4A35A",
    secondary_color: activeWedding?.secondary_color || "#E8D4D4",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWedding) return;

    setLoading(true);

    const { error } = await supabase
      .from("weddings")
      .update({
        name: formData.name,
        wedding_date: formData.wedding_date || null,
        location: formData.location || null,
        primary_color: formData.primary_color,
        secondary_color: formData.secondary_color,
      })
      .eq("id", activeWedding.id);

    if (error) {
      toast({
        title: "Error",
        description: "No se pudieron guardar los cambios",
        variant: "destructive",
      });
    } else {
      toast({ title: "Cambios guardados" });
      refreshWeddings();
    }

    setLoading(false);
  };

  const copyWeddingCode = () => {
    if (activeWedding?.wedding_code) {
      navigator.clipboard.writeText(activeWedding.wedding_code);
      setCodeCopied(true);
      toast({
        title: "¡Código copiado!",
        description: "Comparte este código con tus invitados",
      });
      setTimeout(() => setCodeCopied(false), 2000);
    }
  };

  if (!activeWedding) return null;

  return (
    <div className="space-y-6 max-w-2xl">
      {/* Header */}
      <div>
        <h1 className="text-2xl lg:text-3xl font-serif font-bold">Ajustes</h1>
        <p className="text-muted-foreground">Configuración de tu boda</p>
      </div>

      {/* Wedding Code */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Código de Invitación</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            Comparte este código con tus invitados para que puedan acceder a la boda
          </p>
          <div className="flex items-center gap-3">
            <div className="flex-1 p-4 bg-secondary/50 rounded-lg text-center">
              <p className="text-2xl font-mono font-bold tracking-widest">
                {activeWedding.wedding_code}
              </p>
            </div>
            <Button variant="outline" onClick={copyWeddingCode}>
              {codeCopied ? (
                <Check className="w-4 h-4" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Wedding Details */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Datos de la Boda
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Nombre de la boda</label>
              <Input
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                required
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Fecha de la boda</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="date"
                  value={formData.wedding_date}
                  onChange={(e) =>
                    setFormData({ ...formData, wedding_date: e.target.value })
                  }
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Lugar</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={formData.location}
                  onChange={(e) =>
                    setFormData({ ...formData, location: e.target.value })
                  }
                  className="pl-10"
                  placeholder="Ej: Finca El Olivar, Madrid"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Color primario</label>
                <div className="flex gap-2">
                  <Input
                    type="color"
                    value={formData.primary_color}
                    onChange={(e) =>
                      setFormData({ ...formData, primary_color: e.target.value })
                    }
                    className="w-12 h-10 p-1 cursor-pointer"
                  />
                  <Input
                    value={formData.primary_color}
                    onChange={(e) =>
                      setFormData({ ...formData, primary_color: e.target.value })
                    }
                    className="flex-1"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Color secundario</label>
                <div className="flex gap-2">
                  <Input
                    type="color"
                    value={formData.secondary_color}
                    onChange={(e) =>
                      setFormData({ ...formData, secondary_color: e.target.value })
                    }
                    className="w-12 h-10 p-1 cursor-pointer"
                  />
                  <Input
                    value={formData.secondary_color}
                    onChange={(e) =>
                      setFormData({ ...formData, secondary_color: e.target.value })
                    }
                    className="flex-1"
                  />
                </div>
              </div>
            </div>

            <Button type="submit" disabled={loading}>
              <Save className="w-4 h-4 mr-2" />
              {loading ? "Guardando..." : "Guardar Cambios"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
