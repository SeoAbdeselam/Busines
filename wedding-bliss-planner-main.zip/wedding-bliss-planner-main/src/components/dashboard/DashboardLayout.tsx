import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useWedding } from "@/contexts/WeddingContext";
import { Button } from "@/components/ui/button";
import { 
  Heart, 
  Home, 
  Users, 
  Grid3X3, 
  Wallet, 
  Gift, 
  Bell, 
  Settings,
  LogOut,
  Menu,
  X,
  Plus,
  ChevronDown,
  CheckSquare,
  Briefcase
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface DashboardLayoutProps {
  children: React.ReactNode;
  activeSection: string;
  onSectionChange: (section: string) => void;
  onCreateWedding: () => void;
}

const navItems = [
  { id: "home", label: "Inicio", icon: Home },
  { id: "tasks", label: "Tareas", icon: CheckSquare },
  { id: "guests", label: "Invitados", icon: Users },
  { id: "tables", label: "Mesas", icon: Grid3X3 },
  { id: "budget", label: "Presupuesto", icon: Wallet },
  { id: "providers", label: "Proveedores", icon: Briefcase },
  { id: "gifts", label: "Regalos", icon: Gift },
  { id: "announcements", label: "Avisos", icon: Bell },
  { id: "settings", label: "Ajustes", icon: Settings },
];

export function DashboardLayout({
  children,
  activeSection,
  onSectionChange,
  onCreateWedding,
}: DashboardLayoutProps) {
  const { signOut } = useAuth();
  const { activeWedding, memberships, setActiveWedding } = useWedding();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = async () => {
    await signOut();
    navigate("/auth");
  };

  const handleNavClick = (id: string) => {
    onSectionChange(id);
    setSidebarOpen(false);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Header */}
      <header className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-card border-b border-border z-50 flex items-center justify-between px-4">
        <button
          onClick={() => setSidebarOpen(true)}
          className="p-2 hover:bg-secondary rounded-lg"
        >
          <Menu className="w-6 h-6" />
        </button>
        <div className="flex items-center gap-2">
          <Heart className="w-6 h-6 text-primary" fill="currentColor" />
          <span className="font-serif font-semibold">Loba Ball</span>
        </div>
        <div className="w-10" />
      </header>

      {/* Sidebar Overlay */}
      {sidebarOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full w-64 bg-card border-r border-border z-50 transform transition-transform duration-300 lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="h-16 flex items-center justify-between px-4 border-b border-border">
            <div className="flex items-center gap-2">
              <Heart className="w-6 h-6 text-primary" fill="currentColor" />
              <span className="font-serif font-semibold text-lg">Loba Ball</span>
            </div>
            <button
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden p-2 hover:bg-secondary rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Wedding Selector */}
          <div className="p-4 border-b border-border">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="w-full flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors">
                  <div className="text-left">
                    <p className="text-xs text-muted-foreground">Tu boda</p>
                    <p className="font-medium truncate">
                      {activeWedding?.name || "Seleccionar..."}
                    </p>
                  </div>
                  <ChevronDown className="w-4 h-4 text-muted-foreground" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                {memberships.map((m) => (
                  <DropdownMenuItem
                    key={m.id}
                    onClick={() => setActiveWedding(m.wedding)}
                    className={activeWedding?.id === m.wedding_id ? "bg-secondary" : ""}
                  >
                    {m.wedding.name}
                  </DropdownMenuItem>
                ))}
                <DropdownMenuItem onClick={onCreateWedding}>
                  <Plus className="w-4 h-4 mr-2" />
                  Nueva boda
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-secondary text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Logout */}
          <div className="p-4 border-t border-border">
            <Button
              variant="ghost"
              className="w-full justify-start text-muted-foreground"
              onClick={handleLogout}
            >
              <LogOut className="w-5 h-5 mr-3" />
              Cerrar sesión
            </Button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:ml-64 pt-16 lg:pt-0 min-h-screen">
        <div className="p-4 lg:p-8">{children}</div>
      </main>
    </div>
  );
}
