import { useEffect, useState } from "react";
import { useWedding } from "@/contexts/WeddingContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Plus, Wallet, Trash2, Edit2, CheckCircle2 } from "lucide-react";

interface BudgetItem {
  id: string;
  category: string;
  name: string;
  estimated_amount: number;
  actual_amount: number | null;
  is_paid: boolean;
  notes: string | null;
}

const CATEGORIES = [
  "Ceremonia",
  "Recepción",
  "Catering",
  "Fotografía",
  "Música",
  "Decoración",
  "Vestimenta",
  "Belleza",
  "Transporte",
  "Alojamiento",
  "Papelería",
  "Regalos",
  "Otros",
];

export function BudgetSection() {
  const { activeWedding } = useWedding();
  const { toast } = useToast();
  const [items, setItems] = useState<BudgetItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingItem, setEditingItem] = useState<BudgetItem | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>("all");

  useEffect(() => {
    if (activeWedding) {
      fetchItems();
    }
  }, [activeWedding]);

  const fetchItems = async () => {
    if (!activeWedding) return;

    const { data, error } = await supabase
      .from("budget_items")
      .select("*")
      .eq("wedding_id", activeWedding.id)
      .order("category");

    if (!error && data) {
      setItems(data);
    }
    setLoading(false);
  };

  const deleteItem = async (id: string) => {
    const { error } = await supabase.from("budget_items").delete().eq("id", id);

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo eliminar la partida",
        variant: "destructive",
      });
    } else {
      setItems(items.filter((i) => i.id !== id));
      toast({ title: "Partida eliminada" });
    }
  };

  const togglePaid = async (item: BudgetItem) => {
    const { error } = await supabase
      .from("budget_items")
      .update({ is_paid: !item.is_paid })
      .eq("id", item.id);

    if (!error) {
      setItems(items.map((i) => (i.id === item.id ? { ...i, is_paid: !i.is_paid } : i)));
    }
  };

  const filteredItems = filterCategory === "all"
    ? items
    : items.filter((i) => i.category === filterCategory);

  const stats = {
    totalEstimated: items.reduce((acc, i) => acc + Number(i.estimated_amount || 0), 0),
    totalActual: items.reduce((acc, i) => acc + Number(i.actual_amount || 0), 0),
    totalPaid: items.filter((i) => i.is_paid).reduce((acc, i) => acc + Number(i.actual_amount || 0), 0),
    remaining: 0,
  };
  stats.remaining = stats.totalEstimated - stats.totalActual;

  if (!activeWedding) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-serif font-bold">Presupuesto</h1>
          <p className="text-muted-foreground">Control de gastos de tu boda</p>
        </div>
        <Button onClick={() => setShowAddModal(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Nueva Partida
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-2xl font-bold">
              {stats.totalEstimated.toLocaleString("es-ES")} €
            </p>
            <p className="text-sm text-muted-foreground">Presupuesto total</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-2xl font-bold text-primary">
              {stats.totalActual.toLocaleString("es-ES")} €
            </p>
            <p className="text-sm text-muted-foreground">Gasto real</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-2xl font-bold text-green-600">
              {stats.totalPaid.toLocaleString("es-ES")} €
            </p>
            <p className="text-sm text-muted-foreground">Ya pagado</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className={`text-2xl font-bold ${stats.remaining >= 0 ? "text-primary" : "text-red-600"}`}>
              {stats.remaining.toLocaleString("es-ES")} €
            </p>
            <p className="text-sm text-muted-foreground">
              {stats.remaining >= 0 ? "Restante" : "Excedido"}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Progress Bar */}
      <Card>
        <CardContent className="pt-4 pb-4">
          <div className="flex justify-between mb-2">
            <span className="text-sm text-muted-foreground">Progreso del gasto</span>
            <span className="text-sm font-medium">
              {Math.round((stats.totalActual / stats.totalEstimated) * 100 || 0)}%
            </span>
          </div>
          <div className="h-3 bg-secondary rounded-full overflow-hidden">
            <div
              className={`h-full transition-all ${
                stats.totalActual > stats.totalEstimated ? "bg-red-500" : "bg-primary"
              }`}
              style={{
                width: `${Math.min((stats.totalActual / stats.totalEstimated) * 100 || 0, 100)}%`,
              }}
            />
          </div>
        </CardContent>
      </Card>

      {/* Filter */}
      <Select value={filterCategory} onValueChange={setFilterCategory}>
        <SelectTrigger className="w-[200px]">
          <SelectValue placeholder="Filtrar por categoría" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Todas las categorías</SelectItem>
          {CATEGORIES.map((cat) => (
            <SelectItem key={cat} value={cat}>
              {cat}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Items List */}
      <div className="space-y-2">
        {filteredItems.map((item) => (
          <Card key={item.id} className={item.is_paid ? "border-green-500/30 bg-green-50/30" : ""}>
            <CardContent className="py-4">
              <div className="flex items-center justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium">{item.name}</p>
                    <span className="text-xs bg-secondary px-2 py-0.5 rounded">
                      {item.category}
                    </span>
                    {item.is_paid && (
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                    )}
                  </div>
                  <div className="flex gap-4 text-sm text-muted-foreground mt-1">
                    <span>Estimado: {Number(item.estimated_amount).toLocaleString("es-ES")} €</span>
                    <span>Real: {Number(item.actual_amount || 0).toLocaleString("es-ES")} €</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    variant={item.is_paid ? "default" : "outline"}
                    size="sm"
                    onClick={() => togglePaid(item)}
                  >
                    {item.is_paid ? "Pagado" : "Marcar pagado"}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setEditingItem(item)}
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteItem(item.id)}
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredItems.length === 0 && !loading && (
          <div className="text-center py-12">
            <Wallet className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No hay partidas de presupuesto</p>
            <Button className="mt-4" onClick={() => setShowAddModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Añadir primera partida
            </Button>
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      <BudgetModal
        open={showAddModal || !!editingItem}
        onOpenChange={(open) => {
          if (!open) {
            setShowAddModal(false);
            setEditingItem(null);
          }
        }}
        weddingId={activeWedding.id}
        item={editingItem}
        onSuccess={() => {
          fetchItems();
          setShowAddModal(false);
          setEditingItem(null);
        }}
      />
    </div>
  );
}

function BudgetModal({
  open,
  onOpenChange,
  weddingId,
  item,
  onSuccess,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  weddingId: string;
  item?: BudgetItem | null;
  onSuccess: () => void;
}) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: item?.name || "",
    category: item?.category || CATEGORIES[0],
    estimated_amount: item?.estimated_amount || 0,
    actual_amount: item?.actual_amount || 0,
    notes: item?.notes || "",
  });

  useEffect(() => {
    if (item) {
      setFormData({
        name: item.name,
        category: item.category,
        estimated_amount: item.estimated_amount,
        actual_amount: item.actual_amount || 0,
        notes: item.notes || "",
      });
    } else {
      setFormData({
        name: "",
        category: CATEGORIES[0],
        estimated_amount: 0,
        actual_amount: 0,
        notes: "",
      });
    }
  }, [item]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const payload = {
      ...formData,
      wedding_id: weddingId,
      notes: formData.notes || null,
    };

    let error;
    if (item) {
      const { error: updateError } = await supabase
        .from("budget_items")
        .update(payload)
        .eq("id", item.id);
      error = updateError;
    } else {
      const { error: insertError } = await supabase.from("budget_items").insert(payload);
      error = insertError;
    }

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo guardar la partida",
        variant: "destructive",
      });
    } else {
      toast({ title: item ? "Partida actualizada" : "Partida creada" });
      onSuccess();
    }

    setLoading(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{item ? "Editar Partida" : "Nueva Partida"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Nombre *</label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Ej: Fotógrafo, Flores..."
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Categoría</label>
            <Select
              value={formData.category}
              onValueChange={(value) => setFormData({ ...formData, category: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Presupuesto estimado (€)</label>
              <Input
                type="number"
                min="0"
                step="0.01"
                value={formData.estimated_amount}
                onChange={(e) =>
                  setFormData({ ...formData, estimated_amount: parseFloat(e.target.value) || 0 })
                }
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Gasto real (€)</label>
              <Input
                type="number"
                min="0"
                step="0.01"
                value={formData.actual_amount}
                onChange={(e) =>
                  setFormData({ ...formData, actual_amount: parseFloat(e.target.value) || 0 })
                }
              />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Notas</label>
            <Input
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Notas adicionales..."
            />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Guardando..." : item ? "Guardar Cambios" : "Crear Partida"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
