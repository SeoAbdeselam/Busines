import { useState, useEffect, useCallback } from "react";
import { useWedding } from "@/contexts/WeddingContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, LayoutGrid, List } from "lucide-react";

import { SeatingCanvas } from "./SeatingCanvas";
import { GuestList } from "./GuestList";
import { TableDetails } from "./TableDetails";
import { ValidationPanel } from "./ValidationPanel";
import { WeddingTable, Guest, TableWithGuests, ValidationError } from "./types";

export function SeatingPlanner() {
  const { activeWedding } = useWedding();
  const { toast } = useToast();

  const [tables, setTables] = useState<WeddingTable[]>([]);
  const [guests, setGuests] = useState<Guest[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTableId, setSelectedTableId] = useState<string | null>(null);
  const [guestFilter, setGuestFilter] = useState<"all" | "unassigned" | "confirmed" | "pending">("all");
  const [showAddTableModal, setShowAddTableModal] = useState(false);
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]);
  const [isValidating, setIsValidating] = useState(false);
  const [viewMode, setViewMode] = useState<"canvas" | "list">("canvas");

  // Form state for new table
  const [newTable, setNewTable] = useState({
    name: "",
    capacity: 8,
    table_type: "round" as "round" | "rectangular" | "imperial",
  });

  useEffect(() => {
    if (activeWedding) {
      fetchData();
    }
  }, [activeWedding]);

  const fetchData = async () => {
    if (!activeWedding) return;
    setLoading(true);

    const [tablesRes, guestsRes] = await Promise.all([
      supabase
        .from("wedding_tables")
        .select("*")
        .eq("wedding_id", activeWedding.id)
        .order("name"),
      supabase
        .from("guests")
        .select("id, name, table_id, rsvp_status")
        .eq("wedding_id", activeWedding.id),
    ]);

    if (!tablesRes.error) setTables(tablesRes.data || []);
    if (!guestsRes.error) setGuests(guestsRes.data || []);
    setLoading(false);
  };

  const tablesWithGuests: TableWithGuests[] = tables.map((table) => ({
    ...table,
    guests: guests.filter((g) => g.table_id === table.id),
  }));

  const selectedTable = tablesWithGuests.find((t) => t.id === selectedTableId);

  const handleCreateTable = async () => {
    if (!activeWedding || !newTable.name.trim()) return;

    // Calculate position for new table
    const existingCount = tables.length;
    const row = Math.floor(existingCount / 4);
    const col = existingCount % 4;
    const position_x = 100 + col * 180;
    const position_y = 100 + row * 180;

    const { data, error } = await supabase
      .from("wedding_tables")
      .insert({
        ...newTable,
        wedding_id: activeWedding.id,
        position_x,
        position_y,
      })
      .select()
      .single();

    if (error) {
      toast({ title: "Error", description: "No se pudo crear la mesa", variant: "destructive" });
    } else {
      setTables([...tables, data]);
      setShowAddTableModal(false);
      setNewTable({ name: "", capacity: 8, table_type: "round" });
      toast({ title: "Mesa creada" });
    }
  };

  const handleUpdateTable = async (tableId: string, updates: Partial<WeddingTable>) => {
    const { error } = await supabase
      .from("wedding_tables")
      .update(updates)
      .eq("id", tableId);

    if (!error) {
      setTables(tables.map((t) => (t.id === tableId ? { ...t, ...updates } : t)));
    }
  };

  const handleDeleteTable = async (tableId: string) => {
    // Unassign all guests first
    await supabase
      .from("guests")
      .update({ table_id: null })
      .eq("table_id", tableId);

    const { error } = await supabase
      .from("wedding_tables")
      .delete()
      .eq("id", tableId);

    if (!error) {
      setTables(tables.filter((t) => t.id !== tableId));
      setGuests(guests.map((g) => (g.table_id === tableId ? { ...g, table_id: null } : g)));
      setSelectedTableId(null);
      toast({ title: "Mesa eliminada" });
    }
  };

  const handleAssignGuest = async (guestId: string, tableId: string) => {
    const { error } = await supabase
      .from("guests")
      .update({ table_id: tableId })
      .eq("id", guestId);

    if (!error) {
      setGuests(guests.map((g) => (g.id === guestId ? { ...g, table_id: tableId } : g)));
      toast({ title: "Invitado asignado" });
    }
  };

  const handleRemoveGuest = async (guestId: string) => {
    const { error } = await supabase
      .from("guests")
      .update({ table_id: null })
      .eq("id", guestId);

    if (!error) {
      setGuests(guests.map((g) => (g.id === guestId ? { ...g, table_id: null } : g)));
    }
  };

  const handleMoveTable = useCallback(async (tableId: string, x: number, y: number) => {
    // Optimistic update
    setTables((prev) =>
      prev.map((t) => (t.id === tableId ? { ...t, position_x: x, position_y: y } : t))
    );

    // Debounced save
    await supabase
      .from("wedding_tables")
      .update({ position_x: x, position_y: y })
      .eq("id", tableId);
  }, []);

  const handleValidate = () => {
    setIsValidating(true);
    const errors: ValidationError[] = [];

    // Check overcapacity
    tablesWithGuests.forEach((table) => {
      if (table.guests.length > table.capacity) {
        errors.push({
          type: "overcapacity",
          message: `${table.name} tiene ${table.guests.length} invitados pero solo capacidad para ${table.capacity}`,
          tableId: table.id,
        });
      }
    });

    // Check unassigned confirmed guests
    const unassignedConfirmed = guests.filter(
      (g) => !g.table_id && g.rsvp_status === "confirmed"
    );
    if (unassignedConfirmed.length > 0) {
      errors.push({
        type: "unassigned",
        message: `${unassignedConfirmed.length} invitado(s) confirmado(s) sin mesa asignada`,
      });
    }

    // Check duplicates (shouldn't happen with our logic, but safety check)
    const assignedGuestIds = guests.filter((g) => g.table_id).map((g) => g.id);
    const duplicates = assignedGuestIds.filter(
      (id, index) => assignedGuestIds.indexOf(id) !== index
    );
    if (duplicates.length > 0) {
      errors.push({
        type: "duplicate",
        message: "Hay invitados asignados a múltiples mesas",
      });
    }

    setValidationErrors(errors);
    setIsValidating(false);

    if (errors.length === 0) {
      toast({ title: "¡Perfecto!", description: "La distribución es correcta" });
    }
  };

  if (!activeWedding) return null;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[600px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Cargando mesas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-serif font-bold">Distribución de Mesas</h1>
          <p className="text-muted-foreground">
            {tables.length} mesas · {guests.filter((g) => g.table_id).length}/{guests.length} invitados asignados
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex border rounded-lg overflow-hidden">
            <Button
              variant={viewMode === "canvas" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("canvas")}
              className="rounded-none"
            >
              <LayoutGrid className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("list")}
              className="rounded-none"
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
          <Button onClick={() => setShowAddTableModal(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Nueva Mesa
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex border rounded-lg overflow-hidden bg-card">
        {viewMode === "canvas" ? (
          <>
            <SeatingCanvas
              tables={tablesWithGuests}
              selectedTableId={selectedTableId}
              onSelectTable={setSelectedTableId}
              onAssignGuest={handleAssignGuest}
              onMoveTable={handleMoveTable}
            />

            {selectedTable ? (
              <TableDetails
                table={selectedTable}
                onUpdate={(data) => handleUpdateTable(selectedTable.id, data)}
                onDelete={() => handleDeleteTable(selectedTable.id)}
                onRemoveGuest={handleRemoveGuest}
                onClose={() => setSelectedTableId(null)}
              />
            ) : (
              <GuestList
                guests={guests}
                onGuestDragStart={() => {}}
                filter={guestFilter}
                onFilterChange={setGuestFilter}
              />
            )}
          </>
        ) : (
          // List view - fallback to old TablesSection style
          <div className="flex-1 p-4 overflow-auto">
            <p className="text-muted-foreground text-center py-8">
              Vista de lista disponible próximamente
            </p>
          </div>
        )}
      </div>

      {/* Validation Panel */}
      <ValidationPanel
        errors={validationErrors}
        onValidate={handleValidate}
        isValidating={isValidating}
      />

      {/* Add Table Modal */}
      <Dialog open={showAddTableModal} onOpenChange={setShowAddTableModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nueva Mesa</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Nombre</label>
              <Input
                value={newTable.name}
                onChange={(e) => setNewTable({ ...newTable, name: e.target.value })}
                placeholder="Ej: Mesa 1, Mesa Familia..."
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Tipo de Mesa</label>
              <Select
                value={newTable.table_type}
                onValueChange={(value: "round" | "rectangular" | "imperial") =>
                  setNewTable({ ...newTable, table_type: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="round">Redonda</SelectItem>
                  <SelectItem value="rectangular">Rectangular</SelectItem>
                  <SelectItem value="imperial">Imperial</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Capacidad</label>
              <Input
                type="number"
                min={1}
                max={20}
                value={newTable.capacity}
                onChange={(e) =>
                  setNewTable({ ...newTable, capacity: parseInt(e.target.value) || 8 })
                }
              />
            </div>
            <Button className="w-full" onClick={handleCreateTable} disabled={!newTable.name.trim()}>
              Crear Mesa
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
