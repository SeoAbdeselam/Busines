export interface WeddingTable {
  id: string;
  name: string;
  capacity: number;
  table_type: "round" | "rectangular" | "imperial";
  position_x: number | null;
  position_y: number | null;
}

export interface Guest {
  id: string;
  name: string;
  table_id: string | null;
  rsvp_status: "pending" | "confirmed" | "declined";
}

export interface TableWithGuests extends WeddingTable {
  guests: Guest[];
}

export interface DragItem {
  type: "guest" | "table";
  id: string;
  name: string;
}

export interface CanvasPosition {
  x: number;
  y: number;
  scale: number;
}

export interface ValidationError {
  type: "duplicate" | "overcapacity" | "unassigned";
  message: string;
  tableId?: string;
  guestId?: string;
}
