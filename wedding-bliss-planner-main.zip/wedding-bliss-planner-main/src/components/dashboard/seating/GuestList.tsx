import { useState } from "react";
import { Guest } from "./types";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, User, Check, Clock, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface GuestListProps {
  guests: Guest[];
  onGuestDragStart: (guest: Guest) => void;
  filter: "all" | "unassigned" | "confirmed" | "pending";
  onFilterChange: (filter: "all" | "unassigned" | "confirmed" | "pending") => void;
}

export function GuestList({
  guests,
  onGuestDragStart,
  filter,
  onFilterChange,
}: GuestListProps) {
  const [search, setSearch] = useState("");

  const filteredGuests = guests.filter((guest) => {
    const matchesSearch = guest.name.toLowerCase().includes(search.toLowerCase());
    if (!matchesSearch) return false;

    switch (filter) {
      case "unassigned":
        return !guest.table_id;
      case "confirmed":
        return guest.rsvp_status === "confirmed";
      case "pending":
        return guest.rsvp_status === "pending";
      default:
        return true;
    }
  });

  const unassignedCount = guests.filter((g) => !g.table_id).length;
  const confirmedCount = guests.filter((g) => g.rsvp_status === "confirmed").length;
  const pendingCount = guests.filter((g) => g.rsvp_status === "pending").length;

  const getStatusIcon = (status: Guest["rsvp_status"]) => {
    switch (status) {
      case "confirmed":
        return <Check className="w-3 h-3 text-green-500" />;
      case "declined":
        return <X className="w-3 h-3 text-destructive" />;
      default:
        return <Clock className="w-3 h-3 text-amber-500" />;
    }
  };

  const handleDragStart = (e: React.DragEvent, guest: Guest) => {
    e.dataTransfer.setData("guestId", guest.id);
    e.dataTransfer.effectAllowed = "move";
    onGuestDragStart(guest);
  };

  return (
    <div className="w-72 bg-card border-l border-border h-full flex flex-col">
      <div className="p-4 border-b border-border">
        <h3 className="font-semibold mb-3">Invitados</h3>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Buscar..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      {/* Filters */}
      <div className="p-2 border-b border-border flex flex-wrap gap-1">
        <Badge
          variant={filter === "all" ? "default" : "outline"}
          className="cursor-pointer"
          onClick={() => onFilterChange("all")}
        >
          Todos ({guests.length})
        </Badge>
        <Badge
          variant={filter === "unassigned" ? "default" : "outline"}
          className={cn("cursor-pointer", unassignedCount > 0 && filter !== "unassigned" && "border-amber-500 text-amber-500")}
          onClick={() => onFilterChange("unassigned")}
        >
          Sin mesa ({unassignedCount})
        </Badge>
        <Badge
          variant={filter === "confirmed" ? "default" : "outline"}
          className="cursor-pointer"
          onClick={() => onFilterChange("confirmed")}
        >
          Confirmados ({confirmedCount})
        </Badge>
        <Badge
          variant={filter === "pending" ? "default" : "outline"}
          className="cursor-pointer"
          onClick={() => onFilterChange("pending")}
        >
          Pendientes ({pendingCount})
        </Badge>
      </div>

      {/* Guest List */}
      <div className="flex-1 overflow-y-auto p-2">
        {filteredGuests.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <User className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No hay invitados</p>
          </div>
        ) : (
          <div className="space-y-1">
            {filteredGuests.map((guest) => (
              <div
                key={guest.id}
                draggable
                onDragStart={(e) => handleDragStart(e, guest)}
                className={cn(
                  "flex items-center gap-2 p-2 rounded-lg cursor-grab active:cursor-grabbing transition-colors",
                  "hover:bg-secondary/80",
                  guest.table_id ? "bg-secondary/30" : "bg-secondary/60 border border-dashed border-amber-500/50"
                )}
              >
                {getStatusIcon(guest.rsvp_status)}
                <span className="flex-1 text-sm truncate">{guest.name}</span>
                {guest.table_id && (
                  <Badge variant="secondary" className="text-xs">
                    Asignado
                  </Badge>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
