import { ValidationError } from "./types";
import { AlertTriangle, CheckCircle, XCircle, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ValidationPanelProps {
  errors: ValidationError[];
  onValidate: () => void;
  isValidating: boolean;
}

export function ValidationPanel({ errors, onValidate, isValidating }: ValidationPanelProps) {
  const hasErrors = errors.length > 0;
  const criticalErrors = errors.filter((e) => e.type === "overcapacity" || e.type === "duplicate");
  const warnings = errors.filter((e) => e.type === "unassigned");

  const getIcon = (type: ValidationError["type"]) => {
    switch (type) {
      case "overcapacity":
      case "duplicate":
        return <XCircle className="w-4 h-4 text-destructive" />;
      case "unassigned":
        return <AlertTriangle className="w-4 h-4 text-amber-500" />;
    }
  };

  return (
    <div className="p-4 border-t border-border bg-card">
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-medium">Validación</h4>
        <Button size="sm" onClick={onValidate} disabled={isValidating}>
          {isValidating ? "Validando..." : "Validar Distribución"}
        </Button>
      </div>

      {errors.length === 0 ? (
        <div className="flex items-center gap-2 text-green-600 bg-green-500/10 p-3 rounded-lg">
          <CheckCircle className="w-5 h-5" />
          <span className="text-sm font-medium">¡Distribución correcta!</span>
        </div>
      ) : (
        <div className="space-y-2 max-h-40 overflow-y-auto">
          {criticalErrors.length > 0 && (
            <div className="text-xs font-medium text-destructive mb-1">
              Errores críticos ({criticalErrors.length})
            </div>
          )}
          {criticalErrors.map((error, i) => (
            <div
              key={`critical-${i}`}
              className="flex items-start gap-2 p-2 bg-destructive/10 rounded text-sm"
            >
              {getIcon(error.type)}
              <span>{error.message}</span>
            </div>
          ))}

          {warnings.length > 0 && (
            <div className="text-xs font-medium text-amber-600 mt-2 mb-1">
              Advertencias ({warnings.length})
            </div>
          )}
          {warnings.map((error, i) => (
            <div
              key={`warning-${i}`}
              className="flex items-start gap-2 p-2 bg-amber-500/10 rounded text-sm"
            >
              {getIcon(error.type)}
              <span>{error.message}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
