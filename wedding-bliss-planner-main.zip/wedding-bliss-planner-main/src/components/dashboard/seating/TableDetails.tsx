import { useState } from "react";
import { TableWithGuests, Guest } from "./types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Trash2, X, Edit2, Check, Users } from "lucide-react";
import { cn } from "@/lib/utils";

interface TableDetailsProps {
  table: TableWithGuests;
  onUpdate: (data: Partial<TableWithGuests>) => void;
  onDelete: () => void;
  onRemoveGuest: (guestId: string) => void;
  onClose: () => void;
}

export function TableDetails({
  table,
  onUpdate,
  onDelete,
  onRemoveGuest,
  onClose,
}: TableDetailsProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    name: table.name,
    capacity: table.capacity,
    table_type: table.table_type,
  });

  const handleSave = () => {
    onUpdate(editData);
    setIsEditing(false);
  };

  const occupancy = table.guests.length;
  const isFull = occupancy >= table.capacity;
  const isOverCapacity = occupancy > table.capacity;

  return (
    <div className="w-80 bg-card border-l border-border h-full flex flex-col">
      <div className="p-4 border-b border-border flex items-center justify-between">
        <h3 className="font-semibold">Detalles de Mesa</h3>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="w-4 h-4" />
        </Button>
      </div>

      <div className="p-4 space-y-4 flex-1 overflow-y-auto">
        {isEditing ? (
          <>
            <div className="space-y-2">
              <label className="text-sm font-medium">Nombre</label>
              <Input
                value={editData.name}
                onChange={(e) => setEditData({ ...editData, name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Capacidad</label>
              <Input
                type="number"
                min={1}
                max={20}
                value={editData.capacity}
                onChange={(e) =>
                  setEditData({ ...editData, capacity: parseInt(e.target.value) || 8 })
                }
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Tipo</label>
              <Select
                value={editData.table_type}
                onValueChange={(value: "round" | "rectangular" | "imperial") =>
                  setEditData({ ...editData, table_type: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="round">Redonda</SelectItem>
                  <SelectItem value="rectangular">Rectangular</SelectItem>
                  <SelectItem value="imperial">Imperial</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSave} className="flex-1">
                <Check className="w-4 h-4 mr-2" />
                Guardar
              </Button>
              <Button variant="outline" onClick={() => setIsEditing(false)}>
                Cancelar
              </Button>
            </div>
          </>
        ) : (
          <>
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xl font-semibold">{table.name}</h4>
                <Badge variant="secondary" className="mt-1">
                  {table.table_type === "round"
                    ? "Redonda"
                    : table.table_type === "rectangular"
                    ? "Rectangular"
                    : "Imperial"}
                </Badge>
              </div>
              <Button variant="outline" size="icon" onClick={() => setIsEditing(true)}>
                <Edit2 className="w-4 h-4" />
              </Button>
            </div>

            <div
              className={cn(
                "p-4 rounded-lg border",
                isOverCapacity
                  ? "bg-destructive/10 border-destructive"
                  : isFull
                  ? "bg-green-500/10 border-green-500"
                  : "bg-secondary/50 border-border"
              )}
            >
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                <span className="text-2xl font-bold">
                  {occupancy}/{table.capacity}
                </span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {isOverCapacity
                  ? "¡Excede la capacidad!"
                  : isFull
                  ? "Mesa completa"
                  : `${table.capacity - occupancy} asientos libres`}
              </p>
            </div>

            {/* Guests at this table */}
            <div>
              <h5 className="text-sm font-medium mb-2">Invitados en esta mesa</h5>
              {table.guests.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4 text-center border rounded-lg border-dashed">
                  Arrastra invitados aquí
                </p>
              ) : (
                <div className="space-y-1">
                  {table.guests.map((guest) => (
                    <div
                      key={guest.id}
                      className="flex items-center justify-between p-2 bg-secondary/50 rounded-lg"
                    >
                      <span className="text-sm truncate">{guest.name}</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => onRemoveGuest(guest.id)}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}
      </div>

      {!isEditing && (
        <div className="p-4 border-t border-border">
          <Button variant="destructive" className="w-full" onClick={onDelete}>
            <Trash2 className="w-4 h-4 mr-2" />
            Eliminar Mesa
          </Button>
        </div>
      )}
    </div>
  );
}
