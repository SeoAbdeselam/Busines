import { useState, useRef, useCallback } from "react";
import { TableWithGuests, CanvasPosition, Guest } from "./types";
import { TableShape } from "./TableShape";
import { Button } from "@/components/ui/button";
import { ZoomIn, ZoomOut, Maximize2, Move } from "lucide-react";

interface SeatingCanvasProps {
  tables: TableWithGuests[];
  selectedTableId: string | null;
  onSelectTable: (id: string | null) => void;
  onAssignGuest: (guestId: string, tableId: string) => void;
  onMoveTable: (tableId: string, x: number, y: number) => void;
}

export function SeatingCanvas({
  tables,
  selectedTableId,
  onSelectTable,
  onAssignGuest,
  onMoveTable,
}: SeatingCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState<CanvasPosition>({ x: 0, y: 0, scale: 1 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });
  const [dragOverTableId, setDragOverTableId] = useState<string | null>(null);
  const [draggingTableId, setDraggingTableId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  const handleZoom = (delta: number) => {
    setPosition((prev) => ({
      ...prev,
      scale: Math.max(0.5, Math.min(2, prev.scale + delta)),
    }));
  };

  const handleReset = () => {
    setPosition({ x: 0, y: 0, scale: 1 });
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 1 || (e.button === 0 && e.altKey)) {
      // Middle click or alt+click for panning
      setIsPanning(true);
      setPanStart({ x: e.clientX - position.x, y: e.clientY - position.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
      setPosition((prev) => ({
        ...prev,
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y,
      }));
    } else if (draggingTableId) {
      const rect = containerRef.current?.getBoundingClientRect();
      if (rect) {
        const x = (e.clientX - rect.left - position.x) / position.scale - dragOffset.x;
        const y = (e.clientY - rect.top - position.y) / position.scale - dragOffset.y;
        // Update position in real-time visually
        const table = tables.find((t) => t.id === draggingTableId);
        if (table) {
          onMoveTable(draggingTableId, Math.max(0, x), Math.max(0, y));
        }
      }
    }
  };

  const handleMouseUp = () => {
    setIsPanning(false);
    setDraggingTableId(null);
  };

  const handleTableMouseDown = (e: React.MouseEvent, tableId: string) => {
    e.stopPropagation();
    const table = tables.find((t) => t.id === tableId);
    if (!table) return;

    const rect = containerRef.current?.getBoundingClientRect();
    if (rect) {
      const x = (e.clientX - rect.left - position.x) / position.scale;
      const y = (e.clientY - rect.top - position.y) / position.scale;
      setDragOffset({
        x: x - (table.position_x ?? 100),
        y: y - (table.position_y ?? 100),
      });
      setDraggingTableId(tableId);
    }
  };

  const handleDragOver = (e: React.DragEvent, tableId: string) => {
    e.preventDefault();
    setDragOverTableId(tableId);
  };

  const handleDragLeave = () => {
    setDragOverTableId(null);
  };

  const handleDrop = (guestId: string, tableId: string) => {
    onAssignGuest(guestId, tableId);
    setDragOverTableId(null);
  };

  return (
    <div className="flex-1 relative bg-muted/30 overflow-hidden">
      {/* Controls */}
      <div className="absolute top-4 right-4 z-10 flex gap-2">
        <Button variant="secondary" size="icon" onClick={() => handleZoom(0.1)}>
          <ZoomIn className="w-4 h-4" />
        </Button>
        <Button variant="secondary" size="icon" onClick={() => handleZoom(-0.1)}>
          <ZoomOut className="w-4 h-4" />
        </Button>
        <Button variant="secondary" size="icon" onClick={handleReset}>
          <Maximize2 className="w-4 h-4" />
        </Button>
      </div>

      {/* Pan hint */}
      <div className="absolute bottom-4 left-4 z-10 flex items-center gap-2 text-xs text-muted-foreground bg-background/80 px-3 py-1.5 rounded-full">
        <Move className="w-3 h-3" />
        Alt + arrastrar para mover
      </div>

      {/* Canvas */}
      <div
        ref={containerRef}
        className="w-full h-full cursor-default"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onClick={() => onSelectTable(null)}
      >
        <div
          className="relative w-[2000px] h-[1500px] bg-[radial-gradient(circle,_var(--tw-gradient-stops))] from-background via-background to-muted/50"
          style={{
            transform: `translate(${position.x}px, ${position.y}px) scale(${position.scale})`,
            transformOrigin: "0 0",
          }}
        >
          {/* Grid pattern */}
          <div
            className="absolute inset-0 opacity-30"
            style={{
              backgroundImage: `
                linear-gradient(to right, hsl(var(--border)) 1px, transparent 1px),
                linear-gradient(to bottom, hsl(var(--border)) 1px, transparent 1px)
              `,
              backgroundSize: "50px 50px",
            }}
          />

          {/* Tables */}
          {tables.map((table) => (
            <div
              key={table.id}
              onMouseDown={(e) => handleTableMouseDown(e, table.id)}
              className={draggingTableId === table.id ? "cursor-grabbing" : "cursor-grab"}
            >
              <TableShape
                table={table}
                isSelected={selectedTableId === table.id}
                onSelect={() => onSelectTable(table.id)}
                onDrop={(guestId) => handleDrop(guestId, table.id)}
                isDragOver={dragOverTableId === table.id}
                onDragOver={(e) => handleDragOver(e, table.id)}
                onDragLeave={handleDragLeave}
              />
            </div>
          ))}

          {tables.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <p className="text-lg font-medium mb-2">No hay mesas</p>
                <p className="text-sm">Crea tu primera mesa para empezar</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
