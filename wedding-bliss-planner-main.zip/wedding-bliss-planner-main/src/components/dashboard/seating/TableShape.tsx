import { cn } from "@/lib/utils";
import { TableWithGuests } from "./types";
import { Users } from "lucide-react";

interface TableShapeProps {
  table: TableWithGuests;
  isSelected: boolean;
  onSelect: () => void;
  onDrop: (guestId: string) => void;
  isDragOver: boolean;
  onDragOver: (e: React.DragEvent) => void;
  onDragLeave: () => void;
}

export function TableShape({
  table,
  isSelected,
  onSelect,
  onDrop,
  isDragOver,
  onDragOver,
  onDragLeave,
}: TableShapeProps) {
  const occupancy = table.guests.length;
  const isFull = occupancy >= table.capacity;
  const isOverCapacity = occupancy > table.capacity;

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const guestId = e.dataTransfer.getData("guestId");
    if (guestId) {
      onDrop(guestId);
    }
  };

  const getStatusColor = () => {
    if (isOverCapacity) return "border-destructive bg-destructive/10";
    if (isFull) return "border-green-500 bg-green-500/10";
    if (occupancy > 0) return "border-amber-500 bg-amber-500/10";
    return "border-muted-foreground/30 bg-card";
  };

  const getTableShape = () => {
    switch (table.table_type) {
      case "rectangular":
        return "rounded-lg aspect-[2/1]";
      case "imperial":
        return "rounded-sm aspect-[3/1]";
      case "round":
      default:
        return "rounded-full aspect-square";
    }
  };

  const getTableSize = () => {
    const baseSize = Math.max(80, Math.min(120, table.capacity * 12));
    switch (table.table_type) {
      case "rectangular":
        return { width: baseSize * 1.5, height: baseSize * 0.75 };
      case "imperial":
        return { width: baseSize * 2, height: baseSize * 0.6 };
      case "round":
      default:
        return { width: baseSize, height: baseSize };
    }
  };

  const size = getTableSize();

  return (
    <div
      className={cn(
        "absolute cursor-pointer transition-all duration-200 border-2 flex flex-col items-center justify-center shadow-md hover:shadow-lg",
        getTableShape(),
        getStatusColor(),
        isSelected && "ring-2 ring-primary ring-offset-2",
        isDragOver && "ring-2 ring-primary scale-105"
      )}
      style={{
        left: table.position_x ?? 100,
        top: table.position_y ?? 100,
        width: size.width,
        height: size.height,
      }}
      onClick={onSelect}
      onDrop={handleDrop}
      onDragOver={onDragOver}
      onDragLeave={onDragLeave}
    >
      <span className="font-medium text-sm truncate max-w-[90%]">
        {table.name}
      </span>
      <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
        <Users className="w-3 h-3" />
        <span className={cn(isOverCapacity && "text-destructive font-bold")}>
          {occupancy}/{table.capacity}
        </span>
      </div>
    </div>
  );
}
