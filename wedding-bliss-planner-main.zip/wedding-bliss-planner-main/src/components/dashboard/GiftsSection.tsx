import { useEffect, useState } from "react";
import { useWedding } from "@/contexts/WeddingContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Plus, Gift, Trash2, Edit2 } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

interface GiftItem {
  id: string;
  guest_id: string | null;
  guest_group_id: string | null;
  description: string | null;
  amount: number | null;
  is_monetary: boolean;
  received_at: string | null;
  notes: string | null;
}

interface Guest {
  id: string;
  name: string;
}

interface GuestGroup {
  id: string;
  name: string;
}

export function GiftsSection() {
  const { activeWedding } = useWedding();
  const { toast } = useToast();
  const [gifts, setGifts] = useState<GiftItem[]>([]);
  const [guests, setGuests] = useState<Guest[]>([]);
  const [groups, setGroups] = useState<GuestGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingGift, setEditingGift] = useState<GiftItem | null>(null);

  useEffect(() => {
    if (activeWedding) {
      fetchGifts();
      fetchGuests();
      fetchGroups();
    }
  }, [activeWedding]);

  const fetchGifts = async () => {
    if (!activeWedding) return;

    const { data, error } = await supabase
      .from("gifts")
      .select("*")
      .eq("wedding_id", activeWedding.id)
      .order("received_at", { ascending: false });

    if (!error && data) {
      setGifts(data);
    }
    setLoading(false);
  };

  const fetchGuests = async () => {
    if (!activeWedding) return;

    const { data, error } = await supabase
      .from("guests")
      .select("id, name")
      .eq("wedding_id", activeWedding.id)
      .order("name");

    if (!error && data) {
      setGuests(data);
    }
  };

  const fetchGroups = async () => {
    if (!activeWedding) return;

    const { data, error } = await supabase
      .from("guest_groups")
      .select("id, name")
      .eq("wedding_id", activeWedding.id)
      .order("name");

    if (!error && data) {
      setGroups(data);
    }
  };

  const deleteGift = async (id: string) => {
    const { error } = await supabase.from("gifts").delete().eq("id", id);

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo eliminar el regalo",
        variant: "destructive",
      });
    } else {
      setGifts(gifts.filter((g) => g.id !== id));
      toast({ title: "Regalo eliminado" });
    }
  };

  const getGuestName = (guestId: string | null) => {
    if (!guestId) return null;
    return guests.find((g) => g.id === guestId)?.name;
  };

  const getGroupName = (groupId: string | null) => {
    if (!groupId) return null;
    return groups.find((g) => g.id === groupId)?.name;
  };

  const stats = {
    totalMoney: gifts
      .filter((g) => g.is_monetary)
      .reduce((acc, g) => acc + Number(g.amount || 0), 0),
    totalGifts: gifts.filter((g) => !g.is_monetary).length,
    totalItems: gifts.length,
  };

  if (!activeWedding) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-serif font-bold">Regalos</h1>
          <p className="text-muted-foreground">Registro de regalos y aportaciones</p>
        </div>
        <Button onClick={() => setShowAddModal(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Registrar Regalo
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-3xl font-bold text-primary">
              {stats.totalMoney.toLocaleString("es-ES")} €
            </p>
            <p className="text-sm text-muted-foreground">Total en dinero</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-2xl font-bold">{stats.totalGifts}</p>
            <p className="text-sm text-muted-foreground">Regalos físicos</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-2xl font-bold">{stats.totalItems}</p>
            <p className="text-sm text-muted-foreground">Total registros</p>
          </CardContent>
        </Card>
      </div>

      {/* Gifts List */}
      <div className="space-y-2">
        {gifts.map((gift) => {
          const guestName = getGuestName(gift.guest_id);
          const groupName = getGroupName(gift.guest_group_id);
          const fromName = guestName || groupName || "Anónimo";

          return (
            <Card key={gift.id}>
              <CardContent className="py-4">
                <div className="flex items-center justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <Gift className="w-4 h-4 text-primary" />
                      <p className="font-medium">{fromName}</p>
                      {gift.is_monetary && gift.amount && (
                        <span className="text-primary font-semibold">
                          {Number(gift.amount).toLocaleString("es-ES")} €
                        </span>
                      )}
                    </div>
                    {gift.description && (
                      <p className="text-sm text-muted-foreground mt-1">
                        {gift.description}
                      </p>
                    )}
                    {gift.received_at && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {format(new Date(gift.received_at), "d MMM, yyyy", { locale: es })}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setEditingGift(gift)}
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteGift(gift.id)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}

        {gifts.length === 0 && !loading && (
          <div className="text-center py-12">
            <Gift className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No hay regalos registrados</p>
            <Button className="mt-4" onClick={() => setShowAddModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Registrar primer regalo
            </Button>
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      <GiftModal
        open={showAddModal || !!editingGift}
        onOpenChange={(open) => {
          if (!open) {
            setShowAddModal(false);
            setEditingGift(null);
          }
        }}
        weddingId={activeWedding.id}
        gift={editingGift}
        guests={guests}
        groups={groups}
        onSuccess={() => {
          fetchGifts();
          setShowAddModal(false);
          setEditingGift(null);
        }}
      />
    </div>
  );
}

function GiftModal({
  open,
  onOpenChange,
  weddingId,
  gift,
  guests,
  groups,
  onSuccess,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  weddingId: string;
  gift?: GiftItem | null;
  guests: Guest[];
  groups: GuestGroup[];
  onSuccess: () => void;
}) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    guest_id: gift?.guest_id || "none",
    guest_group_id: gift?.guest_group_id || "none",
    description: gift?.description || "",
    amount: gift?.amount || 0,
    is_monetary: gift?.is_monetary ?? true,
    received_at: gift?.received_at || new Date().toISOString().split("T")[0],
    notes: gift?.notes || "",
  });

  useEffect(() => {
    if (gift) {
      setFormData({
        guest_id: gift.guest_id || "none",
        guest_group_id: gift.guest_group_id || "none",
        description: gift.description || "",
        amount: gift.amount || 0,
        is_monetary: gift.is_monetary,
        received_at: gift.received_at || new Date().toISOString().split("T")[0],
        notes: gift.notes || "",
      });
    } else {
      setFormData({
        guest_id: "none",
        guest_group_id: "none",
        description: "",
        amount: 0,
        is_monetary: true,
        received_at: new Date().toISOString().split("T")[0],
        notes: "",
      });
    }
  }, [gift]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const payload = {
      wedding_id: weddingId,
      guest_id: formData.guest_id && formData.guest_id !== "none" ? formData.guest_id : null,
      guest_group_id: formData.guest_group_id && formData.guest_group_id !== "none" ? formData.guest_group_id : null,
      description: formData.description || null,
      amount: formData.is_monetary ? formData.amount : null,
      is_monetary: formData.is_monetary,
      received_at: formData.received_at || null,
      notes: formData.notes || null,
    };

    let error;
    if (gift) {
      const { error: updateError } = await supabase
        .from("gifts")
        .update(payload)
        .eq("id", gift.id);
      error = updateError;
    } else {
      const { error: insertError } = await supabase.from("gifts").insert(payload);
      error = insertError;
    }

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo guardar el regalo",
        variant: "destructive",
      });
    } else {
      toast({ title: gift ? "Regalo actualizado" : "Regalo registrado" });
      onSuccess();
    }

    setLoading(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{gift ? "Editar Regalo" : "Registrar Regalo"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">De invitado</label>
            <Select
              value={formData.guest_id}
              onValueChange={(value) =>
                setFormData({ ...formData, guest_id: value, guest_group_id: "none" })
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar invitado..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Sin especificar</SelectItem>
                {guests.map((guest) => (
                  <SelectItem key={guest.id} value={guest.id}>
                    {guest.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">O de grupo</label>
            <Select
              value={formData.guest_group_id}
              onValueChange={(value) =>
                setFormData({ ...formData, guest_group_id: value, guest_id: "none" })
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar grupo..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Sin especificar</SelectItem>
                {groups.map((group) => (
                  <SelectItem key={group.id} value={group.id}>
                    {group.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Tipo de regalo</label>
            <Select
              value={formData.is_monetary ? "money" : "gift"}
              onValueChange={(value) =>
                setFormData({ ...formData, is_monetary: value === "money" })
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="money">Dinero</SelectItem>
                <SelectItem value="gift">Regalo físico</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {formData.is_monetary && (
            <div className="space-y-2">
              <label className="text-sm font-medium">Cantidad (€)</label>
              <Input
                type="number"
                min="0"
                step="0.01"
                value={formData.amount}
                onChange={(e) =>
                  setFormData({ ...formData, amount: parseFloat(e.target.value) || 0 })
                }
              />
            </div>
          )}

          <div className="space-y-2">
            <label className="text-sm font-medium">Descripción</label>
            <Input
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder={formData.is_monetary ? "Sobre, transferencia..." : "Descripción del regalo"}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Fecha de recepción</label>
            <Input
              type="date"
              value={formData.received_at}
              onChange={(e) => setFormData({ ...formData, received_at: e.target.value })}
            />
          </div>

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Guardando..." : gift ? "Guardar Cambios" : "Registrar Regalo"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
