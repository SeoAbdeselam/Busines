import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useWedding } from "@/contexts/WeddingContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus, Bell, Trash2, Edit2, Megaphone } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

interface Announcement {
  id: string;
  title: string;
  content: string;
  is_global: boolean;
  target_group_id: string | null;
  created_by: string;
  created_at: string;
}

export function AnnouncementsSection() {
  const { user } = useAuth();
  const { activeWedding } = useWedding();
  const { toast } = useToast();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);

  useEffect(() => {
    if (activeWedding) {
      fetchAnnouncements();
    }
  }, [activeWedding]);

  const fetchAnnouncements = async () => {
    if (!activeWedding) return;

    const { data, error } = await supabase
      .from("announcements")
      .select("*")
      .eq("wedding_id", activeWedding.id)
      .order("created_at", { ascending: false });

    if (!error && data) {
      setAnnouncements(data);
    }
    setLoading(false);
  };

  const deleteAnnouncement = async (id: string) => {
    const { error } = await supabase.from("announcements").delete().eq("id", id);

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo eliminar el aviso",
        variant: "destructive",
      });
    } else {
      setAnnouncements(announcements.filter((a) => a.id !== id));
      toast({ title: "Aviso eliminado" });
    }
  };

  if (!activeWedding) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-serif font-bold">Avisos</h1>
          <p className="text-muted-foreground">Comunicación con tus invitados</p>
        </div>
        <Button onClick={() => setShowAddModal(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Nuevo Aviso
        </Button>
      </div>

      {/* Announcements List */}
      <div className="space-y-4">
        {announcements.map((announcement) => (
          <Card key={announcement.id}>
            <CardContent className="py-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Megaphone className="w-5 h-5 text-primary" />
                    <h3 className="font-semibold text-lg">{announcement.title}</h3>
                  </div>
                  <p className="text-muted-foreground whitespace-pre-wrap">
                    {announcement.content}
                  </p>
                  <p className="text-xs text-muted-foreground mt-3">
                    Publicado el {format(new Date(announcement.created_at), "d MMM, yyyy 'a las' HH:mm", { locale: es })}
                  </p>
                </div>

                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setEditingAnnouncement(announcement)}
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteAnnouncement(announcement.id)}
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {announcements.length === 0 && !loading && (
          <div className="text-center py-12">
            <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No hay avisos publicados</p>
            <p className="text-sm text-muted-foreground mb-4">
              Publica avisos para comunicarte con tus invitados
            </p>
            <Button onClick={() => setShowAddModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Crear primer aviso
            </Button>
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      <AnnouncementModal
        open={showAddModal || !!editingAnnouncement}
        onOpenChange={(open) => {
          if (!open) {
            setShowAddModal(false);
            setEditingAnnouncement(null);
          }
        }}
        weddingId={activeWedding.id}
        userId={user?.id || ""}
        announcement={editingAnnouncement}
        onSuccess={() => {
          fetchAnnouncements();
          setShowAddModal(false);
          setEditingAnnouncement(null);
        }}
      />
    </div>
  );
}

function AnnouncementModal({
  open,
  onOpenChange,
  weddingId,
  userId,
  announcement,
  onSuccess,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  weddingId: string;
  userId: string;
  announcement?: Announcement | null;
  onSuccess: () => void;
}) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: announcement?.title || "",
    content: announcement?.content || "",
  });

  useEffect(() => {
    if (announcement) {
      setFormData({
        title: announcement.title,
        content: announcement.content,
      });
    } else {
      setFormData({ title: "", content: "" });
    }
  }, [announcement]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const payload = {
      ...formData,
      wedding_id: weddingId,
      created_by: userId,
      is_global: true,
    };

    let error;
    if (announcement) {
      const { error: updateError } = await supabase
        .from("announcements")
        .update({ title: formData.title, content: formData.content })
        .eq("id", announcement.id);
      error = updateError;
    } else {
      const { error: insertError } = await supabase.from("announcements").insert(payload);
      error = insertError;
    }

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo guardar el aviso",
        variant: "destructive",
      });
    } else {
      toast({ title: announcement ? "Aviso actualizado" : "Aviso publicado" });
      onSuccess();
    }

    setLoading(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{announcement ? "Editar Aviso" : "Nuevo Aviso"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Título *</label>
            <Input
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="Ej: Recordatorio de confirmación..."
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Contenido *</label>
            <Textarea
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              placeholder="Escribe el mensaje para tus invitados..."
              rows={5}
              required
            />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Guardando..." : announcement ? "Guardar Cambios" : "Publicar Aviso"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
