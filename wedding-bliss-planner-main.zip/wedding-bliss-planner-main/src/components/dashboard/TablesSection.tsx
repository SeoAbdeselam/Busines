import { useEffect, useState } from "react";
import { useWedding } from "@/contexts/WeddingContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Plus, Grid3X3, Trash2, Users, Edit2 } from "lucide-react";

interface WeddingTable {
  id: string;
  name: string;
  capacity: number;
}

interface Guest {
  id: string;
  name: string;
  table_id: string | null;
  rsvp_status: "pending" | "confirmed" | "declined";
}

export function TablesSection() {
  const { activeWedding } = useWedding();
  const { toast } = useToast();
  const [tables, setTables] = useState<WeddingTable[]>([]);
  const [guests, setGuests] = useState<Guest[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingTable, setEditingTable] = useState<WeddingTable | null>(null);

  useEffect(() => {
    if (activeWedding) {
      fetchTables();
      fetchGuests();
    }
  }, [activeWedding]);

  const fetchTables = async () => {
    if (!activeWedding) return;

    const { data, error } = await supabase
      .from("wedding_tables")
      .select("*")
      .eq("wedding_id", activeWedding.id)
      .order("name");

    if (!error && data) {
      setTables(data);
    }
    setLoading(false);
  };

  const fetchGuests = async () => {
    if (!activeWedding) return;

    const { data, error } = await supabase
      .from("guests")
      .select("id, name, table_id, rsvp_status")
      .eq("wedding_id", activeWedding.id)
      .eq("rsvp_status", "confirmed");

    if (!error && data) {
      setGuests(data);
    }
  };

  const deleteTable = async (id: string) => {
    const { error } = await supabase.from("wedding_tables").delete().eq("id", id);

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo eliminar la mesa",
        variant: "destructive",
      });
    } else {
      setTables(tables.filter((t) => t.id !== id));
      toast({ title: "Mesa eliminada" });
    }
  };

  const assignGuestToTable = async (guestId: string, tableId: string | null) => {
    const { error } = await supabase
      .from("guests")
      .update({ table_id: tableId })
      .eq("id", guestId);

    if (!error) {
      setGuests(guests.map((g) => (g.id === guestId ? { ...g, table_id: tableId } : g)));
    }
  };

  const getGuestsForTable = (tableId: string) =>
    guests.filter((g) => g.table_id === tableId);

  const unassignedGuests = guests.filter((g) => !g.table_id);

  if (!activeWedding) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-serif font-bold">Mesas</h1>
          <p className="text-muted-foreground">Organiza la distribución de invitados</p>
        </div>
        <Button onClick={() => setShowAddModal(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Nueva Mesa
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-2xl font-bold">{tables.length}</p>
            <p className="text-sm text-muted-foreground">Mesas totales</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-2xl font-bold">
              {tables.reduce((acc, t) => acc + t.capacity, 0)}
            </p>
            <p className="text-sm text-muted-foreground">Capacidad total</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-2xl font-bold text-primary">
              {guests.length - unassignedGuests.length}
            </p>
            <p className="text-sm text-muted-foreground">Invitados asignados</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-2xl font-bold text-amber-600">
              {unassignedGuests.length}
            </p>
            <p className="text-sm text-muted-foreground">Sin asignar</p>
          </CardContent>
        </Card>
      </div>

      {/* Tables Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {tables.map((table) => {
          const tableGuests = getGuestsForTable(table.id);
          const occupancy = tableGuests.length;
          const isFull = occupancy >= table.capacity;

          return (
            <Card key={table.id} className={isFull ? "border-green-500/50" : ""}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Grid3X3 className="w-5 h-5" />
                    {table.name}
                  </CardTitle>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setEditingTable(table)}
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteTable(table.id)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </div>
                <p className={`text-sm ${isFull ? "text-green-600" : "text-muted-foreground"}`}>
                  {occupancy} / {table.capacity} ocupados
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {tableGuests.map((guest) => (
                    <div
                      key={guest.id}
                      className="flex items-center justify-between p-2 bg-secondary/50 rounded"
                    >
                      <span className="text-sm">{guest.name}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => assignGuestToTable(guest.id, null)}
                        className="text-xs h-7"
                      >
                        Quitar
                      </Button>
                    </div>
                  ))}
                  {!isFull && (
                    <Select
                      onValueChange={(value) => assignGuestToTable(value, table.id)}
                    >
                      <SelectTrigger className="h-9">
                        <SelectValue placeholder="Añadir invitado..." />
                      </SelectTrigger>
                      <SelectContent>
                        {unassignedGuests.map((guest) => (
                          <SelectItem key={guest.id} value={guest.id}>
                            {guest.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}

        {tables.length === 0 && !loading && (
          <div className="col-span-full text-center py-12">
            <Grid3X3 className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No hay mesas creadas</p>
            <Button className="mt-4" onClick={() => setShowAddModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Crear primera mesa
            </Button>
          </div>
        )}
      </div>

      {/* Unassigned Guests */}
      {unassignedGuests.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Invitados sin mesa ({unassignedGuests.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {unassignedGuests.map((guest) => (
                <span
                  key={guest.id}
                  className="px-3 py-1 bg-secondary rounded-full text-sm"
                >
                  {guest.name}
                </span>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add/Edit Table Modal */}
      <TableModal
        open={showAddModal || !!editingTable}
        onOpenChange={(open) => {
          if (!open) {
            setShowAddModal(false);
            setEditingTable(null);
          }
        }}
        weddingId={activeWedding.id}
        table={editingTable}
        onSuccess={() => {
          fetchTables();
          setShowAddModal(false);
          setEditingTable(null);
        }}
      />
    </div>
  );
}

function TableModal({
  open,
  onOpenChange,
  weddingId,
  table,
  onSuccess,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  weddingId: string;
  table?: WeddingTable | null;
  onSuccess: () => void;
}) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: table?.name || "",
    capacity: table?.capacity || 8,
  });

  useEffect(() => {
    if (table) {
      setFormData({ name: table.name, capacity: table.capacity });
    } else {
      setFormData({ name: "", capacity: 8 });
    }
  }, [table]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    let error;
    if (table) {
      const { error: updateError } = await supabase
        .from("wedding_tables")
        .update(formData)
        .eq("id", table.id);
      error = updateError;
    } else {
      const { error: insertError } = await supabase
        .from("wedding_tables")
        .insert({ ...formData, wedding_id: weddingId });
      error = insertError;
    }

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo guardar la mesa",
        variant: "destructive",
      });
    } else {
      toast({ title: table ? "Mesa actualizada" : "Mesa creada" });
      onSuccess();
    }

    setLoading(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{table ? "Editar Mesa" : "Nueva Mesa"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Nombre</label>
            <Input
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
              placeholder="Ej: Mesa 1, Mesa Familia Novia..."
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Capacidad</label>
            <Input
              type="number"
              min="1"
              max="20"
              value={formData.capacity}
              onChange={(e) =>
                setFormData({ ...formData, capacity: parseInt(e.target.value) || 8 })
              }
            />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Guardando..." : table ? "Guardar Cambios" : "Crear Mesa"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
