import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useWedding } from "@/contexts/WeddingContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import {
  Users,
  CheckCircle2,
  Clock,
  DollarSign,
  Calendar,
  ExternalLink,
  MessageSquare,
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { getCategoryLabel, getCategoryIcon } from "@/lib/professionalCategories";

interface Contract {
  id: string;
  status: string;
  estimated_cost: number;
  actual_cost: number | null;
  service_date: string | null;
  contracted_at: string | null;
  professional: {
    id: string;
    business_name: string;
    slug: string;
    primary_category: string;
    logo_url: string | null;
  };
}

const STATUS_CONFIG = {
  interested: { label: "Interesado", color: "bg-blue-500" },
  contacted: { label: "Contactado", color: "bg-yellow-500" },
  contracted: { label: "Contratado", color: "bg-green-500" },
  completed: { label: "Completado", color: "bg-primary" },
  cancelled: { label: "Cancelado", color: "bg-destructive" },
};

export function ProvidersSection() {
  const { activeWedding } = useWedding();
  const { toast } = useToast();
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (activeWedding) {
      fetchContracts();
    }
  }, [activeWedding]);

  const fetchContracts = async () => {
    if (!activeWedding) return;

    try {
      const { data, error } = await supabase
        .from("professional_contracts")
        .select(`
          id,
          status,
          estimated_cost,
          actual_cost,
          service_date,
          contracted_at,
          professional:professionals(id, business_name, slug, primary_category, logo_url)
        `)
        .eq("wedding_id", activeWedding.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setContracts((data || []) as unknown as Contract[]);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const totalEstimated = contracts.reduce((sum, c) => sum + (c.estimated_cost || 0), 0);
  const contracted = contracts.filter(c => c.status === "contracted" || c.status === "completed");

  if (loading) {
    return <div className="animate-pulse">Cargando proveedores...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-serif font-semibold">Proveedores</h1>
          <p className="text-muted-foreground">
            Gestiona tus proveedores contratados
          </p>
        </div>
        <Link to="/profesionales">
          <Button>
            <Users className="w-4 h-4 mr-2" />
            Buscar proveedores
          </Button>
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{contracted.length}</p>
                <p className="text-xs text-muted-foreground">Contratados</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalEstimated.toLocaleString("es-ES")} €</p>
                <p className="text-xs text-muted-foreground">Presupuesto proveedores</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                <Clock className="w-5 h-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{contracts.length - contracted.length}</p>
                <p className="text-xs text-muted-foreground">Pendientes</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Provider list */}
      {contracts.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <Users className="w-12 h-12 text-muted-foreground mb-4" />
            <h3 className="font-medium mb-2">Sin proveedores todavía</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Busca y contrata proveedores para tu boda
            </p>
            <Link to="/profesionales">
              <Button>
                <Users className="w-4 h-4 mr-2" />
                Explorar proveedores
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {contracts.map((contract) => {
            const statusConfig = STATUS_CONFIG[contract.status as keyof typeof STATUS_CONFIG] || STATUS_CONFIG.interested;
            const CategoryIcon = getCategoryIcon(contract.professional.primary_category);

            return (
              <Card key={contract.id} className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    {/* Avatar */}
                    <div className="w-16 h-16 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      {contract.professional.logo_url ? (
                        <img
                          src={contract.professional.logo_url}
                          alt={contract.professional.business_name}
                          className="w-full h-full object-cover rounded-lg"
                        />
                      ) : (
                        <CategoryIcon className="w-8 h-8 text-primary" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-medium truncate">
                            {contract.professional.business_name}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {getCategoryLabel(contract.professional.primary_category)}
                          </p>
                        </div>
                        <Badge className={statusConfig.color}>
                          {statusConfig.label}
                        </Badge>
                      </div>

                      <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                        {contract.estimated_cost > 0 && (
                          <span className="flex items-center gap-1">
                            <DollarSign className="w-3 h-3" />
                            {contract.estimated_cost.toLocaleString("es-ES")} €
                          </span>
                        )}
                        {contract.service_date && (
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {format(new Date(contract.service_date), "dd MMM", { locale: es })}
                          </span>
                        )}
                      </div>

                      <div className="flex gap-2 mt-3">
                        <Link to={`/profesionales/${contract.professional.slug}`}>
                          <Button variant="outline" size="sm">
                            <ExternalLink className="w-3 h-3 mr-1" />
                            Ver perfil
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
