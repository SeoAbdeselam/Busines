import { useWedding } from "@/contexts/WeddingContext";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { CheckCircle2, AlertCircle, Calendar, MapPin, Users, ListTodo } from "lucide-react";

interface ProfileCompletenessAlertProps {
  stats: {
    hasWeddingDate: boolean;
    hasLocation: boolean;
    hasGuests: boolean;
    hasTasks: boolean;
    hasBudget: boolean;
  };
  onNavigate: (section: string) => void;
}

export function ProfileCompletenessAlert({ stats, onNavigate }: ProfileCompletenessAlertProps) {
  const { activeWedding } = useWedding();

  const completedItems = [
    stats.hasWeddingDate,
    stats.hasLocation,
    stats.hasGuests,
    stats.hasTasks,
  ].filter(Boolean).length;

  const totalItems = 4;
  const isComplete = completedItems === totalItems;

  if (isComplete) {
    return null;
  }

  const missingItems = [];
  if (!stats.hasWeddingDate) {
    missingItems.push({
      label: "Fecha de boda",
      icon: Calendar,
      action: "settings",
    });
  }
  if (!stats.hasLocation) {
    missingItems.push({
      label: "Ubicación del evento",
      icon: MapPin,
      action: "settings",
    });
  }
  if (!stats.hasGuests) {
    missingItems.push({
      label: "Lista de invitados",
      icon: Users,
      action: "guests",
    });
  }
  if (!stats.hasTasks) {
    missingItems.push({
      label: "Primera tarea",
      icon: ListTodo,
      action: "tasks",
    });
  }

  return (
    <Alert className="border-amber-500/50 bg-amber-50/50 dark:bg-amber-950/20">
      <AlertCircle className="h-5 w-5 text-amber-600" />
      <AlertTitle className="text-amber-800 dark:text-amber-200">
        Completa tu perfil de boda ({completedItems}/{totalItems})
      </AlertTitle>
      <AlertDescription className="mt-3">
        <p className="text-amber-700 dark:text-amber-300 mb-4">
          Para aprovechar todas las funciones, completa la información básica de tu boda:
        </p>
        <ul className="space-y-2">
          {missingItems.map((item) => (
            <li key={item.label} className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-2 text-amber-700 dark:text-amber-300">
                <item.icon className="w-4 h-4" />
                {item.label}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onNavigate(item.action)}
                className="text-xs"
              >
                Añadir
              </Button>
            </li>
          ))}
        </ul>
      </AlertDescription>
    </Alert>
  );
}
