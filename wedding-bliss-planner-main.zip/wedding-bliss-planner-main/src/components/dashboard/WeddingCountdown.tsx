import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, Sparkles, Calendar, PartyPopper, Clock } from "lucide-react";
import { differenceInDays, differenceInHours, differenceInMinutes, differenceInSeconds, isPast, isToday } from "date-fns";

interface WeddingCountdownProps {
  weddingDate: string | null;
  weddingName: string;
}

export function WeddingCountdown({ weddingDate, weddingName }: WeddingCountdownProps) {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    if (!weddingDate) return;

    const updateCountdown = () => {
      const targetDate = new Date(weddingDate);
      const now = new Date();

      if (isPast(targetDate) && !isToday(targetDate)) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      const days = differenceInDays(targetDate, now);
      const hours = differenceInHours(targetDate, now) % 24;
      const minutes = differenceInMinutes(targetDate, now) % 60;
      const seconds = differenceInSeconds(targetDate, now) % 60;

      setTimeLeft({
        days: Math.max(0, days),
        hours: Math.max(0, hours),
        minutes: Math.max(0, minutes),
        seconds: Math.max(0, seconds),
      });
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);

    return () => clearInterval(interval);
  }, [weddingDate]);

  if (!weddingDate) {
    return (
      <Card className="relative overflow-hidden bg-gradient-to-r from-primary/10 via-blush/20 to-secondary/30 border-primary/20">
        <CardContent className="py-8 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Calendar className="w-8 h-8 text-primary animate-pulse" />
          </div>
          <h3 className="text-lg font-serif font-semibold text-muted-foreground">
            ¡Añade la fecha de tu boda para ver la cuenta atrás!
          </h3>
          <p className="text-sm text-muted-foreground mt-2">
            Ve a Ajustes para configurar la fecha
          </p>
        </CardContent>
      </Card>
    );
  }

  const targetDate = new Date(weddingDate);
  const isWeddingToday = isToday(targetDate);
  const isWeddingPast = isPast(targetDate) && !isWeddingToday;

  // Wedding day celebration
  if (isWeddingToday) {
    return (
      <Card className="relative overflow-hidden bg-gradient-to-r from-primary via-rose-gold to-champagne border-0">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48Y2lyY2xlIGN4PSI3IiBjeT0iNyIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-30" />
        <CardContent className="relative py-10 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <PartyPopper className="w-10 h-10 text-primary-foreground animate-bounce" />
            <Heart className="w-8 h-8 text-primary-foreground fill-current" />
            <Sparkles className="w-10 h-10 text-primary-foreground animate-pulse" />
          </div>
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-primary-foreground mb-2">
            ¡Hoy es el gran día!
          </h2>
          <p className="text-xl text-primary-foreground/90 font-medium">
            {weddingName}
          </p>
          <p className="text-lg text-primary-foreground/80 mt-2">
            ¡Felicidades! Que disfrutéis de cada momento ✨
          </p>
        </CardContent>
      </Card>
    );
  }

  // Wedding passed
  if (isWeddingPast) {
    return (
      <Card className="relative overflow-hidden bg-gradient-to-r from-secondary/40 via-blush/30 to-champagne-light/20 border-primary/20">
        <CardContent className="py-8 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Heart className="w-8 h-8 text-primary fill-current" />
          </div>
          <h3 className="text-2xl font-serif font-semibold text-foreground mb-2">
            ¡Ya sois esposos! 💍
          </h3>
          <p className="text-muted-foreground">
            Esperamos que hayáis disfrutado de vuestro día especial
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Esta herramienta seguirá disponible para gestionar agradecimientos y recuerdos
          </p>
        </CardContent>
      </Card>
    );
  }

  // Countdown
  const CountdownUnit = ({ value, label }: { value: number; label: string }) => (
    <div className="flex flex-col items-center">
      <div className="relative">
        <div className="w-16 h-16 md:w-20 md:h-20 rounded-2xl bg-card/80 backdrop-blur-sm border border-primary/20 flex items-center justify-center shadow-lg">
          <span className="text-2xl md:text-3xl font-serif font-bold text-primary">
            {value.toString().padStart(2, "0")}
          </span>
        </div>
        <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-blush animate-pulse" />
      </div>
      <span className="text-xs md:text-sm text-muted-foreground mt-2 font-medium uppercase tracking-wide">
        {label}
      </span>
    </div>
  );

  return (
    <Card className="relative overflow-hidden bg-gradient-to-r from-primary/10 via-blush/20 to-secondary/30 border-primary/20">
      {/* Decorative elements */}
      <div className="absolute top-4 left-4 opacity-20">
        <Heart className="w-12 h-12 text-primary" fill="currentColor" />
      </div>
      <div className="absolute bottom-4 right-4 opacity-20">
        <Sparkles className="w-10 h-10 text-rose-gold" />
      </div>

      <CardContent className="relative py-8">
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-primary/10 mb-3">
            <Clock className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Cuenta atrás</span>
          </div>
          <h3 className="text-lg md:text-xl font-serif font-semibold text-foreground">
            Faltan para vuestra boda
          </h3>
        </div>

        <div className="flex justify-center items-center gap-3 md:gap-6">
          <CountdownUnit value={timeLeft.days} label="Días" />
          <span className="text-2xl text-primary/50 font-serif hidden md:block">:</span>
          <CountdownUnit value={timeLeft.hours} label="Horas" />
          <span className="text-2xl text-primary/50 font-serif hidden md:block">:</span>
          <CountdownUnit value={timeLeft.minutes} label="Min" />
          <span className="text-2xl text-primary/50 font-serif hidden md:block">:</span>
          <CountdownUnit value={timeLeft.seconds} label="Seg" />
        </div>

        {timeLeft.days <= 30 && timeLeft.days > 0 && (
          <p className="text-center text-sm text-muted-foreground mt-6">
            ¡Ya queda muy poco! 🎉 Revisad los últimos detalles
          </p>
        )}
      </CardContent>
    </Card>
  );
}
