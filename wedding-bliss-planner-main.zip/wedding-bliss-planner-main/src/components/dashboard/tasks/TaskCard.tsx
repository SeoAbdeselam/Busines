import { Task, TASK_CATEGORIES, PRIORITY_LABELS } from "./types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Calendar, DollarSign, MoreVertical, Edit2, Trash2, ChevronRight } from "lucide-react";
import { format, isPast, isToday, differenceInDays } from "date-fns";
import { es } from "date-fns/locale";
import { cn } from "@/lib/utils";

interface TaskCardProps {
  task: Task;
  onStatusChange: (status: Task["status"]) => void;
  onEdit: () => void;
  onDelete: () => void;
  onComplete: () => void;
  isDragging?: boolean;
}

export function TaskCard({
  task,
  onStatusChange,
  onEdit,
  onDelete,
  onComplete,
  isDragging,
}: TaskCardProps) {
  const category = TASK_CATEGORIES[task.category] || TASK_CATEGORIES.general;
  const priority = PRIORITY_LABELS[task.priority] || PRIORITY_LABELS[2];

  const isOverdue = task.due_date && isPast(new Date(task.due_date)) && task.status !== "completed";
  const isDueToday = task.due_date && isToday(new Date(task.due_date));
  const daysUntilDue = task.due_date ? differenceInDays(new Date(task.due_date), new Date()) : null;

  const handleCheckboxChange = (checked: boolean) => {
    if (checked && task.has_cost && task.status !== "completed") {
      onComplete(); // Opens completion modal for tasks with cost
    } else if (checked) {
      onStatusChange("completed");
    } else {
      onStatusChange("pending");
    }
  };

  return (
    <div
      className={cn(
        "p-4 bg-card rounded-lg border transition-all",
        isDragging && "shadow-lg ring-2 ring-primary opacity-90",
        task.status === "completed" && "opacity-60",
        isOverdue && "border-destructive/50"
      )}
    >
      <div className="flex items-start gap-3">
        <Checkbox
          checked={task.status === "completed"}
          onCheckedChange={handleCheckboxChange}
          className="mt-1"
        />

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h4
              className={cn(
                "font-medium",
                task.status === "completed" && "line-through text-muted-foreground"
              )}
            >
              {task.title}
            </h4>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-7 w-7 -mr-2">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={onEdit}>
                  <Edit2 className="w-4 h-4 mr-2" />
                  Editar
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onDelete} className="text-destructive">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Eliminar
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {task.description && (
            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
              {task.description}
            </p>
          )}

          <div className="flex flex-wrap items-center gap-2 mt-3">
            <Badge
              variant="secondary"
              className={cn("text-xs text-white", category.color)}
            >
              {category.label}
            </Badge>

            <span className={cn("text-xs font-medium", priority.color)}>
              {priority.label}
            </span>

            {task.due_date && (
              <span
                className={cn(
                  "flex items-center gap-1 text-xs",
                  isOverdue && "text-destructive font-medium",
                  isDueToday && "text-amber-500 font-medium"
                )}
              >
                <Calendar className="w-3 h-3" />
                {isDueToday
                  ? "Hoy"
                  : isOverdue
                  ? `Vencida hace ${Math.abs(daysUntilDue || 0)} días`
                  : format(new Date(task.due_date), "d MMM", { locale: es })}
              </span>
            )}

            {task.has_cost && task.estimated_cost && (
              <span className="flex items-center gap-1 text-xs text-muted-foreground">
                <DollarSign className="w-3 h-3" />
                {task.estimated_cost.toLocaleString("es-ES")}€
                {task.actual_cost && (
                  <span className="text-primary">
                    → {task.actual_cost.toLocaleString("es-ES")}€
                  </span>
                )}
              </span>
            )}

            {task.has_cost && task.payment_status && (
              <Badge
                variant={
                  task.payment_status === "paid"
                    ? "default"
                    : task.payment_status === "partial"
                    ? "secondary"
                    : "outline"
                }
                className="text-xs"
              >
                {task.payment_status === "paid"
                  ? "Pagado"
                  : task.payment_status === "partial"
                  ? "Parcial"
                  : "Pendiente"}
              </Badge>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
