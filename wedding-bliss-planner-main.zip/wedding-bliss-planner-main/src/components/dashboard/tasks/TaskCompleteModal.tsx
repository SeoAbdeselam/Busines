import { useState } from "react";
import { Task } from "./types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CheckCircle } from "lucide-react";

interface TaskCompleteModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task: Task | null;
  onComplete: (actualCost: number, paymentStatus: "pending" | "partial" | "paid") => Promise<void>;
}

export function TaskCompleteModal({
  open,
  onOpenChange,
  task,
  onComplete,
}: TaskCompleteModalProps) {
  const [loading, setLoading] = useState(false);
  const [actualCost, setActualCost] = useState(task?.estimated_cost || 0);
  const [paymentStatus, setPaymentStatus] = useState<"pending" | "partial" | "paid">("paid");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!task) return;

    setLoading(true);
    await onComplete(actualCost, paymentStatus);
    setLoading(false);
    onOpenChange(false);
  };

  if (!task) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-primary" />
            Completar Tarea
          </DialogTitle>
          <DialogDescription>
            Confirma los detalles del pago para "{task.title}"
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="p-4 bg-secondary/50 rounded-lg">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Coste estimado:</span>
              <span className="font-medium">
                {(task.estimated_cost || 0).toLocaleString("es-ES")}€
              </span>
            </div>
            {task.budget_category && (
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Categoría:</span>
                <span>{task.budget_category}</span>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Coste real (€)</label>
            <Input
              type="number"
              min={0}
              value={actualCost}
              onChange={(e) => setActualCost(parseFloat(e.target.value) || 0)}
            />
            {actualCost !== (task.estimated_cost || 0) && (
              <p className="text-xs text-muted-foreground">
                Diferencia:{" "}
                <span
                  className={
                    actualCost > (task.estimated_cost || 0)
                      ? "text-destructive"
                      : "text-green-600"
                  }
                >
                  {actualCost > (task.estimated_cost || 0) ? "+" : ""}
                  {(actualCost - (task.estimated_cost || 0)).toLocaleString("es-ES")}€
                </span>
              </p>
            )}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Estado del pago</label>
            <Select value={paymentStatus} onValueChange={(v: "pending" | "partial" | "paid") => setPaymentStatus(v)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="paid">Pagado completamente</SelectItem>
                <SelectItem value="partial">Pago parcial</SelectItem>
                <SelectItem value="pending">Pendiente de pago</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              onClick={() => onOpenChange(false)}
            >
              Cancelar
            </Button>
            <Button type="submit" className="flex-1" disabled={loading}>
              {loading ? "Guardando..." : "Completar Tarea"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
