import { Task, TaskStatus } from "./types";
import { TaskCard } from "./TaskCard";
import { cn } from "@/lib/utils";

interface KanbanColumnProps {
  title: string;
  status: TaskStatus;
  tasks: Task[];
  count: number;
  onTaskStatusChange: (taskId: string, status: TaskStatus) => void;
  onEditTask: (task: Task) => void;
  onDeleteTask: (taskId: string) => void;
  onCompleteTask: (task: Task) => void;
  onDragStart: (e: React.DragEvent, taskId: string) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent, status: TaskStatus) => void;
  isDragOver: boolean;
}

const COLUMN_COLORS: Record<TaskStatus, string> = {
  pending: "border-t-amber-500",
  in_progress: "border-t-blue-500",
  completed: "border-t-green-500",
};

export function KanbanColumn({
  title,
  status,
  tasks,
  count,
  onTaskStatusChange,
  onEditTask,
  onDeleteTask,
  onCompleteTask,
  onDragStart,
  onDragOver,
  onDrop,
  isDragOver,
}: KanbanColumnProps) {
  return (
    <div
      className={cn(
        "flex-1 min-w-[300px] bg-muted/30 rounded-lg border-t-4 transition-colors",
        COLUMN_COLORS[status],
        isDragOver && "bg-primary/5 ring-2 ring-primary/20"
      )}
      onDragOver={onDragOver}
      onDrop={(e) => onDrop(e, status)}
    >
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">{title}</h3>
          <span className="text-sm text-muted-foreground bg-secondary px-2 py-0.5 rounded-full">
            {count}
          </span>
        </div>
      </div>

      <div className="p-3 space-y-3 min-h-[200px] max-h-[calc(100vh-20rem)] overflow-y-auto">
        {tasks.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground text-sm">
            No hay tareas
          </div>
        ) : (
          tasks.map((task) => (
            <div
              key={task.id}
              draggable
              onDragStart={(e) => onDragStart(e, task.id)}
              className="cursor-grab active:cursor-grabbing"
            >
              <TaskCard
                task={task}
                onStatusChange={(newStatus) => onTaskStatusChange(task.id, newStatus)}
                onEdit={() => onEditTask(task)}
                onDelete={() => onDeleteTask(task.id)}
                onComplete={() => onCompleteTask(task)}
              />
            </div>
          ))
        )}
      </div>
    </div>
  );
}
