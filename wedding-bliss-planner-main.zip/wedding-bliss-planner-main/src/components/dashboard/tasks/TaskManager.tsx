import { useState, useEffect } from "react";
import { useWedding } from "@/contexts/WeddingContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Plus, Sparkles, ListTodo, DollarSign, Clock } from "lucide-react";
import { differenceInMonths } from "date-fns";

import { Task, TaskTemplate, TaskStatus } from "./types";
import { KanbanColumn } from "./KanbanColumn";
import { TaskFormModal } from "./TaskFormModal";
import { TaskCompleteModal } from "./TaskCompleteModal";

export function TaskManager() {
  const { activeWedding } = useWedding();
  const { toast } = useToast();

  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [completingTask, setCompletingTask] = useState<Task | null>(null);
  const [showGenerateDialog, setShowGenerateDialog] = useState(false);
  const [dragOverColumn, setDragOverColumn] = useState<TaskStatus | null>(null);
  const [deleteTaskId, setDeleteTaskId] = useState<string | null>(null);

  useEffect(() => {
    if (activeWedding) {
      fetchTasks();
    }
  }, [activeWedding]);

  const fetchTasks = async () => {
    if (!activeWedding) return;

    const { data, error } = await supabase
      .from("tasks")
      .select("*")
      .eq("wedding_id", activeWedding.id)
      .order("sort_order")
      .order("priority")
      .order("due_date");

    if (!error) {
      setTasks((data || []) as Task[]);
    }
    setLoading(false);
  };

  const generateTasksFromTemplates = async () => {
    if (!activeWedding) return;

    const weddingDate = activeWedding.wedding_date
      ? new Date(activeWedding.wedding_date)
      : null;

    if (!weddingDate) {
      toast({
        title: "Fecha requerida",
        description: "Establece la fecha de la boda para generar tareas automáticamente",
        variant: "destructive",
      });
      return;
    }

    // Fetch templates
    const { data: templates, error } = await supabase
      .from("task_templates")
      .select("*")
      .order("sort_order");

    if (error || !templates) {
      toast({ title: "Error", description: "No se pudieron cargar las plantillas", variant: "destructive" });
      return;
    }

    const monthsUntilWedding = differenceInMonths(weddingDate, new Date());

    // Filter relevant templates and create tasks
    const relevantTemplates = (templates as TaskTemplate[]).filter(
      (t) => t.months_before <= monthsUntilWedding + 1 || monthsUntilWedding < 0
    );

    // Check which templates are already used
    const existingKeys = tasks.filter((t) => t.template_key).map((t) => t.template_key);
    const newTemplates = relevantTemplates.filter((t) => !existingKeys.includes(t.key));

    if (newTemplates.length === 0) {
      toast({ title: "Sin novedades", description: "Todas las tareas ya fueron generadas" });
      setShowGenerateDialog(false);
      return;
    }

    // Calculate due dates based on months_before
    // Insert tasks one by one to avoid type issues
    const insertedTasks: Task[] = [];
    
    for (const template of newTemplates) {
      const dueDate = new Date(weddingDate);
      dueDate.setMonth(dueDate.getMonth() - template.months_before);

      const { data: inserted, error: insertError } = await supabase
        .from("tasks")
        .insert({
          wedding_id: activeWedding.id,
          title: template.title,
          description: template.description,
          category: template.category,
          priority: template.priority,
          due_date: dueDate.toISOString().split("T")[0],
          has_cost: template.has_cost,
          budget_category: template.budget_category,
          is_from_template: true,
          template_key: template.key,
          sort_order: template.sort_order,
          status: "pending" as const,
        })
        .select()
        .single();

      if (!insertError && inserted) {
        insertedTasks.push(inserted as Task);
      }
    }

    if (insertedTasks.length === 0) {
      toast({ title: "Error", description: "No se pudieron crear las tareas", variant: "destructive" });
    } else {
      setTasks([...tasks, ...insertedTasks]);
      toast({
        title: "¡Tareas generadas!",
        description: `Se crearon ${insertedTasks.length} tareas basadas en tu fecha de boda`,
      });
    }

    setShowGenerateDialog(false);
  };

  const handleCreateTask = async (data: Partial<Task>) => {
    if (!activeWedding) return;

    const { data: newTask, error } = await supabase
      .from("tasks")
      .insert({
        wedding_id: activeWedding.id,
        title: data.title || "",
        description: data.description || null,
        category: data.category || "general",
        priority: data.priority || 2,
        due_date: data.due_date || null,
        has_cost: data.has_cost || false,
        estimated_cost: data.estimated_cost || null,
        budget_category: data.budget_category || null,
        status: "pending" as const,
        sort_order: tasks.length,
      })
      .select()
      .single();

    if (error) {
      toast({ title: "Error", description: "No se pudo crear la tarea", variant: "destructive" });
    } else {
      setTasks([...tasks, newTask as Task]);
      toast({ title: "Tarea creada" });
    }
  };

  const handleUpdateTask = async (data: Partial<Task>) => {
    if (!editingTask) return;

    const { error } = await supabase
      .from("tasks")
      .update(data)
      .eq("id", editingTask.id);

    if (!error) {
      setTasks(tasks.map((t) => (t.id === editingTask.id ? { ...t, ...data } : t)));
      toast({ title: "Tarea actualizada" });
    }
    setEditingTask(null);
  };

  const handleDeleteTask = async (taskId: string) => {
    const { error } = await supabase.from("tasks").delete().eq("id", taskId);

    if (!error) {
      setTasks(tasks.filter((t) => t.id !== taskId));
      toast({ title: "Tarea eliminada" });
    }
    setDeleteTaskId(null);
  };

  const handleStatusChange = async (taskId: string, status: TaskStatus) => {
    const task = tasks.find((t) => t.id === taskId);
    if (!task) return;

    const updates: Partial<Task> = {
      status,
      completed_at: status === "completed" ? new Date().toISOString() : null,
    };

    const { error } = await supabase.from("tasks").update(updates).eq("id", taskId);

    if (!error) {
      setTasks(tasks.map((t) => (t.id === taskId ? { ...t, ...updates } : t)));
    }
  };

  const handleCompleteWithCost = async (actualCost: number, paymentStatus: "pending" | "partial" | "paid") => {
    if (!completingTask) return;

    const updates = {
      status: "completed" as const,
      completed_at: new Date().toISOString(),
      actual_cost: actualCost,
      payment_status: paymentStatus,
    };

    const { error } = await supabase.from("tasks").update(updates).eq("id", completingTask.id);

    if (!error) {
      setTasks(tasks.map((t) => (t.id === completingTask.id ? { ...t, ...updates } : t)));
      toast({ title: "Tarea completada" });
    }
    setCompletingTask(null);
  };

  const handleDragStart = (e: React.DragEvent, taskId: string) => {
    e.dataTransfer.setData("taskId", taskId);
  };

  const handleDragOver = (e: React.DragEvent, status: TaskStatus) => {
    e.preventDefault();
    setDragOverColumn(status);
  };

  const handleDrop = async (e: React.DragEvent, status: TaskStatus) => {
    e.preventDefault();
    const taskId = e.dataTransfer.getData("taskId");
    if (taskId) {
      const task = tasks.find((t) => t.id === taskId);
      if (task && task.has_cost && status === "completed") {
        setCompletingTask(task);
      } else {
        await handleStatusChange(taskId, status);
      }
    }
    setDragOverColumn(null);
  };

  // Stats
  const pendingTasks = tasks.filter((t) => t.status === "pending");
  const inProgressTasks = tasks.filter((t) => t.status === "in_progress");
  const completedTasks = tasks.filter((t) => t.status === "completed");
  const completionRate = tasks.length > 0 ? (completedTasks.length / tasks.length) * 100 : 0;

  const totalEstimated = tasks.filter((t) => t.has_cost).reduce((acc, t) => acc + (t.estimated_cost || 0), 0);
  const totalActual = tasks.filter((t) => t.actual_cost).reduce((acc, t) => acc + (t.actual_cost || 0), 0);

  if (!activeWedding) return null;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[400px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Cargando tareas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-serif font-bold">Tareas</h1>
          <p className="text-muted-foreground">
            {completedTasks.length} de {tasks.length} completadas
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setShowGenerateDialog(true)}>
            <Sparkles className="w-4 h-4 mr-2" />
            Generar Automáticas
          </Button>
          <Button onClick={() => setShowFormModal(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Nueva Tarea
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <ListTodo className="w-4 h-4" />
              <span className="text-sm">Progreso</span>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="font-semibold">{Math.round(completionRate)}%</span>
              </div>
              <Progress value={completionRate} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <Clock className="w-4 h-4" />
              <span className="text-sm">Pendientes</span>
            </div>
            <p className="text-2xl font-bold">{pendingTasks.length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <DollarSign className="w-4 h-4" />
              <span className="text-sm">Estimado</span>
            </div>
            <p className="text-2xl font-bold">{totalEstimated.toLocaleString("es-ES")}€</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <DollarSign className="w-4 h-4" />
              <span className="text-sm">Gastado</span>
            </div>
            <p className="text-2xl font-bold text-primary">{totalActual.toLocaleString("es-ES")}€</p>
          </CardContent>
        </Card>
      </div>

      {/* Kanban Board */}
      <div className="flex gap-4 overflow-x-auto pb-4">
        <KanbanColumn
          title="Pendientes"
          status="pending"
          tasks={pendingTasks}
          count={pendingTasks.length}
          onTaskStatusChange={handleStatusChange}
          onEditTask={(task) => { setEditingTask(task); setShowFormModal(true); }}
          onDeleteTask={(id) => setDeleteTaskId(id)}
          onCompleteTask={setCompletingTask}
          onDragStart={handleDragStart}
          onDragOver={(e) => handleDragOver(e, "pending")}
          onDrop={(e) => handleDrop(e, "pending")}
          isDragOver={dragOverColumn === "pending"}
        />
        <KanbanColumn
          title="En Progreso"
          status="in_progress"
          tasks={inProgressTasks}
          count={inProgressTasks.length}
          onTaskStatusChange={handleStatusChange}
          onEditTask={(task) => { setEditingTask(task); setShowFormModal(true); }}
          onDeleteTask={(id) => setDeleteTaskId(id)}
          onCompleteTask={setCompletingTask}
          onDragStart={handleDragStart}
          onDragOver={(e) => handleDragOver(e, "in_progress")}
          onDrop={(e) => handleDrop(e, "in_progress")}
          isDragOver={dragOverColumn === "in_progress"}
        />
        <KanbanColumn
          title="Completadas"
          status="completed"
          tasks={completedTasks}
          count={completedTasks.length}
          onTaskStatusChange={handleStatusChange}
          onEditTask={(task) => { setEditingTask(task); setShowFormModal(true); }}
          onDeleteTask={(id) => setDeleteTaskId(id)}
          onCompleteTask={setCompletingTask}
          onDragStart={handleDragStart}
          onDragOver={(e) => handleDragOver(e, "completed")}
          onDrop={(e) => handleDrop(e, "completed")}
          isDragOver={dragOverColumn === "completed"}
        />
      </div>

      {/* Modals */}
      <TaskFormModal
        open={showFormModal}
        onOpenChange={(open) => {
          setShowFormModal(open);
          if (!open) setEditingTask(null);
        }}
        task={editingTask}
        onSubmit={editingTask ? handleUpdateTask : handleCreateTask}
      />

      <TaskCompleteModal
        open={!!completingTask}
        onOpenChange={(open) => !open && setCompletingTask(null)}
        task={completingTask}
        onComplete={handleCompleteWithCost}
      />

      {/* Generate Dialog */}
      <AlertDialog open={showGenerateDialog} onOpenChange={setShowGenerateDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              Generar Tareas Automáticamente
            </AlertDialogTitle>
            <AlertDialogDescription>
              Crearemos una lista de tareas basada en la fecha de tu boda, con fechas límite
              sugeridas y categorías de presupuesto asociadas.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={generateTasksFromTemplates}>
              Generar Tareas
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteTaskId} onOpenChange={(open) => !open && setDeleteTaskId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar tarea?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteTaskId && handleDeleteTask(deleteTaskId)}
              className="bg-destructive hover:bg-destructive/90"
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
