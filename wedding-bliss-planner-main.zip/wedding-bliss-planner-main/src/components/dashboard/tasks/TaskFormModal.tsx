import { useState, useEffect } from "react";
import { Task, TASK_CATEGORIES } from "./types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { cn } from "@/lib/utils";

interface TaskFormModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task?: Task | null;
  onSubmit: (data: Partial<Task>) => Promise<void>;
}

const BUDGET_CATEGORIES = [
  "Venue",
  "Catering",
  "Fotografía",
  "Música",
  "Decoración",
  "Vestuario",
  "Papelería",
  "Joyería",
  "Ceremonia",
  "Transporte",
  "Otros",
];

export function TaskFormModal({
  open,
  onOpenChange,
  task,
  onSubmit,
}: TaskFormModalProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "general",
    priority: 2,
    due_date: null as Date | null,
    has_cost: false,
    estimated_cost: 0,
    budget_category: "none",
  });

  useEffect(() => {
    if (task) {
      setFormData({
        title: task.title,
        description: task.description || "",
        category: task.category,
        priority: task.priority,
        due_date: task.due_date ? new Date(task.due_date) : null,
        has_cost: task.has_cost,
        estimated_cost: task.estimated_cost || 0,
        budget_category: task.budget_category || "none",
      });
    } else {
      setFormData({
        title: "",
        description: "",
        category: "general",
        priority: 2,
        due_date: null,
        has_cost: false,
        estimated_cost: 0,
        budget_category: "none",
      });
    }
  }, [task, open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    await onSubmit({
      title: formData.title,
      description: formData.description || null,
      category: formData.category,
      priority: formData.priority,
      due_date: formData.due_date?.toISOString().split("T")[0] || null,
      has_cost: formData.has_cost,
      estimated_cost: formData.has_cost ? formData.estimated_cost : null,
      budget_category: formData.has_cost && formData.budget_category !== "none" 
        ? formData.budget_category 
        : null,
    });

    setLoading(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{task ? "Editar Tarea" : "Nueva Tarea"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Título *</label>
            <Input
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="¿Qué necesitas hacer?"
              required
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Descripción</label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Detalles adicionales..."
              rows={2}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Categoría</label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(TASK_CATEGORIES).map(([key, { label }]) => (
                    <SelectItem key={key} value={key}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Prioridad</label>
              <Select
                value={formData.priority.toString()}
                onValueChange={(value) =>
                  setFormData({ ...formData, priority: parseInt(value) })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Alta</SelectItem>
                  <SelectItem value="2">Media</SelectItem>
                  <SelectItem value="3">Baja</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Fecha límite</label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !formData.due_date && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {formData.due_date
                    ? format(formData.due_date, "PPP", { locale: es })
                    : "Sin fecha"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={formData.due_date || undefined}
                  onSelect={(date) => setFormData({ ...formData, due_date: date || null })}
                  locale={es}
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Budget Integration */}
          <div className="border-t pt-4">
            <div className="flex items-center gap-2 mb-4">
              <Checkbox
                id="has_cost"
                checked={formData.has_cost}
                onCheckedChange={(checked) =>
                  setFormData({ ...formData, has_cost: !!checked })
                }
              />
              <label htmlFor="has_cost" className="text-sm font-medium cursor-pointer">
                Esta tarea tiene coste asociado
              </label>
            </div>

            {formData.has_cost && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Coste estimado (€)</label>
                  <Input
                    type="number"
                    min={0}
                    value={formData.estimated_cost}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        estimated_cost: parseFloat(e.target.value) || 0,
                      })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Categoría presupuesto</label>
                  <Select
                    value={formData.budget_category}
                    onValueChange={(value) =>
                      setFormData({ ...formData, budget_category: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Sin categoría</SelectItem>
                      {BUDGET_CATEGORIES.map((cat) => (
                        <SelectItem key={cat} value={cat}>
                          {cat}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
          </div>

          <Button type="submit" className="w-full" disabled={loading || !formData.title.trim()}>
            {loading ? "Guardando..." : task ? "Guardar Cambios" : "Crear Tarea"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
