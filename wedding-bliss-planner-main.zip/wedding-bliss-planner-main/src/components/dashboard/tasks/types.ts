export interface Task {
  id: string;
  wedding_id: string;
  title: string;
  description: string | null;
  category: string;
  priority: number; // 1=high, 2=medium, 3=low
  status: "pending" | "in_progress" | "completed";
  due_date: string | null;
  has_cost: boolean;
  estimated_cost: number | null;
  actual_cost: number | null;
  payment_status: "pending" | "partial" | "paid" | null;
  budget_category: string | null;
  is_from_template: boolean;
  template_key: string | null;
  sort_order: number;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface TaskTemplate {
  id: string;
  key: string;
  title: string;
  description: string | null;
  category: string;
  priority: number;
  months_before: number;
  has_cost: boolean;
  budget_category: string | null;
  sort_order: number;
}

export type TaskStatus = "pending" | "in_progress" | "completed";

export const TASK_CATEGORIES: Record<string, { label: string; color: string }> = {
  planning: { label: "Planificación", color: "bg-blue-500" },
  venue: { label: "Lugar", color: "bg-purple-500" },
  catering: { label: "Catering", color: "bg-orange-500" },
  photography: { label: "Fotografía", color: "bg-pink-500" },
  entertainment: { label: "Entretenimiento", color: "bg-yellow-500" },
  decoration: { label: "Decoración", color: "bg-green-500" },
  attire: { label: "Vestuario", color: "bg-indigo-500" },
  stationery: { label: "Papelería", color: "bg-teal-500" },
  ceremony: { label: "Ceremonia", color: "bg-rose-500" },
  guests: { label: "Invitados", color: "bg-cyan-500" },
  general: { label: "General", color: "bg-gray-500" },
};

export const PRIORITY_LABELS: Record<number, { label: string; color: string }> = {
  1: { label: "Alta", color: "text-destructive" },
  2: { label: "Media", color: "text-amber-500" },
  3: { label: "Baja", color: "text-muted-foreground" },
};
