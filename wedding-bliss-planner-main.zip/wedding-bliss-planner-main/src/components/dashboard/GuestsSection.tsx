import { useEffect, useState } from "react";
import { useWedding } from "@/contexts/WeddingContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  Plus, 
  Users, 
  Search, 
  CheckCircle2, 
  Clock, 
  XCircle,
  Trash2,
  Edit2,
  UserPlus
} from "lucide-react";

interface Guest {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  rsvp_status: "pending" | "confirmed" | "declined";
  plus_ones: number;
  dietary_notes: string | null;
  notes: string | null;
  guest_group_id: string | null;
  table_id: string | null;
}

interface GuestGroup {
  id: string;
  name: string;
  description: string | null;
}

export function GuestsSection() {
  const { activeWedding } = useWedding();
  const { toast } = useToast();
  const [guests, setGuests] = useState<Guest[]>([]);
  const [groups, setGroups] = useState<GuestGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterGroup, setFilterGroup] = useState<string>("all");
  const [showAddModal, setShowAddModal] = useState(false);
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [editingGuest, setEditingGuest] = useState<Guest | null>(null);

  useEffect(() => {
    if (activeWedding) {
      fetchGuests();
      fetchGroups();
    }
  }, [activeWedding]);

  const fetchGuests = async () => {
    if (!activeWedding) return;

    const { data, error } = await supabase
      .from("guests")
      .select("*")
      .eq("wedding_id", activeWedding.id)
      .order("name");

    if (!error && data) {
      setGuests(data);
    }
    setLoading(false);
  };

  const fetchGroups = async () => {
    if (!activeWedding) return;

    const { data, error } = await supabase
      .from("guest_groups")
      .select("*")
      .eq("wedding_id", activeWedding.id)
      .order("name");

    if (!error && data) {
      setGroups(data);
    }
  };

  const deleteGuest = async (id: string) => {
    const { error } = await supabase.from("guests").delete().eq("id", id);

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo eliminar el invitado",
        variant: "destructive",
      });
    } else {
      setGuests(guests.filter((g) => g.id !== id));
      toast({ title: "Invitado eliminado" });
    }
  };

  const updateGuestStatus = async (id: string, status: "pending" | "confirmed" | "declined") => {
    const { error } = await supabase
      .from("guests")
      .update({ rsvp_status: status })
      .eq("id", id);

    if (!error) {
      setGuests(guests.map((g) => (g.id === id ? { ...g, rsvp_status: status } : g)));
    }
  };

  const filteredGuests = guests.filter((guest) => {
    const matchesSearch = guest.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      guest.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || guest.rsvp_status === filterStatus;
    const matchesGroup = filterGroup === "all" || guest.guest_group_id === filterGroup;
    return matchesSearch && matchesStatus && matchesGroup;
  });

  const stats = {
    total: guests.length,
    confirmed: guests.filter((g) => g.rsvp_status === "confirmed").length,
    pending: guests.filter((g) => g.rsvp_status === "pending").length,
    declined: guests.filter((g) => g.rsvp_status === "declined").length,
    totalAttendees: guests
      .filter((g) => g.rsvp_status === "confirmed")
      .reduce((acc, g) => acc + 1 + g.plus_ones, 0),
  };

  if (!activeWedding) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-serif font-bold">Invitados</h1>
          <p className="text-muted-foreground">Gestiona tu lista de invitados</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowGroupModal(true)}>
            <Users className="w-4 h-4 mr-2" />
            Grupos
          </Button>
          <Button onClick={() => setShowAddModal(true)}>
            <UserPlus className="w-4 h-4 mr-2" />
            Añadir Invitado
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-2xl font-bold">{stats.total}</p>
            <p className="text-sm text-muted-foreground">Total invitados</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-2xl font-bold text-green-600">{stats.confirmed}</p>
            <p className="text-sm text-muted-foreground">Confirmados</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-2xl font-bold text-amber-600">{stats.pending}</p>
            <p className="text-sm text-muted-foreground">Pendientes</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-2xl font-bold text-red-600">{stats.declined}</p>
            <p className="text-sm text-muted-foreground">No asisten</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <p className="text-2xl font-bold text-primary">{stats.totalAttendees}</p>
            <p className="text-sm text-muted-foreground">Asistentes reales</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Buscar invitados..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <SelectValue placeholder="Estado" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los estados</SelectItem>
            <SelectItem value="confirmed">Confirmados</SelectItem>
            <SelectItem value="pending">Pendientes</SelectItem>
            <SelectItem value="declined">No asisten</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterGroup} onValueChange={setFilterGroup}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <SelectValue placeholder="Grupo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los grupos</SelectItem>
            {groups.map((group) => (
              <SelectItem key={group.id} value={group.id}>
                {group.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Guests List */}
      <div className="space-y-2">
        {filteredGuests.map((guest) => (
          <Card key={guest.id} className="hover:shadow-md transition-shadow">
            <CardContent className="py-4">
              <div className="flex items-center justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium truncate">{guest.name}</p>
                    {guest.plus_ones > 0 && (
                      <span className="text-xs bg-secondary px-2 py-0.5 rounded">
                        +{guest.plus_ones}
                      </span>
                    )}
                  </div>
                  {guest.email && (
                    <p className="text-sm text-muted-foreground truncate">
                      {guest.email}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <Select
                    value={guest.rsvp_status}
                    onValueChange={(value: "pending" | "confirmed" | "declined") =>
                      updateGuestStatus(guest.id, value)
                    }
                  >
                    <SelectTrigger className="w-[130px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="confirmed">
                        <span className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-green-500" />
                          Confirmado
                        </span>
                      </SelectItem>
                      <SelectItem value="pending">
                        <span className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-amber-500" />
                          Pendiente
                        </span>
                      </SelectItem>
                      <SelectItem value="declined">
                        <span className="flex items-center gap-2">
                          <XCircle className="w-4 h-4 text-red-500" />
                          No asiste
                        </span>
                      </SelectItem>
                    </SelectContent>
                  </Select>

                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setEditingGuest(guest)}
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteGuest(guest.id)}
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredGuests.length === 0 && !loading && (
          <div className="text-center py-12">
            <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No hay invitados que mostrar</p>
            <Button className="mt-4" onClick={() => setShowAddModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Añadir tu primer invitado
            </Button>
          </div>
        )}
      </div>

      {/* Add Guest Modal */}
      <AddGuestModal
        open={showAddModal}
        onOpenChange={setShowAddModal}
        groups={groups}
        weddingId={activeWedding.id}
        onSuccess={() => {
          fetchGuests();
          setShowAddModal(false);
        }}
      />

      {/* Edit Guest Modal */}
      {editingGuest && (
        <AddGuestModal
          open={!!editingGuest}
          onOpenChange={() => setEditingGuest(null)}
          groups={groups}
          weddingId={activeWedding.id}
          guest={editingGuest}
          onSuccess={() => {
            fetchGuests();
            setEditingGuest(null);
          }}
        />
      )}

      {/* Groups Modal */}
      <GroupsModal
        open={showGroupModal}
        onOpenChange={setShowGroupModal}
        weddingId={activeWedding.id}
        groups={groups}
        onSuccess={fetchGroups}
      />
    </div>
  );
}

// Add Guest Modal Component
function AddGuestModal({
  open,
  onOpenChange,
  groups,
  weddingId,
  guest,
  onSuccess,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  groups: GuestGroup[];
  weddingId: string;
  guest?: Guest;
  onSuccess: () => void;
}) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: guest?.name || "",
    email: guest?.email || "",
    phone: guest?.phone || "",
    plus_ones: guest?.plus_ones || 0,
    dietary_notes: guest?.dietary_notes || "",
    notes: guest?.notes || "",
    guest_group_id: guest?.guest_group_id || "none",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const payload = {
      ...formData,
      wedding_id: weddingId,
      guest_group_id: formData.guest_group_id && formData.guest_group_id !== "none" ? formData.guest_group_id : null,
      email: formData.email || null,
      phone: formData.phone || null,
      dietary_notes: formData.dietary_notes || null,
      notes: formData.notes || null,
    };

    let error;
    if (guest) {
      const { error: updateError } = await supabase
        .from("guests")
        .update(payload)
        .eq("id", guest.id);
      error = updateError;
    } else {
      const { error: insertError } = await supabase
        .from("guests")
        .insert(payload);
      error = insertError;
    }

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo guardar el invitado",
        variant: "destructive",
      });
    } else {
      toast({
        title: guest ? "Invitado actualizado" : "Invitado añadido",
      });
      onSuccess();
    }

    setLoading(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {guest ? "Editar Invitado" : "Añadir Invitado"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Nombre *</label>
            <Input
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Email</label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) =>
                  setFormData({ ...formData, email: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Teléfono</label>
              <Input
                value={formData.phone}
                onChange={(e) =>
                  setFormData({ ...formData, phone: e.target.value })
                }
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Acompañantes</label>
              <Input
                type="number"
                min="0"
                value={formData.plus_ones}
                onChange={(e) =>
                  setFormData({ ...formData, plus_ones: parseInt(e.target.value) || 0 })
                }
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Grupo</label>
              <Select
                value={formData.guest_group_id}
                onValueChange={(value) =>
                  setFormData({ ...formData, guest_group_id: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sin grupo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Sin grupo</SelectItem>
                  {groups.map((group) => (
                    <SelectItem key={group.id} value={group.id}>
                      {group.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Notas dietéticas</label>
            <Input
              value={formData.dietary_notes}
              onChange={(e) =>
                setFormData({ ...formData, dietary_notes: e.target.value })
              }
              placeholder="Alergias, preferencias..."
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Notas</label>
            <Input
              value={formData.notes}
              onChange={(e) =>
                setFormData({ ...formData, notes: e.target.value })
              }
              placeholder="Notas adicionales..."
            />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Guardando..." : guest ? "Guardar Cambios" : "Añadir Invitado"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// Groups Modal Component
function GroupsModal({
  open,
  onOpenChange,
  weddingId,
  groups,
  onSuccess,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  weddingId: string;
  groups: GuestGroup[];
  onSuccess: () => void;
}) {
  const { toast } = useToast();
  const [newGroupName, setNewGroupName] = useState("");
  const [loading, setLoading] = useState(false);

  const addGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) return;

    setLoading(true);
    const { error } = await supabase.from("guest_groups").insert({
      name: newGroupName,
      wedding_id: weddingId,
    });

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo crear el grupo",
        variant: "destructive",
      });
    } else {
      setNewGroupName("");
      onSuccess();
    }
    setLoading(false);
  };

  const deleteGroup = async (id: string) => {
    const { error } = await supabase.from("guest_groups").delete().eq("id", id);

    if (error) {
      toast({
        title: "Error",
        description: "No se pudo eliminar el grupo",
        variant: "destructive",
      });
    } else {
      onSuccess();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Grupos de Invitados</DialogTitle>
        </DialogHeader>

        <form onSubmit={addGroup} className="flex gap-2">
          <Input
            placeholder="Nombre del grupo..."
            value={newGroupName}
            onChange={(e) => setNewGroupName(e.target.value)}
          />
          <Button type="submit" disabled={loading}>
            <Plus className="w-4 h-4" />
          </Button>
        </form>

        <div className="space-y-2 max-h-[300px] overflow-y-auto">
          {groups.map((group) => (
            <div
              key={group.id}
              className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg"
            >
              <span>{group.name}</span>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => deleteGroup(group.id)}
              >
                <Trash2 className="w-4 h-4 text-destructive" />
              </Button>
            </div>
          ))}
          {groups.length === 0 && (
            <p className="text-center text-muted-foreground py-4">
              No hay grupos creados
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
