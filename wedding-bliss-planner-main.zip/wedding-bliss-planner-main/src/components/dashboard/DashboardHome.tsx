import { useEffect, useState } from "react";
import { useWedding } from "@/contexts/WeddingContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Users, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  Wallet, 
  Gift, 
  Copy,
  Check
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ProfileCompletenessAlert } from "./ProfileCompletenessAlert";
import { WeddingCountdown } from "./WeddingCountdown";
interface Stats {
  totalGuests: number;
  confirmed: number;
  pending: number;
  declined: number;
  totalAttendees: number;
  totalBudget: number;
  totalSpent: number;
  totalGifts: number;
}

interface ProfileCompleteness {
  hasWeddingDate: boolean;
  hasLocation: boolean;
  hasGuests: boolean;
  hasTasks: boolean;
  hasBudget: boolean;
}

interface DashboardHomeProps {
  onNavigate?: (section: string) => void;
}

export function DashboardHome({ onNavigate }: DashboardHomeProps) {
  const { activeWedding } = useWedding();
  const [stats, setStats] = useState<Stats>({
    totalGuests: 0,
    confirmed: 0,
    pending: 0,
    declined: 0,
    totalAttendees: 0,
    totalBudget: 0,
    totalSpent: 0,
    totalGifts: 0,
  });
  const [profileCompleteness, setProfileCompleteness] = useState<ProfileCompleteness>({
    hasWeddingDate: false,
    hasLocation: false,
    hasGuests: false,
    hasTasks: false,
    hasBudget: false,
  });
  const [loading, setLoading] = useState(true);
  const [codeCopied, setCodeCopied] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (activeWedding) {
      fetchStats();
    }
  }, [activeWedding]);

  const fetchStats = async () => {
    if (!activeWedding) return;

    try {
      // Fetch guests stats
      const { data: guests } = await supabase
        .from("guests")
        .select("rsvp_status, plus_ones")
        .eq("wedding_id", activeWedding.id);

      // Fetch budget stats
      const { data: budgetItems } = await supabase
        .from("budget_items")
        .select("estimated_amount, actual_amount")
        .eq("wedding_id", activeWedding.id);

      // Fetch gifts stats
      const { data: gifts } = await supabase
        .from("gifts")
        .select("amount")
        .eq("wedding_id", activeWedding.id);

      // Fetch tasks for completeness check
      const { data: tasks } = await supabase
        .from("tasks")
        .select("id")
        .eq("wedding_id", activeWedding.id)
        .limit(1);

      // Calculate profile completeness
      setProfileCompleteness({
        hasWeddingDate: !!activeWedding.wedding_date,
        hasLocation: !!activeWedding.location,
        hasGuests: (guests?.length || 0) > 0,
        hasTasks: (tasks?.length || 0) > 0,
        hasBudget: (budgetItems?.length || 0) > 0,
      });

      if (guests) {
        const confirmed = guests.filter((g) => g.rsvp_status === "confirmed");
        const pending = guests.filter((g) => g.rsvp_status === "pending");
        const declined = guests.filter((g) => g.rsvp_status === "declined");
        const totalAttendees = confirmed.reduce(
          (acc, g) => acc + 1 + (g.plus_ones || 0),
          0
        );

        setStats((prev) => ({
          ...prev,
          totalGuests: guests.length,
          confirmed: confirmed.length,
          pending: pending.length,
          declined: declined.length,
          totalAttendees,
        }));
      }

      if (budgetItems) {
        const totalBudget = budgetItems.reduce(
          (acc, b) => acc + Number(b.estimated_amount || 0),
          0
        );
        const totalSpent = budgetItems.reduce(
          (acc, b) => acc + Number(b.actual_amount || 0),
          0
        );

        setStats((prev) => ({
          ...prev,
          totalBudget,
          totalSpent,
        }));
      }

      if (gifts) {
        const totalGifts = gifts.reduce(
          (acc, g) => acc + Number(g.amount || 0),
          0
        );

        setStats((prev) => ({
          ...prev,
          totalGifts,
        }));
      }
    } catch (error) {
      console.error("Error fetching stats:", error);
    } finally {
      setLoading(false);
    }
  };

  const copyWeddingCode = () => {
    if (activeWedding?.wedding_code) {
      navigator.clipboard.writeText(activeWedding.wedding_code);
      setCodeCopied(true);
      toast({
        title: "¡Código copiado!",
        description: "Comparte este código con tus invitados",
      });
      setTimeout(() => setCodeCopied(false), 2000);
    }
  };

  if (!activeWedding) return null;

  const handleNavigate = (section: string) => {
    if (onNavigate) {
      onNavigate(section);
    }
  };

  return (
    <div className="space-y-6">
      {/* Profile Completeness Alert */}
      <ProfileCompletenessAlert 
        stats={profileCompleteness} 
        onNavigate={handleNavigate} 
      />

      {/* Wedding Countdown */}
      <WeddingCountdown 
        weddingDate={activeWedding.wedding_date} 
        weddingName={activeWedding.name} 
      />

      {/* Header */}
      <div>
        <h1 className="text-2xl lg:text-3xl font-serif font-bold">
          {activeWedding.name}
        </h1>
        <p className="text-muted-foreground">
          Panel de control de tu boda
        </p>
      </div>

      {/* Wedding Code Card */}
      <Card className="bg-gradient-to-r from-primary/10 to-secondary/30 border-primary/20">
        <CardContent className="py-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <p className="text-sm text-muted-foreground mb-1">
                Código de invitación
              </p>
              <p className="text-2xl font-mono font-bold tracking-widest">
                {activeWedding.wedding_code}
              </p>
            </div>
            <Button variant="outline" onClick={copyWeddingCode}>
              {codeCopied ? (
                <Check className="w-4 h-4 mr-2" />
              ) : (
                <Copy className="w-4 h-4 mr-2" />
              )}
              {codeCopied ? "Copiado" : "Copiar"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">

        {/* Total Guests */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-blue-500/10">
                <Users className="w-6 h-6 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalGuests}</p>
                <p className="text-sm text-muted-foreground">invitados</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Confirmed */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-green-500/10">
                <CheckCircle2 className="w-6 h-6 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalAttendees}</p>
                <p className="text-sm text-muted-foreground">asistentes</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pending */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-amber-500/10">
                <Clock className="w-6 h-6 text-amber-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.pending}</p>
                <p className="text-sm text-muted-foreground">pendientes</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Financial Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Budget */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Wallet className="w-5 h-5 text-primary" />
              Presupuesto
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Estimado</span>
                <span className="font-medium">
                  {stats.totalBudget.toLocaleString("es-ES")} €
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Gastado</span>
                <span className="font-medium">
                  {stats.totalSpent.toLocaleString("es-ES")} €
                </span>
              </div>
              <div className="h-2 bg-secondary rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary transition-all"
                  style={{
                    width: `${Math.min(
                      (stats.totalSpent / stats.totalBudget) * 100 || 0,
                      100
                    )}%`,
                  }}
                />
              </div>
              <p className="text-sm text-muted-foreground text-right">
                Restante:{" "}
                <span className="font-medium text-foreground">
                  {(stats.totalBudget - stats.totalSpent).toLocaleString("es-ES")} €
                </span>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Gifts */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Gift className="w-5 h-5 text-primary" />
              Regalos Recibidos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">
              {stats.totalGifts.toLocaleString("es-ES")} €
            </p>
            <p className="text-sm text-muted-foreground">en aportaciones</p>
          </CardContent>
        </Card>

        {/* RSVP Breakdown */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              Estado de Confirmaciones
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                  <span>Confirmados</span>
                </div>
                <span className="font-medium">{stats.confirmed}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-500" />
                  <span>Pendientes</span>
                </div>
                <span className="font-medium">{stats.pending}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <XCircle className="w-4 h-4 text-red-500" />
                  <span>No asisten</span>
                </div>
                <span className="font-medium">{stats.declined}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
