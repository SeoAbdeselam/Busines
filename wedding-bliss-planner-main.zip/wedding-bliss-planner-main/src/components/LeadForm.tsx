import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Heart, Sparkles, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export const LeadForm = () => {
  const [formData, setFormData] = useState({
    nombre: "",
    email: "",
    telefono: "",
    fechaBoda: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    setIsSubmitting(false);
    setIsSuccess(true);
    
    toast({
      title: "¡Bienvenido/a! 💍",
      description: "Te hemos enviado un email con acceso a tu organizador.",
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  if (isSuccess) {
    return (
      <section id="registro" className="section-padding bg-gradient-to-b from-secondary/30 to-background">
        <div className="container-wedding">
          <div className="max-w-xl mx-auto text-center animate-scale-in">
            <div className="w-20 h-20 rounded-full bg-champagne/20 mx-auto mb-6 flex items-center justify-center">
              <Check className="w-10 h-10 text-champagne" />
            </div>
            <h2 className="text-3xl md:text-4xl font-serif font-semibold mb-4">
              ¡Ya casi está!
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              Revisa tu email para acceder a tu organizador de bodas personalizado.
            </p>
            <Button variant="outline" onClick={() => setIsSuccess(false)}>
              Registrar otra cuenta
            </Button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="registro" className="section-padding bg-gradient-to-b from-secondary/30 to-background relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-10 right-10 opacity-20">
        <Heart className="w-24 h-24 text-blush-deep" fill="currentColor" />
      </div>
      <div className="absolute bottom-10 left-10 opacity-20">
        <Sparkles className="w-20 h-20 text-champagne" />
      </div>

      <div className="container-wedding relative z-10">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <span className="text-champagne font-medium text-sm uppercase tracking-wider">
              Empieza gratis hoy
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-semibold mt-4 mb-6">
              Crea tu organizador
            </h2>
            <p className="text-muted-foreground text-lg">
              Regístrate y accede a todas las herramientas que necesitas para planificar tu boda perfecta.
            </p>
          </div>

          {/* Form Card */}
          <div className="card-wedding p-8 md:p-10">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">
                    Tu nombre
                  </label>
                  <Input
                    name="nombre"
                    placeholder="María García"
                    value={formData.nombre}
                    onChange={handleChange}
                    required
                    className="h-12 rounded-xl border-border/50 focus:border-champagne focus:ring-champagne"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">
                    Email
                  </label>
                  <Input
                    name="email"
                    type="email"
                    placeholder="maria@email.com"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="h-12 rounded-xl border-border/50 focus:border-champagne focus:ring-champagne"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">
                    Teléfono
                  </label>
                  <Input
                    name="telefono"
                    type="tel"
                    placeholder="+34 600 000 000"
                    value={formData.telefono}
                    onChange={handleChange}
                    required
                    className="h-12 rounded-xl border-border/50 focus:border-champagne focus:ring-champagne"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">
                    Fecha de boda (aproximada)
                  </label>
                  <Input
                    name="fechaBoda"
                    type="date"
                    value={formData.fechaBoda}
                    onChange={handleChange}
                    className="h-12 rounded-xl border-border/50 focus:border-champagne focus:ring-champagne"
                  />
                </div>
              </div>

              <Button 
                type="submit" 
                variant="hero" 
                className="w-full" 
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <span className="animate-spin">
                      <Heart className="w-5 h-5" />
                    </span>
                    Creando tu cuenta...
                  </>
                ) : (
                  <>
                    <Heart className="w-5 h-5" />
                    Acceder Gratis
                  </>
                )}
              </Button>

              <p className="text-xs text-center text-muted-foreground">
                Al registrarte aceptas nuestra{" "}
                <a href="#" className="text-champagne hover:underline">política de privacidad</a>
                {" "}y{" "}
                <a href="#" className="text-champagne hover:underline">términos de servicio</a>.
              </p>
            </form>
          </div>

          {/* Social Proof */}
          <div className="text-center mt-8">
            <p className="text-sm text-muted-foreground">
              Ya han confiado en nosotros <span className="font-semibold text-foreground">+2,500 parejas</span>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
