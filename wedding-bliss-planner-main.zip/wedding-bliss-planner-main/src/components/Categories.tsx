import { 
  Camera, 
  Flower2, 
  UtensilsCrossed, 
  Music, 
  Shirt,
  Car,
  Cake,
  Gem
} from "lucide-react";

const categories = [
  { icon: Camera, name: "Fotógrafos", count: "120+" },
  { icon: Flower2, name: "Floristerías", count: "85+" },
  { icon: UtensilsCrossed, name: "Catering", count: "95+" },
  { icon: Music, name: "Música y DJ", count: "60+" },
  { icon: Shirt, name: "Vestidos", count: "45+" },
  { icon: Car, name: "Transporte", count: "30+" },
  { icon: Cake, name: "Pastelería", count: "55+" },
  { icon: Gem, name: "Joyerías", count: "40+" },
];

export const Categories = () => {
  return (
    <section className="section-padding bg-cream">
      <div className="container-wedding">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-champagne font-medium text-sm uppercase tracking-wider">
            Profesionales verificados
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-semibold mt-4 mb-6">
            Encuentra a los mejores
          </h2>
          <p className="text-muted-foreground text-lg">
            Conecta con profesionales de confianza que harán realidad tu sueño.
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 lg:gap-6">
          {categories.map((category) => (
            <div 
              key={category.name}
              className="group cursor-pointer"
            >
              <div className="card-wedding p-6 text-center">
                <div className="w-16 h-16 rounded-full bg-blush mx-auto mb-4 flex items-center justify-center group-hover:bg-blush-deep transition-colors">
                  <category.icon className="w-8 h-8 text-blush-deep group-hover:text-primary-foreground transition-colors" />
                </div>
                <h3 className="font-serif font-semibold text-lg mb-1">
                  {category.name}
                </h3>
                <span className="text-sm text-muted-foreground">
                  {category.count} profesionales
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Coming Soon Badge */}
        <div className="text-center mt-12">
          <span className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-secondary border border-champagne-light/30 text-muted-foreground">
            <span className="w-2 h-2 rounded-full bg-champagne animate-pulse" />
            Próximamente más categorías
          </span>
        </div>
      </div>
    </section>
  );
};
