import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useProfessionalAuth } from "@/contexts/ProfessionalAuthContext";
import { Button } from "@/components/ui/button";
import { 
  Heart, 
  Home, 
  User,
  Image,
  MessageSquare,
  Users,
  Star,
  BarChart3,
  Settings,
  LogOut,
  Menu,
  X,
  Crown
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface ProDashboardLayoutProps {
  children: React.ReactNode;
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const navItems = [
  { id: "home", label: "Inicio", icon: Home },
  { id: "profile", label: "Mi Perfil", icon: User },
  { id: "gallery", label: "Galería", icon: Image },
  { id: "messages", label: "Mensajes", icon: MessageSquare },
  { id: "clients", label: "Clientes", icon: Users },
  { id: "reviews", label: "Reseñas", icon: Star },
  { id: "stats", label: "Estadísticas", icon: BarChart3 },
  { id: "subscription", label: "Suscripción", icon: Crown },
  { id: "settings", label: "Ajustes", icon: Settings },
];

export function ProDashboardLayout({
  children,
  activeSection,
  onSectionChange,
}: ProDashboardLayoutProps) {
  const { signOut, professional, isPremium } = useProfessionalAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = async () => {
    await signOut();
    navigate("/pro/auth");
  };

  const handleNavClick = (id: string) => {
    onSectionChange(id);
    setSidebarOpen(false);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Header */}
      <header className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-card border-b border-border z-50 flex items-center justify-between px-4">
        <button
          onClick={() => setSidebarOpen(true)}
          className="p-2 hover:bg-secondary rounded-lg"
        >
          <Menu className="w-6 h-6" />
        </button>
        <div className="flex items-center gap-2">
          <Heart className="w-6 h-6 text-primary" fill="currentColor" />
          <span className="font-serif font-semibold">Loba Ball Pro</span>
        </div>
        <div className="w-10" />
      </header>

      {/* Sidebar Overlay */}
      {sidebarOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full w-64 bg-card border-r border-border z-50 transform transition-transform duration-300 lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="h-16 flex items-center justify-between px-4 border-b border-border">
            <Link to="/" className="flex items-center gap-2">
              <Heart className="w-6 h-6 text-primary" fill="currentColor" />
              <span className="font-serif font-semibold text-lg">Loba Ball</span>
              <Badge variant="secondary" className="text-xs">PRO</Badge>
            </Link>
            <button
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden p-2 hover:bg-secondary rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Business Info */}
          <div className="p-4 border-b border-border">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <User className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{professional?.business_name || "Tu Negocio"}</p>
                <div className="flex items-center gap-2">
                  {isPremium ? (
                    <Badge className="bg-gradient-to-r from-amber-500 to-amber-600 text-white text-xs">
                      <Crown className="w-3 h-3 mr-1" />
                      Premium
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-xs">Gratuito</Badge>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              const isStatsLocked = item.id === "stats" && !isPremium;
              
              return (
                <button
                  key={item.id}
                  onClick={() => !isStatsLocked && handleNavClick(item.id)}
                  disabled={isStatsLocked}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : isStatsLocked
                      ? "opacity-50 cursor-not-allowed text-muted-foreground"
                      : "hover:bg-secondary text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                  {isStatsLocked && (
                    <Crown className="w-4 h-4 ml-auto text-amber-500" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Upgrade Banner (for free users) */}
          {!isPremium && (
            <div className="p-4 border-t border-border">
              <div className="p-3 rounded-lg bg-gradient-to-r from-amber-500/10 to-amber-600/10 border border-amber-500/20">
                <p className="text-sm font-medium text-amber-700 dark:text-amber-300">
                  ¿Quieres más clientes?
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Desbloquea datos de contacto y más
                </p>
                <Button 
                  size="sm" 
                  className="w-full mt-2 bg-gradient-to-r from-amber-500 to-amber-600"
                  onClick={() => onSectionChange("subscription")}
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Mejorar Plan
                </Button>
              </div>
            </div>
          )}

          {/* Logout */}
          <div className="p-4 border-t border-border">
            <Button
              variant="ghost"
              className="w-full justify-start text-muted-foreground"
              onClick={handleLogout}
            >
              <LogOut className="w-5 h-5 mr-3" />
              Cerrar sesión
            </Button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:ml-64 pt-16 lg:pt-0 min-h-screen">
        <div className="p-4 lg:p-8">{children}</div>
      </main>
    </div>
  );
}
