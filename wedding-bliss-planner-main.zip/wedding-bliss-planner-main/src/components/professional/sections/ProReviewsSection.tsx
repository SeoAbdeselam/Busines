import { useState, useEffect } from "react";
import { useProfessionalAuth } from "@/contexts/ProfessionalAuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Star, MessageSquare } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

interface Review {
  id: string;
  professional_id: string;
  contract_id: string;
  rating: number;
  title: string | null;
  content: string | null;
  response: string | null;
  response_at: string | null;
  is_verified: boolean;
  created_at: string;
  wedding?: {
    name: string;
  };
}

export function ProReviewsSection() {
  const { professional, refreshProfessional } = useProfessionalAuth();
  const { toast } = useToast();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [respondingTo, setRespondingTo] = useState<string | null>(null);
  const [responseText, setResponseText] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (professional) {
      fetchReviews();
    }
  }, [professional]);

  const fetchReviews = async () => {
    if (!professional) return;

    try {
      const { data, error } = await supabase
        .from("professional_reviews")
        .select(`
          *,
          wedding:weddings(name)
        `)
        .eq("professional_id", professional.id)
        .eq("is_published", true)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setReviews(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRespond = async (reviewId: string) => {
    if (!responseText.trim()) return;

    setSaving(true);
    try {
      const { error } = await supabase
        .from("professional_reviews")
        .update({ 
          response: responseText.trim(),
          response_at: new Date().toISOString()
        })
        .eq("id", reviewId);

      if (error) throw error;

      toast({
        title: "Respuesta publicada",
      });
      setRespondingTo(null);
      setResponseText("");
      fetchReviews();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="animate-pulse">Cargando reseñas...</div>;
  }

  const averageRating = reviews.length > 0
    ? (reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length).toFixed(1)
    : "—";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-serif font-semibold">Reseñas</h1>
        <p className="text-muted-foreground">
          Opiniones verificadas de tus clientes
        </p>
      </div>

      {/* Summary */}
      <Card>
        <CardContent className="flex items-center gap-6 p-6">
          <div className="text-center">
            <div className="flex items-center gap-1 mb-1">
              <Star className="w-8 h-8 text-amber-500 fill-amber-500" />
              <span className="text-4xl font-bold">{averageRating}</span>
            </div>
            <p className="text-sm text-muted-foreground">{reviews.length} reseñas</p>
          </div>
          <div className="flex-1">
            {[5, 4, 3, 2, 1].map((stars) => {
              const count = reviews.filter(r => r.rating === stars).length;
              const percentage = reviews.length > 0 ? (count / reviews.length) * 100 : 0;
              return (
                <div key={stars} className="flex items-center gap-2 text-sm">
                  <span className="w-6">{stars}★</span>
                  <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-amber-500 rounded-full"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                  <span className="w-8 text-muted-foreground">{count}</span>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {reviews.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <Star className="w-12 h-12 text-muted-foreground mb-4" />
            <h3 className="font-medium mb-2">Sin reseñas todavía</h3>
            <p className="text-sm text-muted-foreground">
              Cuando completes trabajos, tus clientes podrán dejarte reseñas verificadas
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {reviews.map((review) => (
            <Card key={review.id}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < review.rating 
                                ? "text-amber-500 fill-amber-500" 
                                : "text-muted-foreground"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="font-medium">{review.wedding?.name || "Cliente"}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {format(new Date(review.created_at), "dd MMMM yyyy", { locale: es })}
                    </p>
                  </div>
                  {review.is_verified && (
                    <span className="text-xs bg-green-500/10 text-green-600 px-2 py-1 rounded-full">
                      ✓ Verificada
                    </span>
                  )}
                </div>

                {review.title && (
                  <h4 className="font-medium mb-2">{review.title}</h4>
                )}
                {review.content && (
                  <p className="text-muted-foreground mb-4">{review.content}</p>
                )}

                {/* Response */}
                {review.response ? (
                  <div className="mt-4 p-4 bg-secondary/50 rounded-lg">
                    <p className="text-sm font-medium mb-2">Tu respuesta:</p>
                    <p className="text-sm text-muted-foreground">{review.response}</p>
                  </div>
                ) : respondingTo === review.id ? (
                  <div className="mt-4 space-y-2">
                    <Textarea
                      value={responseText}
                      onChange={(e) => setResponseText(e.target.value)}
                      placeholder="Escribe tu respuesta..."
                      rows={3}
                    />
                    <div className="flex gap-2">
                      <Button 
                        size="sm"
                        onClick={() => handleRespond(review.id)}
                        disabled={saving}
                      >
                        {saving ? "Guardando..." : "Publicar respuesta"}
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => {
                          setRespondingTo(null);
                          setResponseText("");
                        }}
                      >
                        Cancelar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => setRespondingTo(review.id)}
                  >
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Responder
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
