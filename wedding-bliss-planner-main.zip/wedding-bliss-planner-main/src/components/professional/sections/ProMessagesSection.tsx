import { useState, useEffect } from "react";
import { useProfessionalAuth } from "@/contexts/ProfessionalAuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { 
  MessageSquare, 
  Send, 
  Eye, 
  EyeOff, 
  Crown,
  Mail,
  Phone
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";

interface Conversation {
  id: string;
  professional_id: string;
  wedding_id: string;
  client_user_id: string;
  last_message_at: string;
  professional_unread: number;
  wedding?: {
    name: string;
  };
  client_profile?: {
    full_name: string | null;
    email: string;
    phone: string;
  } | null;
}

interface Message {
  id: string;
  conversation_id: string;
  sender_type: string;
  content: string;
  is_read: boolean;
  created_at: string;
}

export function ProMessagesSection() {
  const { professional, isPremium } = useProfessionalAuth();
  const { toast } = useToast();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (professional) {
      fetchConversations();
    }
  }, [professional]);

  useEffect(() => {
    if (selectedConversation) {
      fetchMessages(selectedConversation.id);
    }
  }, [selectedConversation]);

  const fetchConversations = async () => {
    if (!professional) return;

    try {
      const { data, error } = await supabase
        .from("professional_conversations")
        .select(`
          *,
          wedding:weddings(name)
        `)
        .eq("professional_id", professional.id)
        .order("last_message_at", { ascending: false });

      if (error) throw error;

      // If premium, fetch client profiles
      let convsWithProfiles = data || [];
      if (isPremium && data && data.length > 0) {
        const clientIds = [...new Set(data.map(c => c.client_user_id))];
        const { data: profiles } = await supabase
          .from("profiles")
          .select("id, full_name, email, phone")
          .in("id", clientIds);

        if (profiles) {
          const profileMap = new Map(profiles.map(p => [p.id, p]));
          convsWithProfiles = data.map(c => ({
            ...c,
            client_profile: profileMap.get(c.client_user_id) || null
          }));
        }
      }

      setConversations(convsWithProfiles);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async (conversationId: string) => {
    try {
      const { data, error } = await supabase
        .from("professional_messages")
        .select("*")
        .eq("conversation_id", conversationId)
        .order("created_at", { ascending: true });

      if (error) throw error;
      setMessages(data || []);

      // Mark as read
      await supabase
        .from("professional_conversations")
        .update({ professional_unread: 0 })
        .eq("id", conversationId);
    } catch (error: any) {
      console.error("Error fetching messages:", error);
    }
  };

  const handleSendMessage = async () => {
    if (!selectedConversation || !newMessage.trim() || !professional) return;

    setSending(true);
    try {
      const { error } = await supabase
        .from("professional_messages")
        .insert({
          conversation_id: selectedConversation.id,
          sender_type: "professional",
          sender_id: professional.user_id,
          content: newMessage.trim(),
        });

      if (error) throw error;

      // Update last message time
      await supabase
        .from("professional_conversations")
        .update({ 
          last_message_at: new Date().toISOString(),
          client_unread: selectedConversation.client_user_id ? 1 : 0
        })
        .eq("id", selectedConversation.id);

      setNewMessage("");
      fetchMessages(selectedConversation.id);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSending(false);
    }
  };

  if (loading) {
    return <div className="animate-pulse">Cargando mensajes...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-serif font-semibold">Mensajes</h1>
        <p className="text-muted-foreground">
          Comunicación con clientes interesados
        </p>
      </div>

      {conversations.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <MessageSquare className="w-12 h-12 text-muted-foreground mb-4" />
            <h3 className="font-medium mb-2">Sin mensajes todavía</h3>
            <p className="text-sm text-muted-foreground">
              Cuando los clientes te contacten, verás sus mensajes aquí
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-3 gap-4 h-[600px]">
          {/* Conversation List */}
          <Card className="md:col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Conversaciones</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[520px]">
                {conversations.map((conv) => (
                  <button
                    key={conv.id}
                    onClick={() => setSelectedConversation(conv)}
                    className={`w-full p-4 text-left border-b hover:bg-secondary/50 transition-colors ${
                      selectedConversation?.id === conv.id ? "bg-secondary" : ""
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium truncate">
                        {conv.wedding?.name || "Cliente"}
                      </span>
                      {conv.professional_unread > 0 && (
                        <Badge className="ml-2">{conv.professional_unread}</Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(conv.last_message_at), { 
                        addSuffix: true, 
                        locale: es 
                      })}
                    </p>
                  </button>
                ))}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Messages */}
          <Card className="md:col-span-2 flex flex-col">
            {selectedConversation ? (
              <>
                <CardHeader className="border-b">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">
                        {selectedConversation.client_profile?.full_name || selectedConversation.wedding?.name || "Cliente"}
                      </CardTitle>
                      {/* Contact info - only for premium */}
                      {isPremium && selectedConversation.client_profile ? (
                        <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Mail className="w-3 h-3" />
                            {selectedConversation.client_profile.email}
                          </span>
                          {selectedConversation.client_profile.phone && (
                            <span className="flex items-center gap-1">
                              <Phone className="w-3 h-3" />
                              {selectedConversation.client_profile.phone}
                            </span>
                          )}
                        </div>
                      ) : !isPremium ? (
                        <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                          <EyeOff className="w-3 h-3" />
                          Datos de contacto ocultos
                          <Badge variant="outline" className="text-xs">
                            <Crown className="w-3 h-3 mr-1" />
                            Premium
                          </Badge>
                        </div>
                      ) : null}
                    </div>
                  </div>
                </CardHeader>
                <ScrollArea className="flex-1 p-4">
                  <div className="space-y-4">
                    {messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex ${
                          msg.sender_type === "professional" ? "justify-end" : "justify-start"
                        }`}
                      >
                        <div
                          className={`max-w-[80%] p-3 rounded-lg ${
                            msg.sender_type === "professional"
                              ? "bg-primary text-primary-foreground"
                              : "bg-secondary"
                          }`}
                        >
                          <p className="text-sm">{msg.content}</p>
                          <p className={`text-xs mt-1 ${
                            msg.sender_type === "professional" 
                              ? "text-primary-foreground/70" 
                              : "text-muted-foreground"
                          }`}>
                            {formatDistanceToNow(new Date(msg.created_at), { 
                              addSuffix: true, 
                              locale: es 
                            })}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
                <div className="p-4 border-t">
                  <div className="flex gap-2">
                    <Textarea
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Escribe tu mensaje..."
                      rows={2}
                      className="resize-none"
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                    />
                    <Button 
                      onClick={handleSendMessage} 
                      disabled={sending || !newMessage.trim()}
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              <CardContent className="flex-1 flex items-center justify-center text-muted-foreground">
                Selecciona una conversación
              </CardContent>
            )}
          </Card>
        </div>
      )}
    </div>
  );
}
