import { useState, useEffect } from "react";
import { useProfessionalAuth } from "@/contexts/ProfessionalAuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { 
  Users, 
  Calendar, 
  DollarSign, 
  CheckCircle2,
  Clock,
  XCircle,
  Crown,
  Mail,
  Phone,
  Eye,
  EyeOff
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

interface Contract {
  id: string;
  professional_id: string;
  wedding_id: string;
  client_user_id: string;
  status: string;
  service_description: string | null;
  estimated_cost: number;
  actual_cost: number | null;
  service_date: string | null;
  contracted_at: string | null;
  wedding?: {
    name: string;
    wedding_date: string | null;
  };
  client_profile?: {
    full_name: string | null;
    email: string;
    phone: string;
  };
}

const STATUS_CONFIG = {
  interested: { label: "Interesado", icon: Clock, color: "bg-blue-500" },
  contacted: { label: "Contactado", icon: Clock, color: "bg-yellow-500" },
  contracted: { label: "Contratado", icon: CheckCircle2, color: "bg-green-500" },
  completed: { label: "Completado", icon: CheckCircle2, color: "bg-primary" },
  cancelled: { label: "Cancelado", icon: XCircle, color: "bg-destructive" },
};

export function ProClientsSection() {
  const { professional, isPremium } = useProfessionalAuth();
  const { toast } = useToast();
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (professional) {
      fetchContracts();
    }
  }, [professional]);

  const fetchContracts = async () => {
    if (!professional) return;

    try {
      const { data, error } = await supabase
        .from("professional_contracts")
        .select(`
          *,
          wedding:weddings(name, wedding_date)
        `)
        .eq("professional_id", professional.id)
        .order("created_at", { ascending: false });

      if (error) throw error;

      // If premium, fetch client profiles
      let contractsWithProfiles = data || [];
      if (isPremium && data && data.length > 0) {
        const clientIds = [...new Set(data.map(c => c.client_user_id))];
        const { data: profiles } = await supabase
          .from("profiles")
          .select("id, full_name, email, phone")
          .in("id", clientIds);

        if (profiles) {
          const profileMap = new Map(profiles.map(p => [p.id, p]));
          contractsWithProfiles = data.map(c => ({
            ...c,
            client_profile: profileMap.get(c.client_user_id) || undefined
          }));
        }
      }

      setContracts(contractsWithProfiles);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (contractId: string, newStatus: string) => {
    try {
      const updates: any = { status: newStatus };
      if (newStatus === "contracted") {
        updates.contracted_at = new Date().toISOString();
      } else if (newStatus === "completed") {
        updates.completed_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from("professional_contracts")
        .update(updates)
        .eq("id", contractId);

      if (error) throw error;

      fetchContracts();
      toast({
        title: "Estado actualizado",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return <div className="animate-pulse">Cargando clientes...</div>;
  }

  const contracted = contracts.filter(c => c.status === "contracted" || c.status === "completed");
  const interested = contracts.filter(c => c.status === "interested" || c.status === "contacted");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-serif font-semibold">Clientes</h1>
        <p className="text-muted-foreground">
          Gestiona tus contrataciones y clientes interesados
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{contracted.length}</p>
                <p className="text-xs text-muted-foreground">Contratados</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                <Clock className="w-5 h-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{interested.length}</p>
                <p className="text-xs text-muted-foreground">Interesados</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {contracts.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <Users className="w-12 h-12 text-muted-foreground mb-4" />
            <h3 className="font-medium mb-2">Sin clientes todavía</h3>
            <p className="text-sm text-muted-foreground">
              Cuando las parejas te contraten, aparecerán aquí
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {contracts.map((contract) => {
            const statusConfig = STATUS_CONFIG[contract.status as keyof typeof STATUS_CONFIG] || STATUS_CONFIG.interested;
            const StatusIcon = statusConfig.icon;

            return (
              <Card key={contract.id}>
                <CardContent className="p-4">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-medium">{contract.wedding?.name || "Boda"}</h3>
                        <Badge className={statusConfig.color}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {statusConfig.label}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        {contract.wedding?.wedding_date && (
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Calendar className="w-4 h-4" />
                            {format(new Date(contract.wedding.wedding_date), "dd MMM yyyy", { locale: es })}
                          </div>
                        )}
                        {contract.estimated_cost > 0 && (
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <DollarSign className="w-4 h-4" />
                            {contract.estimated_cost.toLocaleString("es-ES")} €
                          </div>
                        )}
                        {/* Contact info - premium only */}
                        {isPremium && contract.client_profile ? (
                          <>
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Mail className="w-4 h-4" />
                              {contract.client_profile.email}
                            </div>
                            {contract.client_profile.phone && (
                              <div className="flex items-center gap-2 text-muted-foreground">
                                <Phone className="w-4 h-4" />
                                {contract.client_profile.phone}
                              </div>
                            )}
                          </>
                        ) : !isPremium ? (
                          <div className="flex items-center gap-2 text-muted-foreground col-span-2">
                            <EyeOff className="w-4 h-4" />
                            Datos ocultos
                            <Badge variant="outline" className="text-xs">
                              <Crown className="w-3 h-3 mr-1" />
                              Premium
                            </Badge>
                          </div>
                        ) : null}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2">
                      {contract.status === "interested" && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => updateStatus(contract.id, "contacted")}
                        >
                          Marcar contactado
                        </Button>
                      )}
                      {contract.status === "contacted" && (
                        <Button 
                          size="sm"
                          onClick={() => updateStatus(contract.id, "contracted")}
                        >
                          Confirmar contrato
                        </Button>
                      )}
                      {contract.status === "contracted" && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => updateStatus(contract.id, "completed")}
                        >
                          Marcar completado
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
