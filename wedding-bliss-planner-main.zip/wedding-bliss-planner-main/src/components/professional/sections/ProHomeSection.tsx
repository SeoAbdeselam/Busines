import { useState, useEffect } from "react";
import { useProfessionalAuth } from "@/contexts/ProfessionalAuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  Eye, 
  MessageSquare, 
  Users, 
  Star,
  TrendingUp,
  Crown,
  AlertTriangle,
  CheckCircle2
} from "lucide-react";
import { getCategoryLabel } from "@/lib/professionalCategories";

export function ProHomeSection() {
  const { professional, isPremium } = useProfessionalAuth();
  const [galleryCount, setGalleryCount] = useState(0);

  useEffect(() => {
    if (professional) {
      fetchGalleryCount();
    }
  }, [professional]);

  const fetchGalleryCount = async () => {
    if (!professional) return;
    const { count } = await supabase
      .from("professional_gallery")
      .select("*", { count: "exact", head: true })
      .eq("professional_id", professional.id);
    setGalleryCount(count || 0);
  };

  // Calcular requisitos de perfil completo
  const profileChecks = {
    hasName: !!professional?.business_name,
    hasCategory: !!professional?.primary_category,
    hasCity: !!professional?.city,
    hasDescription: !!professional?.description,
    hasGallery: galleryCount > 0,
  };
  
  const isProfileComplete = Object.values(profileChecks).every(Boolean);
  const completedSteps = Object.values(profileChecks).filter(Boolean).length;
  const totalSteps = Object.values(profileChecks).length;

  const stats = [
    {
      label: "Visitas al perfil",
      value: professional?.views_count || 0,
      icon: Eye,
      change: "+12%",
      locked: false,
    },
    {
      label: "Mensajes recibidos",
      value: professional?.contacts_count || 0,
      icon: MessageSquare,
      change: "+5%",
      locked: false,
    },
    {
      label: "Clientes contratados",
      value: professional?.total_contracts || 0,
      icon: Users,
      change: "+2",
      locked: false,
    },
    {
      label: "Valoración media",
      value: professional?.average_rating || "—",
      icon: Star,
      change: `${professional?.total_reviews || 0} reseñas`,
      locked: false,
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-serif font-semibold">
          ¡Hola, {professional?.business_name}!
        </h1>
        <p className="text-muted-foreground">
          Aquí tienes un resumen de tu actividad
        </p>
      </div>

      {/* Profile Completion Alert */}
      {!isProfileComplete && (
        <Alert variant="destructive" className="border-amber-500/50 bg-amber-500/10 text-foreground">
          <AlertTriangle className="h-4 w-4 text-amber-500" />
          <AlertTitle className="text-amber-600 font-semibold">
            Perfil incompleto ({completedSteps}/{totalSteps})
          </AlertTitle>
          <AlertDescription className="text-muted-foreground">
            Tu perfil no aparecerá en el directorio público hasta que completes todos los campos obligatorios:
            <ul className="mt-2 space-y-1 text-sm">
              <li className="flex items-center gap-2">
                {profileChecks.hasName ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <span className="w-4 h-4 rounded-full border-2 border-muted-foreground/30" />}
                Nombre comercial
              </li>
              <li className="flex items-center gap-2">
                {profileChecks.hasCategory ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <span className="w-4 h-4 rounded-full border-2 border-muted-foreground/30" />}
                Categoría principal
              </li>
              <li className="flex items-center gap-2">
                {profileChecks.hasCity ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <span className="w-4 h-4 rounded-full border-2 border-muted-foreground/30" />}
                Ciudad
              </li>
              <li className="flex items-center gap-2">
                {profileChecks.hasDescription ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <span className="w-4 h-4 rounded-full border-2 border-muted-foreground/30" />}
                Descripción del negocio
              </li>
              <li className="flex items-center gap-2">
                {profileChecks.hasGallery ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <span className="w-4 h-4 rounded-full border-2 border-muted-foreground/30" />}
                Al menos 1 imagen en la galería
              </li>
            </ul>
          </AlertDescription>
        </Alert>
      )}

      {isProfileComplete && (
        <Alert className="border-green-500/50 bg-green-500/10">
          <CheckCircle2 className="h-4 w-4 text-green-500" />
          <AlertTitle className="text-green-600 font-semibold">
            ¡Perfil completo!
          </AlertTitle>
          <AlertDescription className="text-muted-foreground">
            Tu perfil está visible en el directorio público de profesionales.
          </AlertDescription>
        </Alert>
      )}

      {/* Plan Status */}
      <Card className={isPremium ? "border-amber-500/50 bg-gradient-to-r from-amber-500/5 to-amber-600/5" : ""}>
        <CardContent className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              isPremium ? "bg-amber-500/20" : "bg-secondary"
            }`}>
              <Crown className={`w-5 h-5 ${isPremium ? "text-amber-500" : "text-muted-foreground"}`} />
            </div>
            <div>
              <p className="font-medium">
                Plan {isPremium ? "Premium" : "Gratuito"}
              </p>
              <p className="text-sm text-muted-foreground">
                {isPremium 
                  ? "Acceso completo a todas las funciones" 
                  : "Mejora para desbloquear más funciones"
                }
              </p>
            </div>
          </div>
          <Badge variant={isPremium ? "default" : "outline"} className={isPremium ? "bg-amber-500" : ""}>
            {getCategoryLabel(professional?.primary_category || "")}
          </Badge>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.label}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <stat.icon className="w-5 h-5 text-muted-foreground" />
                {!stat.locked && (
                  <span className="text-xs text-green-500 flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    {stat.change}
                  </span>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Próximos pasos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {!professional?.description && (
              <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium">
                  1
                </div>
                <div className="flex-1">
                  <p className="font-medium">Completa tu perfil</p>
                  <p className="text-sm text-muted-foreground">
                    Añade una descripción para que los clientes te conozcan
                  </p>
                </div>
              </div>
            )}
            <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium">
                2
              </div>
              <div className="flex-1">
                <p className="font-medium">Sube fotos a tu galería</p>
                <p className="text-sm text-muted-foreground">
                  Muestra tu trabajo con imágenes de calidad
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium">
                3
              </div>
              <div className="flex-1">
                <p className="font-medium">Conecta tus redes sociales</p>
                <p className="text-sm text-muted-foreground">
                  Instagram, TikTok, web...
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
