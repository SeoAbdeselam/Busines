import { useProfessionalAuth } from "@/contexts/ProfessionalAuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Crown, 
  Check, 
  X,
  Eye,
  Mail,
  Phone,
  MessageSquare,
  Star,
  BarChart3,
  Image
} from "lucide-react";

const FEATURES = [
  { name: "Perfil público visible", free: true, premium: true, icon: Eye },
  { name: "Galería de fotos", free: "10 máx", premium: "Ilimitadas", icon: Image },
  { name: "Galería de vídeos", free: "2 máx", premium: "Ilimitados", icon: Image },
  { name: "Recibir mensajes", free: true, premium: true, icon: MessageSquare },
  { name: "Ver email del cliente", free: false, premium: true, icon: Mail },
  { name: "Ver teléfono del cliente", free: false, premium: true, icon: Phone },
  { name: "Contacto por WhatsApp", free: false, premium: true, icon: Phone },
  { name: "Perfil destacado", free: false, premium: true, icon: Star },
  { name: "Estadísticas avanzadas", free: false, premium: true, icon: BarChart3 },
  { name: "Varias categorías", free: false, premium: true, icon: Check },
];

export function ProSubscriptionSection() {
  const { subscription, isPremium, professional } = useProfessionalAuth();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-serif font-semibold">Suscripción</h1>
        <p className="text-muted-foreground">
          Gestiona tu plan y desbloquea más funciones
        </p>
      </div>

      {/* Current Plan */}
      <Card className={isPremium ? "border-amber-500/50 bg-gradient-to-r from-amber-500/5 to-amber-600/5" : ""}>
        <CardContent className="flex items-center justify-between p-6">
          <div className="flex items-center gap-4">
            <div className={`w-14 h-14 rounded-full flex items-center justify-center ${
              isPremium ? "bg-gradient-to-r from-amber-500 to-amber-600" : "bg-secondary"
            }`}>
              <Crown className={`w-7 h-7 ${isPremium ? "text-white" : "text-muted-foreground"}`} />
            </div>
            <div>
              <h3 className="text-xl font-semibold">
                Plan {isPremium ? "Premium" : "Gratuito"}
              </h3>
              <p className="text-muted-foreground">
                {isPremium 
                  ? "Acceso completo a todas las funciones"
                  : "Funcionalidades básicas incluidas"
                }
              </p>
            </div>
          </div>
          {isPremium && subscription?.expires_at && (
            <Badge variant="outline">
              Expira: {new Date(subscription.expires_at).toLocaleDateString("es-ES")}
            </Badge>
          )}
        </CardContent>
      </Card>

      {/* Plans Comparison */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Free Plan */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Plan Gratuito
              {!isPremium && <Badge variant="secondary">Actual</Badge>}
            </CardTitle>
            <CardDescription>
              Empieza gratis y recibe contactos
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold mb-6">0€<span className="text-lg font-normal text-muted-foreground">/mes</span></div>
            <ul className="space-y-3">
              {FEATURES.map((feature) => (
                <li key={feature.name} className="flex items-center gap-3 text-sm">
                  {feature.free === true ? (
                    <Check className="w-4 h-4 text-green-500" />
                  ) : feature.free === false ? (
                    <X className="w-4 h-4 text-muted-foreground" />
                  ) : (
                    <span className="w-4 h-4 text-xs text-center text-muted-foreground">{feature.free}</span>
                  )}
                  <span className={feature.free ? "" : "text-muted-foreground"}>
                    {feature.name}
                  </span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Premium Plan */}
        <Card className="border-amber-500/50 relative overflow-hidden">
          <div className="absolute top-0 right-0 bg-gradient-to-r from-amber-500 to-amber-600 text-white text-xs px-3 py-1 rounded-bl-lg">
            Recomendado
          </div>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-amber-500" />
              Plan Premium
              {isPremium && <Badge className="bg-amber-500">Actual</Badge>}
            </CardTitle>
            <CardDescription>
              Desbloquea todo el potencial
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold mb-2">Contactar</div>
            <p className="text-sm text-muted-foreground mb-6">
              Pago por transferencia o QR
            </p>
            <ul className="space-y-3 mb-6">
              {FEATURES.map((feature) => (
                <li key={feature.name} className="flex items-center gap-3 text-sm">
                  {feature.premium === true ? (
                    <Check className="w-4 h-4 text-green-500" />
                  ) : (
                    <span className="w-4 h-4 text-xs text-center text-amber-500">{feature.premium}</span>
                  )}
                  <span>{feature.name}</span>
                </li>
              ))}
            </ul>
            {!isPremium && (
              <Button className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700">
                <Crown className="w-4 h-4 mr-2" />
                Solicitar Premium
              </Button>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Payment Info */}
      <Card>
        <CardHeader>
          <CardTitle>¿Cómo funciona el pago?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-muted-foreground">
          <p>
            El plan Premium se activa mediante pago por <strong>transferencia bancaria</strong> o <strong>QR de pago</strong>.
          </p>
          <ol className="list-decimal list-inside space-y-2">
            <li>Solicita el plan Premium haciendo clic en el botón</li>
            <li>Recibirás los datos de pago por email</li>
            <li>Realiza la transferencia o pago por QR</li>
            <li>Tu plan se activará en 24-48 horas</li>
          </ol>
        </CardContent>
      </Card>
    </div>
  );
}
