import { useProfessionalAuth } from "@/contexts/ProfessionalAuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useState } from "react";

export function ProSettingsSection() {
  const { professional, refreshProfessional } = useProfessionalAuth();
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [isActive, setIsActive] = useState(professional?.is_active ?? true);

  const handleToggleActive = async () => {
    if (!professional) return;
    
    setSaving(true);
    try {
      const { error } = await supabase
        .from("professionals")
        .update({ is_active: !isActive })
        .eq("id", professional.id);

      if (error) throw error;

      setIsActive(!isActive);
      await refreshProfessional();
      toast({
        title: isActive ? "Perfil desactivado" : "Perfil activado",
        description: isActive 
          ? "Tu perfil ya no es visible públicamente"
          : "Tu perfil ahora es visible para los clientes",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-serif font-semibold">Ajustes</h1>
        <p className="text-muted-foreground">
          Configura tu cuenta y preferencias
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Visibilidad del perfil</CardTitle>
          <CardDescription>
            Controla si tu perfil es visible públicamente
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="active-toggle">Perfil activo</Label>
              <p className="text-sm text-muted-foreground">
                {isActive 
                  ? "Tu perfil es visible para los clientes"
                  : "Tu perfil está oculto"
                }
              </p>
            </div>
            <Switch
              id="active-toggle"
              checked={isActive}
              onCheckedChange={handleToggleActive}
              disabled={saving}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Notificaciones</CardTitle>
          <CardDescription>
            Elige qué notificaciones quieres recibir
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Nuevos mensajes</Label>
              <p className="text-sm text-muted-foreground">
                Recibe un email cuando te envíen un mensaje
              </p>
            </div>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <Label>Nuevas contrataciones</Label>
              <p className="text-sm text-muted-foreground">
                Recibe un email cuando te contraten
              </p>
            </div>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <Label>Nuevas reseñas</Label>
              <p className="text-sm text-muted-foreground">
                Recibe un email cuando te dejen una reseña
              </p>
            </div>
            <Switch defaultChecked />
          </div>
        </CardContent>
      </Card>

      <Card className="border-destructive/50">
        <CardHeader>
          <CardTitle className="text-destructive">Zona de peligro</CardTitle>
          <CardDescription>
            Acciones irreversibles
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button variant="destructive">
            Eliminar cuenta
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
