import { useProfessionalAuth } from "@/contexts/ProfessionalAuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { 
  Eye, 
  MessageSquare, 
  Users, 
  TrendingUp,
  Crown
} from "lucide-react";

export function ProStatsSection() {
  const { professional, isPremium } = useProfessionalAuth();

  if (!isPremium) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-serif font-semibold">Estadísticas</h1>
          <p className="text-muted-foreground">
            Analiza el rendimiento de tu perfil
          </p>
        </div>

        <Card className="border-amber-500/50">
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <div className="w-16 h-16 rounded-full bg-amber-500/10 flex items-center justify-center mb-4">
              <Crown className="w-8 h-8 text-amber-500" />
            </div>
            <h3 className="text-xl font-medium mb-2">Función Premium</h3>
            <p className="text-muted-foreground mb-4 max-w-md">
              Mejora tu plan para acceder a estadísticas detalladas: visitas, conversiones, tendencias y más.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Premium stats view
  const stats = [
    { label: "Visitas este mes", value: professional?.views_count || 0, change: "+15%", icon: Eye },
    { label: "Mensajes recibidos", value: professional?.contacts_count || 0, change: "+8%", icon: MessageSquare },
    { label: "Contrataciones", value: professional?.total_contracts || 0, change: "+2", icon: Users },
    { label: "Tasa de conversión", value: "12%", change: "+3%", icon: TrendingUp },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-serif font-semibold">Estadísticas</h1>
        <p className="text-muted-foreground">
          Analiza el rendimiento de tu perfil
        </p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.label}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <stat.icon className="w-5 h-5 text-muted-foreground" />
                <span className="text-xs text-green-500 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  {stat.change}
                </span>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Evolución mensual</CardTitle>
          <CardDescription>Visitas y contactos en los últimos 6 meses</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center text-muted-foreground">
            Gráfico de evolución (próximamente)
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
