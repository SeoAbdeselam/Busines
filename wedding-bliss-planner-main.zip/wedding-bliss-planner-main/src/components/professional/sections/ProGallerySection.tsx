import { useState, useEffect } from "react";
import { useProfessionalAuth } from "@/contexts/ProfessionalAuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Plus, Image, Video, Crown, AlertCircle } from "lucide-react";
import { GalleryUploader } from "../gallery/GalleryUploader";
import { GalleryGrid } from "../gallery/GalleryGrid";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface GalleryItem {
  id: string;
  type: string;
  url: string;
  thumbnail_url: string | null;
  title: string | null;
  sort_order: number;
}

export function ProGallerySection() {
  const { professional, isPremium } = useProfessionalAuth();
  const { toast } = useToast();
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showUploader, setShowUploader] = useState(false);

  const maxImages = isPremium ? Infinity : 10;
  const maxVideos = isPremium ? Infinity : 2;

  const imageCount = gallery.filter(g => g.type === "image").length;
  const videoCount = gallery.filter(g => g.type === "video").length;

  useEffect(() => {
    if (professional) {
      fetchGallery();
    }
  }, [professional]);

  const fetchGallery = async () => {
    if (!professional) return;
    
    try {
      const { data, error } = await supabase
        .from("professional_gallery")
        .select("*")
        .eq("professional_id", professional.id)
        .order("sort_order", { ascending: true });

      if (error) throw error;
      setGallery(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="animate-pulse">Cargando galería...</div>;
  }

  const isAtImageLimit = !isPremium && imageCount >= maxImages;
  const isAtVideoLimit = !isPremium && videoCount >= maxVideos;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-serif font-semibold">Galería</h1>
          <p className="text-muted-foreground">
            Muestra tu trabajo con fotos y vídeos
          </p>
        </div>
        <Button onClick={() => setShowUploader(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Subir archivo
        </Button>
      </div>

      {/* Limits info */}
      <div className="flex gap-4">
        <Badge 
          variant={isAtImageLimit ? "destructive" : "outline"} 
          className="flex items-center gap-2"
        >
          <Image className="w-4 h-4" />
          {imageCount}/{isPremium ? "∞" : maxImages} fotos
        </Badge>
        <Badge 
          variant={isAtVideoLimit ? "destructive" : "outline"} 
          className="flex items-center gap-2"
        >
          <Video className="w-4 h-4" />
          {videoCount}/{isPremium ? "∞" : maxVideos} vídeos
        </Badge>
      </div>

      {/* Premium upgrade alert */}
      {!isPremium && (isAtImageLimit || isAtVideoLimit) && (
        <Alert>
          <Crown className="h-4 w-4" />
          <AlertDescription className="flex items-center justify-between">
            <span>Has alcanzado el límite de tu plan gratuito.</span>
            <Button variant="link" className="text-primary p-0 h-auto">
              Actualizar a Premium →
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Gallery content */}
      {gallery.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <Image className="w-12 h-12 text-muted-foreground mb-4" />
            <h3 className="font-medium mb-2">Tu galería está vacía</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Sube fotos y vídeos para mostrar tu trabajo a los clientes
            </p>
            <Button onClick={() => setShowUploader(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Subir primer archivo
            </Button>
          </CardContent>
        </Card>
      ) : (
        <GalleryGrid gallery={gallery} onDelete={fetchGallery} />
      )}

      {/* File uploader modal */}
      {professional && (
        <GalleryUploader
          professionalId={professional.id}
          isPremium={isPremium}
          imageCount={imageCount}
          videoCount={videoCount}
          maxImages={maxImages}
          maxVideos={maxVideos}
          open={showUploader}
          onOpenChange={setShowUploader}
          onUploadComplete={fetchGallery}
        />
      )}
    </div>
  );
}
