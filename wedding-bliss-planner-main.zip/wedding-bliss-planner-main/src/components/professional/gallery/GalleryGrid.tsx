import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Trash2, Image, Video, Loader2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface GalleryItem {
  id: string;
  type: string;
  url: string;
  thumbnail_url: string | null;
  title: string | null;
  sort_order: number;
}

interface GalleryGridProps {
  gallery: GalleryItem[];
  onDelete: () => void;
}

export function GalleryGrid({ gallery, onDelete }: GalleryGridProps) {
  const { toast } = useToast();
  const [deleting, setDeleting] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const handleDelete = async (item: GalleryItem) => {
    setDeleting(item.id);
    try {
      // Extract file path from URL
      const urlParts = item.url.split("/professional-media/");
      if (urlParts.length > 1) {
        const filePath = urlParts[1];
        // Delete from storage
        await supabase.storage.from("professional-media").remove([filePath]);
      }

      // Delete from database
      const { error } = await supabase
        .from("professional_gallery")
        .delete()
        .eq("id", item.id);

      if (error) throw error;

      toast({
        title: "Eliminado",
        description: "Elemento eliminado de la galería",
      });
      onDelete();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setDeleting(null);
      setConfirmDelete(null);
    }
  };

  if (gallery.length === 0) {
    return null;
  }

  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {gallery.map((item) => (
          <Card key={item.id} className="group relative overflow-hidden">
            <div className="aspect-square">
              {item.type === "image" ? (
                <img
                  src={item.url}
                  alt={item.title || ""}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              ) : (
                <video
                  src={item.url}
                  className="w-full h-full object-cover"
                  muted
                  playsInline
                  onMouseEnter={(e) => e.currentTarget.play()}
                  onMouseLeave={(e) => {
                    e.currentTarget.pause();
                    e.currentTarget.currentTime = 0;
                  }}
                />
              )}
            </div>

            {/* Overlay with delete button */}
            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <Button
                size="icon"
                variant="destructive"
                onClick={() => setConfirmDelete(item.id)}
                disabled={deleting === item.id}
              >
                {deleting === item.id ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Trash2 className="w-4 h-4" />
                )}
              </Button>
            </div>

            {/* Title overlay */}
            {item.title && (
              <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/80 to-transparent">
                <p className="text-white text-sm truncate">{item.title}</p>
              </div>
            )}

            {/* Type badge */}
            <Badge
              className="absolute top-2 right-2"
              variant={item.type === "image" ? "default" : "secondary"}
            >
              {item.type === "image" ? (
                <Image className="w-3 h-3" />
              ) : (
                <Video className="w-3 h-3" />
              )}
            </Badge>
          </Card>
        ))}
      </div>

      {/* Confirm delete dialog */}
      <AlertDialog open={!!confirmDelete} onOpenChange={() => setConfirmDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar este elemento?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. El archivo será eliminado permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                const item = gallery.find((g) => g.id === confirmDelete);
                if (item) handleDelete(item);
              }}
              className="bg-destructive hover:bg-destructive/90"
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
