import { useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Upload, Image, Video, Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

interface GalleryUploaderProps {
  professionalId: string;
  isPremium: boolean;
  imageCount: number;
  videoCount: number;
  maxImages: number;
  maxVideos: number;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUploadComplete: () => void;
}

export function GalleryUploader({
  professionalId,
  isPremium,
  imageCount,
  videoCount,
  maxImages,
  maxVideos,
  open,
  onOpenChange,
  onUploadComplete,
}: GalleryUploaderProps) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [fileType, setFileType] = useState<"image" | "video">("image");

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Determine file type
    const isVideo = file.type.startsWith("video/");
    const isImage = file.type.startsWith("image/");

    if (!isVideo && !isImage) {
      toast({
        title: "Formato no válido",
        description: "Solo se permiten imágenes y vídeos",
        variant: "destructive",
      });
      return;
    }

    // Check limits
    if (isImage && imageCount >= maxImages) {
      toast({
        title: "Límite alcanzado",
        description: `Has alcanzado el límite de ${maxImages} imágenes. ${!isPremium ? "Actualiza a Premium para subir más." : ""}`,
        variant: "destructive",
      });
      return;
    }

    if (isVideo && videoCount >= maxVideos) {
      toast({
        title: "Límite alcanzado",
        description: `Has alcanzado el límite de ${maxVideos} vídeos. ${!isPremium ? "Actualiza a Premium para subir más." : ""}`,
        variant: "destructive",
      });
      return;
    }

    // Check file size (5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Archivo muy grande",
        description: "El archivo no puede superar los 5MB",
        variant: "destructive",
      });
      return;
    }

    setSelectedFile(file);
    setFileType(isVideo ? "video" : "image");

    // Create preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    setUploading(true);
    try {
      // Generate unique filename
      const ext = selectedFile.name.split(".").pop();
      const fileName = `${professionalId}/${Date.now()}.${ext}`;

      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from("professional-media")
        .upload(fileName, selectedFile, {
          cacheControl: "3600",
          upsert: false,
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: urlData } = supabase.storage
        .from("professional-media")
        .getPublicUrl(fileName);

      // Save to gallery table
      const { error: dbError } = await supabase
        .from("professional_gallery")
        .insert({
          professional_id: professionalId,
          type: fileType,
          url: urlData.publicUrl,
          title: title || null,
          sort_order: imageCount + videoCount,
        });

      if (dbError) throw dbError;

      toast({
        title: "Subido correctamente",
        description: `${fileType === "image" ? "Imagen" : "Vídeo"} añadido a tu galería`,
      });

      // Reset and close
      setSelectedFile(null);
      setPreview(null);
      setTitle("");
      onOpenChange(false);
      onUploadComplete();
    } catch (error: any) {
      console.error("Upload error:", error);
      toast({
        title: "Error al subir",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const resetForm = () => {
    setSelectedFile(null);
    setPreview(null);
    setTitle("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <Dialog open={open} onOpenChange={(value) => {
      if (!value) resetForm();
      onOpenChange(value);
    }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Subir a galería</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Upload area */}
          {!selectedFile ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed rounded-lg p-8 text-center cursor-pointer hover:border-primary/50 transition-colors"
            >
              <Upload className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
              <p className="font-medium mb-1">Haz clic para seleccionar</p>
              <p className="text-sm text-muted-foreground">
                Imágenes (JPG, PNG, WebP) o vídeos (MP4, WebM)
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                Máximo 5MB por archivo
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Preview */}
              <div className="relative aspect-video rounded-lg overflow-hidden bg-secondary">
                {fileType === "image" ? (
                  <img
                    src={preview || ""}
                    alt="Preview"
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <video
                    src={preview || ""}
                    className="w-full h-full object-contain"
                    controls
                  />
                )}
                <div className="absolute top-2 right-2">
                  {fileType === "image" ? (
                    <Image className="w-5 h-5 text-white drop-shadow" />
                  ) : (
                    <Video className="w-5 h-5 text-white drop-shadow" />
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground truncate max-w-[200px]">
                  {selectedFile.name}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={resetForm}
                >
                  Cambiar
                </Button>
              </div>
            </div>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm"
            onChange={handleFileSelect}
            className="hidden"
          />

          {/* Title input */}
          {selectedFile && (
            <div className="space-y-2">
              <Label>Título (opcional)</Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Descripción breve"
              />
            </div>
          )}

          {/* Limits info */}
          <div className="flex gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Image className="w-3 h-3" />
              {imageCount}/{isPremium ? "∞" : maxImages}
            </span>
            <span className="flex items-center gap-1">
              <Video className="w-3 h-3" />
              {videoCount}/{isPremium ? "∞" : maxVideos}
            </span>
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={uploading}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleUpload}
            disabled={!selectedFile || uploading}
          >
            {uploading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Subiendo...
              </>
            ) : (
              "Subir"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
