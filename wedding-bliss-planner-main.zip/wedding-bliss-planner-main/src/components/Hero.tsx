import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-wedding.jpg";
import { Heart, Sparkles } from "lucide-react";
export const Hero = () => {
  const scrollToRegistro = () => {
    document.getElementById("registro")?.scrollIntoView({
      behavior: "smooth"
    });
  };
  return <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" style={{
      backgroundImage: `url(${heroImage})`
    }}>
        <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/50 to-background" />
      </div>

      {/* Floating decorative elements */}
      <div className="absolute top-20 left-10 animate-float opacity-30">
        <Heart className="w-8 h-8 text-champagne" fill="currentColor" />
      </div>
      <div className="absolute top-40 right-20 animate-float opacity-40" style={{
      animationDelay: "2s"
    }}>
        <Sparkles className="w-6 h-6 text-rose-gold" />
      </div>
      <div className="absolute bottom-40 left-20 animate-float opacity-30" style={{
      animationDelay: "4s"
    }}>
        <Heart className="w-10 h-10 text-blush-deep" fill="currentColor" />
      </div>

      {/* Content */}
      <div className="relative z-10 container-wedding text-center">
        <div className="max-w-4xl mx-auto space-y-8 animate-fade-up">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/80 backdrop-blur-sm border border-champagne-light/30">
            <Sparkles className="w-4 h-4 text-champagne" />
            <span className="text-sm font-medium text-secondary-foreground">
              Tu boda perfecta comienza aquí
            </span>
          </div>

          {/* Title */}
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-serif font-semibold text-foreground leading-tight">
            Organiza tu boda<br />
            <span className="text-gradient">sin estrés</span>
          </h1>

          {/* Subtitle */}
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto font-light leading-relaxed">
            La herramienta gratuita que te ayuda a planificar cada detalle de tu día especial. 
            Encuentra los mejores profesionales y organiza todo en un solo lugar.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button variant="hero" size="xl" onClick={scrollToRegistro}>
              <Heart className="w-5 h-5" />
              Empezar Gratis
            </Button>
            <Button variant="outline" size="xl" className="rounded-full">
              Descubrir Profesionales
            </Button>
          </div>

          {/* Trust badges */}
          <div className="flex flex-wrap justify-center gap-8 pt-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-champagne" />
              100% Gratuito
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-champagne" />
              +500 Profesionales
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-champagne" />
              Sin Compromiso
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 border-muted-foreground/30 flex items-start justify-center p-2">
          <div className="w-1 h-2 rounded-full bg-muted-foreground/50" />
        </div>
      </div>
    </section>;
};