import { 
  Camera, 
  Video,
  Flower2, 
  UtensilsCrossed, 
  Music, 
  Shirt,
  Car,
  Cake,
  Gem,
  Building2,
  HeartHandshake,
  Palette,
  Mail,
  Sparkles,
  MoreHorizontal
} from "lucide-react";

export const PROFESSIONAL_CATEGORIES = {
  photography: { 
    label: "Fotografía", 
    icon: Camera,
    description: "Captura los mejores momentos de tu boda"
  },
  video: { 
    label: "Vídeo", 
    icon: Video,
    description: "Producción audiovisual para tu día especial"
  },
  florist: { 
    label: "Floristería", 
    icon: Flower2,
    description: "Decoración floral y ramos de novia"
  },
  catering: { 
    label: "Catering", 
    icon: UtensilsCrossed,
    description: "Gastronomía y servicio de banquetes"
  },
  dj_music: { 
    label: "DJ / Música", 
    icon: Music,
    description: "Música en vivo y entretenimiento"
  },
  dresses: { 
    label: "Vestidos", 
    icon: Shirt,
    description: "Vestidos de novia y trajes"
  },
  transport: { 
    label: "Transporte", 
    icon: Car,
    description: "Coches de época y transporte nupcial"
  },
  pastry: { 
    label: "Pastelería", 
    icon: Cake,
    description: "Tartas nupciales y dulces"
  },
  jewelry: { 
    label: "Joyería", 
    icon: Gem,
    description: "Alianzas y joyería nupcial"
  },
  venues: { 
    label: "Salones de boda", 
    icon: Building2,
    description: "Espacios y fincas para celebraciones"
  },
  wedding_planner: { 
    label: "Wedding Planner", 
    icon: HeartHandshake,
    description: "Organización integral de bodas"
  },
  makeup_hair: { 
    label: "Maquillaje y Peluquería", 
    icon: Sparkles,
    description: "Belleza y estilismo nupcial"
  },
  decoration: { 
    label: "Decoración", 
    icon: Palette,
    description: "Ambientación y diseño de espacios"
  },
  invitations: { 
    label: "Invitaciones", 
    icon: Mail,
    description: "Papelería nupcial y diseño gráfico"
  },
  other: { 
    label: "Otros servicios", 
    icon: MoreHorizontal,
    description: "Otros servicios para bodas"
  },
} as const;

export type ProfessionalCategory = keyof typeof PROFESSIONAL_CATEGORIES;

export const getCategoryLabel = (category: string): string => {
  return PROFESSIONAL_CATEGORIES[category as ProfessionalCategory]?.label || category;
};

export const getCategoryIcon = (category: string) => {
  return PROFESSIONAL_CATEGORIES[category as ProfessionalCategory]?.icon || MoreHorizontal;
};
