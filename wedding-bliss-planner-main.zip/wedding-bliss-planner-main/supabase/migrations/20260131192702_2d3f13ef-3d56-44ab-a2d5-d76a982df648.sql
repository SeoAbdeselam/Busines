-- Add table_type enum for different table shapes
CREATE TYPE public.table_type AS ENUM ('round', 'rectangular', 'imperial');

-- Add table_type column to wedding_tables
ALTER TABLE public.wedding_tables 
ADD COLUMN table_type public.table_type NOT NULL DEFAULT 'round';

-- Create tasks table for smart task management
CREATE TABLE public.tasks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wedding_id UUID NOT NULL REFERENCES public.weddings(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL DEFAULT 'general',
  priority INTEGER NOT NULL DEFAULT 2, -- 1=high, 2=medium, 3=low
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed')),
  due_date DATE,
  -- Budget integration
  has_cost BOOLEAN NOT NULL DEFAULT false,
  estimated_cost NUMERIC DEFAULT 0,
  actual_cost NUMERIC,
  payment_status TEXT CHECK (payment_status IN ('pending', 'partial', 'paid')),
  -- Connections
  budget_category TEXT,
  -- Template reference
  is_from_template BOOLEAN NOT NULL DEFAULT false,
  template_key TEXT,
  -- Ordering for drag/drop
  sort_order INTEGER NOT NULL DEFAULT 0,
  -- Timestamps
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

-- RLS policies for tasks
CREATE POLICY "Couples can view tasks" 
ON public.tasks FOR SELECT 
USING (is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can create tasks" 
ON public.tasks FOR INSERT 
WITH CHECK (is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can update tasks" 
ON public.tasks FOR UPDATE 
USING (is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can delete tasks" 
ON public.tasks FOR DELETE 
USING (is_couple_in_wedding(wedding_id));

-- Trigger for updated_at
CREATE TRIGGER update_tasks_updated_at
BEFORE UPDATE ON public.tasks
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at();

-- Create task templates table for auto-generation
CREATE TABLE public.task_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL,
  priority INTEGER NOT NULL DEFAULT 2,
  months_before INTEGER NOT NULL, -- How many months before wedding
  has_cost BOOLEAN NOT NULL DEFAULT false,
  budget_category TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0
);

-- Insert default task templates
INSERT INTO public.task_templates (key, title, description, category, priority, months_before, has_cost, budget_category, sort_order) VALUES
-- 12 months before
('venue', 'Reservar el lugar de celebración', 'Visita y reserva el espacio para la ceremonia y el banquete', 'venue', 1, 12, true, 'Venue', 1),
('date', 'Fijar la fecha definitiva', 'Confirma la fecha con los lugares y proveedores clave', 'planning', 1, 12, false, NULL, 2),
('budget', 'Definir el presupuesto', 'Establece un presupuesto realista para todos los gastos', 'planning', 1, 12, false, NULL, 3),

-- 9 months before
('catering', 'Contratar catering', 'Busca, prueba y contrata el servicio de catering', 'catering', 1, 9, true, 'Catering', 10),
('photographer', 'Contratar fotógrafo/a', 'Revisa portfolios y reserva al profesional', 'photography', 1, 9, true, 'Fotografía', 11),
('music', 'Contratar música/DJ', 'Decide el estilo musical y contrata el servicio', 'entertainment', 2, 9, true, 'Música', 12),

-- 6 months before
('florist', 'Contratar floristería', 'Elige el estilo floral y reserva el servicio', 'decoration', 2, 6, true, 'Decoración', 20),
('invitations_design', 'Diseñar invitaciones', 'Crea el diseño de las invitaciones', 'stationery', 2, 6, true, 'Papelería', 21),
('dress', 'Elegir vestido/traje', 'Busca y encarga la vestimenta principal', 'attire', 1, 6, true, 'Vestuario', 22),
('officiant', 'Confirmar oficiante', 'Reserva quien oficiará la ceremonia', 'ceremony', 2, 6, true, 'Ceremonia', 23),

-- 3 months before
('guest_list', 'Cerrar lista de invitados', 'Finaliza la lista completa de invitados', 'guests', 1, 3, false, NULL, 30),
('send_invitations', 'Enviar invitaciones', 'Envía todas las invitaciones', 'stationery', 1, 3, true, 'Papelería', 31),
('menu_tasting', 'Cata del menú', 'Prueba y confirma el menú definitivo', 'catering', 2, 3, false, NULL, 32),
('rings', 'Encargar alianzas', 'Elige y encarga los anillos de boda', 'attire', 2, 3, true, 'Joyería', 33),

-- 1 month before
('seating', 'Organizar mesas', 'Distribuye a los invitados en las mesas', 'guests', 1, 1, false, NULL, 40),
('confirm_vendors', 'Confirmar proveedores', 'Reconfirma todos los servicios contratados', 'planning', 1, 1, false, NULL, 41),
('timeline', 'Crear timeline del día', 'Planifica el horario detallado de la boda', 'planning', 2, 1, false, NULL, 42),

-- 1 week before
('final_count', 'Confirmar asistencia final', 'Obtén la cuenta final de asistentes', 'guests', 1, 0, false, NULL, 50),
('payments', 'Revisar pagos pendientes', 'Asegura que todos los pagos están al día', 'planning', 1, 0, false, NULL, 51);

-- Grant permissions
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tasks TO authenticated;
GRANT SELECT ON public.task_templates TO authenticated;