-- Añadir campo is_profile_complete a professionals con cálculo automático
ALTER TABLE public.professionals ADD COLUMN IF NOT EXISTS is_profile_complete boolean DEFAULT false;

-- Función para calcular si un perfil profesional está completo
CREATE OR REPLACE FUNCTION public.calculate_professional_profile_complete(p_professional_id uuid)
RETURNS boolean
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_prof RECORD;
  v_gallery_count INTEGER;
BEGIN
  -- Obtener datos del profesional
  SELECT business_name, primary_category, city, description
  INTO v_prof
  FROM public.professionals
  WHERE id = p_professional_id;
  
  IF NOT FOUND THEN
    RETURN false;
  END IF;
  
  -- Contar imágenes en galería
  SELECT COUNT(*) INTO v_gallery_count
  FROM public.professional_gallery
  WHERE professional_id = p_professional_id;
  
  -- Perfil completo si tiene: nombre, categoría, ciudad, descripción Y al menos 1 imagen
  RETURN (
    v_prof.business_name IS NOT NULL AND v_prof.business_name != '' AND
    v_prof.primary_category IS NOT NULL AND
    v_prof.city IS NOT NULL AND v_prof.city != '' AND
    v_prof.description IS NOT NULL AND v_prof.description != '' AND
    v_gallery_count > 0
  );
END;
$$;

-- Trigger para actualizar is_profile_complete cuando cambia el profesional
CREATE OR REPLACE FUNCTION public.update_professional_profile_complete()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.is_profile_complete := public.calculate_professional_profile_complete(NEW.id);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_update_professional_profile_complete ON public.professionals;
CREATE TRIGGER trigger_update_professional_profile_complete
  BEFORE UPDATE ON public.professionals
  FOR EACH ROW
  EXECUTE FUNCTION public.update_professional_profile_complete();

-- Trigger para actualizar is_profile_complete cuando se añade/elimina de galería
CREATE OR REPLACE FUNCTION public.update_professional_profile_on_gallery_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_professional_id uuid;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_professional_id := OLD.professional_id;
  ELSE
    v_professional_id := NEW.professional_id;
  END IF;
  
  UPDATE public.professionals
  SET is_profile_complete = public.calculate_professional_profile_complete(v_professional_id)
  WHERE id = v_professional_id;
  
  RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS trigger_update_professional_on_gallery_change ON public.professional_gallery;
CREATE TRIGGER trigger_update_professional_on_gallery_change
  AFTER INSERT OR DELETE ON public.professional_gallery
  FOR EACH ROW
  EXECUTE FUNCTION public.update_professional_profile_on_gallery_change();

-- Actualizar todos los profesionales existentes
UPDATE public.professionals
SET is_profile_complete = public.calculate_professional_profile_complete(id);