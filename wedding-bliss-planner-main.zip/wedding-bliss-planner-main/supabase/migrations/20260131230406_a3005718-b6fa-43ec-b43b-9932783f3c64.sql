-- Create sample/seed data for professionals
-- These are demo professionals that don't require real auth users
-- They use their own ID as user_id (which won't match any real auth user)
-- This is acceptable for demo data as the RLS policies allow public viewing

-- First, ensure we can insert sample data by temporarily using a specific approach
INSERT INTO public.professionals (
  id, user_id, business_name, slug, primary_category, city, province, description, story, 
  is_verified, is_active, is_profile_complete, is_premium, average_rating, total_reviews,
  cover_image_url
) VALUES
-- Fotografía (Premium)
(
  gen_random_uuid(),
  gen_random_uuid(),
  'Estudio Luz y Sombra',
  'estudio-luz-y-sombra',
  'photography',
  'Madrid',
  'Madrid',
  'Capturamos los momentos más especiales de vuestra boda con un estilo natural y emotivo. Más de 10 años de experiencia.',
  'Somos María y Carlos, un equipo apasionado por la fotografía de bodas. Creemos que cada pareja tiene su propia historia que contar, y nuestro trabajo es capturarla de forma auténtica y atemporal.',
  true, true, true, true, 4.9, 127,
  'https://images.unsplash.com/photo-1519741497674-611481863552?w=1200'
),
-- Vídeo (Premium)
(
  gen_random_uuid(),
  gen_random_uuid(),
  'Producciones Momentos',
  'producciones-momentos',
  'video',
  'Barcelona',
  'Barcelona',
  'Vídeos cinematográficos que cuentan vuestra historia de amor. Estilo documental y emotivo.',
  'Nuestro equipo de videógrafos profesionales crea películas únicas que os harán revivir cada emoción de vuestro día especial.',
  true, true, true, true, 4.8, 89,
  'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=1200'
),
-- Catering
(
  gen_random_uuid(),
  gen_random_uuid(),
  'Gastronomía del Sur',
  'gastronomia-del-sur',
  'catering',
  'Sevilla',
  'Sevilla',
  'Cocina andaluza de autor para bodas. Menús personalizados con productos locales de primera calidad.',
  'Llevamos tres generaciones dedicados a la gastronomía. Nuestra pasión es crear experiencias culinarias inolvidables para los días más especiales.',
  true, true, true, false, 4.7, 156,
  'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1200'
),
-- Floristería
(
  gen_random_uuid(),
  gen_random_uuid(),
  'Flores del Jardín',
  'flores-del-jardin',
  'florist',
  'Valencia',
  'Valencia',
  'Decoración floral exclusiva para bodas. Ramos de novia, centros de mesa y ambientación completa.',
  'Elena fundó Flores del Jardín hace 15 años con una misión clara: transformar espacios con la belleza natural de las flores.',
  true, true, true, false, 4.6, 78,
  'https://images.unsplash.com/photo-1522057306606-8d84776e10b8?w=1200'
),
-- DJ / Música (Premium)
(
  gen_random_uuid(),
  gen_random_uuid(),
  'DJ Marcos Events',
  'dj-marcos-events',
  'dj_music',
  'Málaga',
  'Málaga',
  'DJ profesional con más de 500 bodas. Música para ceremonia, cóctel y fiesta que se adapta a todos los gustos.',
  'La música es emoción, y mi trabajo es crear la banda sonora perfecta para cada momento de vuestra boda.',
  true, true, true, true, 4.9, 234,
  'https://images.unsplash.com/photo-1493676304819-0d7a8d026dcf?w=1200'
),
-- Salones de boda
(
  gen_random_uuid(),
  gen_random_uuid(),
  'Finca El Olivar',
  'finca-el-olivar',
  'venues',
  'Toledo',
  'Toledo',
  'Finca exclusiva entre olivos centenarios. Capacidad hasta 300 invitados. Ceremonia civil y banquete.',
  'Un espacio mágico rodeado de naturaleza donde los sueños de boda se hacen realidad desde hace más de 20 años.',
  true, true, true, false, 4.8, 189,
  'https://images.unsplash.com/photo-1519225421980-715cb0215aed?w=1200'
),
-- Vestidos
(
  gen_random_uuid(),
  gen_random_uuid(),
  'Atelier Novias Laura',
  'atelier-novias-laura',
  'dresses',
  'Bilbao',
  'Vizcaya',
  'Vestidos de novia a medida con tejidos de alta costura. Diseños exclusivos y atemporales.',
  'Cada vestido que creamos es único, diseñado especialmente para realzar la belleza de cada novia.',
  true, true, true, false, 4.7, 92,
  'https://images.unsplash.com/photo-1594552072238-b8a33785b261?w=1200'
),
-- Pastelería
(
  gen_random_uuid(),
  gen_random_uuid(),
  'Dulce Tentación',
  'dulce-tentacion',
  'pastry',
  'Zaragoza',
  'Zaragoza',
  'Tartas nupciales artesanales. Diseños personalizados con los mejores ingredientes.',
  'Creamos obras de arte comestibles que deleitan tanto la vista como el paladar.',
  true, true, true, false, 4.9, 145,
  'https://images.unsplash.com/photo-1535254973040-607b474cb50d?w=1200'
),
-- Wedding Planner
(
  gen_random_uuid(),
  gen_random_uuid(),
  'Organización Perfecta',
  'organizacion-perfecta',
  'wedding_planner',
  'Madrid',
  'Madrid',
  'Wedding planners con experiencia internacional. Coordinación integral de tu boda desde la organización hasta el día D.',
  'Nuestro equipo de organizadoras profesionales se encarga de cada detalle para que tú solo tengas que disfrutar.',
  true, true, true, false, 4.8, 67,
  'https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?w=1200'
),
-- Decoración
(
  gen_random_uuid(),
  gen_random_uuid(),
  'Ambientes con Estilo',
  'ambientes-con-estilo',
  'decoration',
  'Alicante',
  'Alicante',
  'Decoración integral de bodas. Desde el concepto hasta la ejecución, creamos ambientes únicos y personalizados.',
  'Transformamos espacios en escenarios de cuento donde cada detalle cuenta tu historia de amor.',
  true, true, true, false, 4.5, 43,
  'https://images.unsplash.com/photo-1478146059778-26028b07395a?w=1200'
)
ON CONFLICT (slug) DO NOTHING;

-- Insert gallery images for the new professionals
INSERT INTO public.professional_gallery (professional_id, type, url, title, sort_order)
SELECT p.id, 'image', 
  CASE p.primary_category
    WHEN 'photography' THEN 'https://images.unsplash.com/photo-1606216794074-735e91aa2c92?w=800'
    WHEN 'video' THEN 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=800'
    WHEN 'catering' THEN 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800'
    WHEN 'florist' THEN 'https://images.unsplash.com/photo-1478146059778-26028b07395a?w=800'
    WHEN 'dj_music' THEN 'https://images.unsplash.com/photo-1429962714451-bb934ecdc4ec?w=800'
    WHEN 'venues' THEN 'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=800'
    WHEN 'dresses' THEN 'https://images.unsplash.com/photo-1549416878-7d5d30f23abb?w=800'
    WHEN 'pastry' THEN 'https://images.unsplash.com/photo-1558301211-0d8c8ddee6ec?w=800'
    WHEN 'wedding_planner' THEN 'https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?w=800'
    ELSE 'https://images.unsplash.com/photo-1519741497674-611481863552?w=800'
  END,
  'Trabajo destacado', 1
FROM public.professionals p
WHERE p.slug IN (
  'estudio-luz-y-sombra', 'producciones-momentos', 'gastronomia-del-sur', 
  'flores-del-jardin', 'dj-marcos-events', 'finca-el-olivar', 
  'atelier-novias-laura', 'dulce-tentacion', 'organizacion-perfecta', 'ambientes-con-estilo'
);

-- Add task templates for common wedding tasks
INSERT INTO public.task_templates (key, title, description, category, months_before, priority, has_cost, budget_category, sort_order)
VALUES
('define_budget', 'Definir presupuesto total', 'Establece el presupuesto máximo para la boda y cómo lo distribuiréis', 'planning', 12, 1, false, null, 1),
('choose_date', 'Elegir fecha de la boda', 'Selecciona la fecha ideal teniendo en cuenta la disponibilidad de los invitados', 'planning', 12, 1, false, null, 2),
('choose_venue', 'Reservar lugar de celebración', 'Visita y reserva el espacio para la ceremonia y/o banquete', 'venues', 12, 1, true, 'venues', 3),
('hire_photographer', 'Contratar fotógrafo', 'Busca y contrata al fotógrafo que capturará vuestros recuerdos', 'photography', 10, 1, true, 'photography', 4),
('hire_videographer', 'Contratar videógrafo', 'Elige al profesional que filmará vuestro día especial', 'video', 10, 2, true, 'video', 5),
('choose_catering', 'Contratar catering', 'Selecciona el servicio de catering y define el menú', 'catering', 9, 1, true, 'catering', 6),
('choose_dress', 'Elegir vestido de novia', 'Visita tiendas y elige el vestido perfecto', 'dresses', 8, 1, true, 'dresses', 7),
('choose_suit', 'Elegir traje del novio', 'Selecciona el traje para el día de la boda', 'dresses', 6, 2, true, 'dresses', 8),
('hire_florist', 'Contratar florista', 'Elige la decoración floral: ramo, centros de mesa, etc.', 'florist', 6, 2, true, 'florist', 9),
('hire_dj', 'Contratar DJ o música', 'Reserva al DJ o grupo musical para la fiesta', 'dj_music', 6, 2, true, 'dj_music', 10),
('order_cake', 'Encargar tarta nupcial', 'Diseña y encarga la tarta de la boda', 'pastry', 4, 2, true, 'pastry', 11),
('send_invitations', 'Enviar invitaciones', 'Diseña, imprime y envía las invitaciones a los invitados', 'invitations', 4, 1, true, 'invitations', 12),
('confirm_guests', 'Confirmar lista de invitados', 'Recoge las confirmaciones de asistencia', 'planning', 2, 1, false, null, 13),
('seating_plan', 'Organizar mesas', 'Crea el plan de mesas y asigna los asientos', 'planning', 1, 1, false, null, 14),
('final_details', 'Últimos detalles', 'Revisa todos los proveedores y confirma horarios', 'planning', 0, 1, false, null, 15)
ON CONFLICT (key) DO NOTHING;