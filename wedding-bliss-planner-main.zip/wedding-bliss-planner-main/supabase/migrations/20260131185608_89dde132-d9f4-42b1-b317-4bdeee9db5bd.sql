-- Drop existing INSERT policy
DROP POLICY IF EXISTS "Users can create their own weddings" ON public.weddings;

-- Create a simple INSERT policy that allows any authenticated user to insert
-- The created_by will be validated by the frontend and the FK constraint
CREATE POLICY "Authenticated users can create weddings" 
ON public.weddings 
FOR INSERT 
TO authenticated
WITH CHECK (true);

-- Re-add the enforce_created_by trigger for additional security
CREATE OR REPLACE TRIGGER enforce_wedding_created_by
BEFORE INSERT ON public.weddings
FOR EACH ROW
EXECUTE FUNCTION public.enforce_created_by();