-- Create storage bucket for professional media
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'professional-media', 
  'professional-media', 
  true,
  5242880, -- 5MB limit
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'video/mp4', 'video/webm']
);

-- RLS policies for professional-media bucket
-- Public read access
CREATE POLICY "Professional media is publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'professional-media');

-- Professionals can upload to their own folder
CREATE POLICY "Professionals can upload to own folder"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'professional-media' 
  AND (storage.foldername(name))[1] = (
    SELECT id::text FROM public.professionals WHERE user_id = auth.uid()
  )
);

-- Professionals can update their own files
CREATE POLICY "Professionals can update own files"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'professional-media' 
  AND (storage.foldername(name))[1] = (
    SELECT id::text FROM public.professionals WHERE user_id = auth.uid()
  )
);

-- Professionals can delete their own files
CREATE POLICY "Professionals can delete own files"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'professional-media' 
  AND (storage.foldername(name))[1] = (
    SELECT id::text FROM public.professionals WHERE user_id = auth.uid()
  )
);

-- Add is_premium column to professionals for easier queries
-- This is a computed/cached field updated when subscription changes
ALTER TABLE public.professionals 
ADD COLUMN IF NOT EXISTS is_premium boolean DEFAULT false;

-- Create function to check and update premium status
CREATE OR REPLACE FUNCTION public.update_professional_premium_status()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.professionals
  SET is_premium = (
    SELECT EXISTS (
      SELECT 1 FROM public.professional_subscriptions
      WHERE professional_id = NEW.professional_id
      AND plan = 'premium'
      AND status = 'active'
      AND (expires_at IS NULL OR expires_at > now())
    )
  )
  WHERE id = NEW.professional_id;
  RETURN NEW;
END;
$$;

-- Create trigger to auto-update premium status
CREATE TRIGGER update_premium_on_subscription_change
AFTER INSERT OR UPDATE ON public.professional_subscriptions
FOR EACH ROW
EXECUTE FUNCTION public.update_professional_premium_status();

-- Create function to auto-create task and budget item when professional is contracted
CREATE OR REPLACE FUNCTION public.handle_professional_contracted()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_professional_name text;
  v_category text;
  v_task_id uuid;
  v_budget_item_id uuid;
BEGIN
  -- Only run when status changes to 'contracted'
  IF NEW.status = 'contracted' AND (OLD.status IS NULL OR OLD.status != 'contracted') THEN
    -- Get professional info
    SELECT business_name, primary_category 
    INTO v_professional_name, v_category
    FROM public.professionals 
    WHERE id = NEW.professional_id;

    -- Create task
    INSERT INTO public.tasks (
      wedding_id,
      title,
      description,
      category,
      status,
      has_cost,
      estimated_cost,
      budget_category,
      priority,
      due_date
    ) VALUES (
      NEW.wedding_id,
      'Contratar ' || v_professional_name,
      'Proveedor contratado a través de la plataforma',
      v_category,
      'in_progress',
      true,
      COALESCE(NEW.estimated_cost, 0),
      v_category,
      1,
      NEW.service_date
    )
    RETURNING id INTO v_task_id;

    -- Create budget item
    INSERT INTO public.budget_items (
      wedding_id,
      name,
      category,
      estimated_amount,
      actual_amount,
      is_paid,
      notes
    ) VALUES (
      NEW.wedding_id,
      v_professional_name,
      v_category,
      COALESCE(NEW.estimated_cost, 0),
      0,
      false,
      'Contrato con proveedor'
    )
    RETURNING id INTO v_budget_item_id;

    -- Link task and budget item to contract
    UPDATE public.professional_contracts
    SET task_id = v_task_id, budget_item_id = v_budget_item_id
    WHERE id = NEW.id;
  END IF;

  RETURN NEW;
END;
$$;

-- Create trigger for contract status change
CREATE TRIGGER on_professional_contracted
AFTER INSERT OR UPDATE OF status ON public.professional_contracts
FOR EACH ROW
EXECUTE FUNCTION public.handle_professional_contracted();

-- Create function to sync task completion with budget
CREATE OR REPLACE FUNCTION public.sync_contract_completion()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- When contract is marked as completed
  IF NEW.status = 'completed' AND (OLD.status IS NULL OR OLD.status != 'completed') THEN
    -- Update linked task
    IF NEW.task_id IS NOT NULL THEN
      UPDATE public.tasks
      SET 
        status = 'completed',
        completed_at = now(),
        actual_cost = COALESCE(NEW.actual_cost, NEW.estimated_cost)
      WHERE id = NEW.task_id;
    END IF;

    -- Update linked budget item
    IF NEW.budget_item_id IS NOT NULL THEN
      UPDATE public.budget_items
      SET 
        actual_amount = COALESCE(NEW.actual_cost, NEW.estimated_cost),
        is_paid = COALESCE(NEW.deposit_paid, false)
      WHERE id = NEW.budget_item_id;
    END IF;

    -- Increment professional's contract count
    UPDATE public.professionals
    SET total_contracts = COALESCE(total_contracts, 0) + 1
    WHERE id = NEW.professional_id;
  END IF;

  RETURN NEW;
END;
$$;

-- Create trigger for contract completion
CREATE TRIGGER on_contract_completed
AFTER UPDATE OF status ON public.professional_contracts
FOR EACH ROW
EXECUTE FUNCTION public.sync_contract_completion();