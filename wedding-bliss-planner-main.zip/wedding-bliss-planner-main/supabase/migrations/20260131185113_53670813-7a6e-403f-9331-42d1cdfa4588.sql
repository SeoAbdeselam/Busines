-- Drop and recreate the INSERT policy with correct check
DROP POLICY IF EXISTS "Any authenticated user can create weddings" ON public.weddings;

-- Create policy that verifies the user is setting their own ID as created_by
CREATE POLICY "Users can create their own weddings" 
ON public.weddings 
FOR INSERT 
TO authenticated
WITH CHECK (created_by = auth.uid());