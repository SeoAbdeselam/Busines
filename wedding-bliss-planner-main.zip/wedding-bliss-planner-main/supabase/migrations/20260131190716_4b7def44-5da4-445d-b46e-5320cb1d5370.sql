-- =============================================
-- RGPD COMPLIANCE: Consents table + Profile updates
-- =============================================

-- 1. Set default for phone first
ALTER TABLE public.profiles 
ALTER COLUMN phone SET DEFAULT '';

-- 2. Update existing NULL phones to empty string
UPDATE public.profiles SET phone = '' WHERE phone IS NULL;

-- 3. Now make phone NOT NULL
ALTER TABLE public.profiles 
ALTER COLUMN phone SET NOT NULL;

-- 4. Create consent types enum
CREATE TYPE public.consent_type AS ENUM (
  'terms_of_service',
  'privacy_policy', 
  'marketing_communications',
  'provider_offers',
  'event_notifications'
);

-- 5. Create consents table (CRITICAL for RGPD)
CREATE TABLE public.consents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  consent_type consent_type NOT NULL,
  granted BOOLEAN NOT NULL DEFAULT false,
  granted_at TIMESTAMP WITH TIME ZONE,
  revoked_at TIMESTAMP WITH TIME ZONE,
  ip_address TEXT,
  user_agent TEXT,
  origin TEXT NOT NULL DEFAULT 'registration',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, consent_type)
);

-- 6. Enable RLS on consents
ALTER TABLE public.consents ENABLE ROW LEVEL SECURITY;

-- 7. RLS policies for consents
CREATE POLICY "Users can view own consents"
ON public.consents FOR SELECT TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "Users can insert own consents"
ON public.consents FOR INSERT TO authenticated
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own consents"
ON public.consents FOR UPDATE TO authenticated
USING (user_id = auth.uid());

-- 8. Create user_role enum for future use
CREATE TYPE public.user_role AS ENUM ('couple', 'guest', 'professional', 'admin');

-- 9. Add role column to profiles
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS role public.user_role DEFAULT 'couple';

-- 10. Trigger for updated_at on consents
CREATE TRIGGER update_consents_updated_at
BEFORE UPDATE ON public.consents
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at();

-- 11. Grant permissions
GRANT SELECT, INSERT, UPDATE ON public.consents TO authenticated;

-- 12. Indexes
CREATE INDEX idx_consents_user_id ON public.consents(user_id);
CREATE INDEX idx_consents_type ON public.consents(consent_type);