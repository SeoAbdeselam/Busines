-- Fix RLS policies: Change from RESTRICTIVE to PERMISSIVE

-- Drop existing restrictive policies for weddings
DROP POLICY IF EXISTS "Authenticated users can create weddings" ON public.weddings;
DROP POLICY IF EXISTS "Couples can update their weddings" ON public.weddings;
DROP POLICY IF EXISTS "Members can view their weddings" ON public.weddings;
DROP POLICY IF EXISTS "Owner can delete wedding" ON public.weddings;

-- Recreate as PERMISSIVE policies (default)
CREATE POLICY "Authenticated users can create weddings" 
ON public.weddings 
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() IS NOT NULL AND created_by = auth.uid());

CREATE POLICY "Couples can update their weddings" 
ON public.weddings 
FOR UPDATE 
TO authenticated
USING (is_couple_in_wedding(id));

CREATE POLICY "Members can view their weddings" 
ON public.weddings 
FOR SELECT 
TO authenticated
USING (is_wedding_member(id));

CREATE POLICY "Owner can delete wedding" 
ON public.weddings 
FOR DELETE 
TO authenticated
USING (is_wedding_owner(id));

-- Fix wedding_memberships policies
DROP POLICY IF EXISTS "Couples can add members" ON public.wedding_memberships;
DROP POLICY IF EXISTS "Couples can remove members" ON public.wedding_memberships;
DROP POLICY IF EXISTS "Couples can update memberships" ON public.wedding_memberships;
DROP POLICY IF EXISTS "Members can view memberships in their weddings" ON public.wedding_memberships;

CREATE POLICY "Couples can add members" 
ON public.wedding_memberships 
FOR INSERT 
TO authenticated
WITH CHECK (is_couple_in_wedding(wedding_id) OR (auth.uid() IS NOT NULL AND user_id = auth.uid()));

CREATE POLICY "Couples can remove members" 
ON public.wedding_memberships 
FOR DELETE 
TO authenticated
USING (is_couple_in_wedding(wedding_id) OR user_id = auth.uid());

CREATE POLICY "Couples can update memberships" 
ON public.wedding_memberships 
FOR UPDATE 
TO authenticated
USING (is_couple_in_wedding(wedding_id));

CREATE POLICY "Members can view memberships in their weddings" 
ON public.wedding_memberships 
FOR SELECT 
TO authenticated
USING (is_wedding_member(wedding_id));

-- Fix other tables policies
DROP POLICY IF EXISTS "Couples can create guest groups" ON public.guest_groups;
DROP POLICY IF EXISTS "Couples can delete guest groups" ON public.guest_groups;
DROP POLICY IF EXISTS "Couples can update guest groups" ON public.guest_groups;
DROP POLICY IF EXISTS "Members can view guest groups" ON public.guest_groups;

CREATE POLICY "Couples can create guest groups" ON public.guest_groups FOR INSERT TO authenticated WITH CHECK (is_couple_in_wedding(wedding_id));
CREATE POLICY "Couples can delete guest groups" ON public.guest_groups FOR DELETE TO authenticated USING (is_couple_in_wedding(wedding_id));
CREATE POLICY "Couples can update guest groups" ON public.guest_groups FOR UPDATE TO authenticated USING (is_couple_in_wedding(wedding_id));
CREATE POLICY "Members can view guest groups" ON public.guest_groups FOR SELECT TO authenticated USING (is_wedding_member(wedding_id));

DROP POLICY IF EXISTS "Couples can add guests" ON public.guests;
DROP POLICY IF EXISTS "Couples can delete guests" ON public.guests;
DROP POLICY IF EXISTS "Couples and linked users can update guests" ON public.guests;
DROP POLICY IF EXISTS "Members can view guests" ON public.guests;

CREATE POLICY "Couples can add guests" ON public.guests FOR INSERT TO authenticated WITH CHECK (is_couple_in_wedding(wedding_id));
CREATE POLICY "Couples can delete guests" ON public.guests FOR DELETE TO authenticated USING (is_couple_in_wedding(wedding_id));
CREATE POLICY "Couples and linked users can update guests" ON public.guests FOR UPDATE TO authenticated USING (is_couple_in_wedding(wedding_id) OR user_id = auth.uid());
CREATE POLICY "Members can view guests" ON public.guests FOR SELECT TO authenticated USING (is_wedding_member(wedding_id));

DROP POLICY IF EXISTS "Couples can create tables" ON public.wedding_tables;
DROP POLICY IF EXISTS "Couples can delete tables" ON public.wedding_tables;
DROP POLICY IF EXISTS "Couples can update tables" ON public.wedding_tables;
DROP POLICY IF EXISTS "Members can view tables" ON public.wedding_tables;

CREATE POLICY "Couples can create tables" ON public.wedding_tables FOR INSERT TO authenticated WITH CHECK (is_couple_in_wedding(wedding_id));
CREATE POLICY "Couples can delete tables" ON public.wedding_tables FOR DELETE TO authenticated USING (is_couple_in_wedding(wedding_id));
CREATE POLICY "Couples can update tables" ON public.wedding_tables FOR UPDATE TO authenticated USING (is_couple_in_wedding(wedding_id));
CREATE POLICY "Members can view tables" ON public.wedding_tables FOR SELECT TO authenticated USING (is_wedding_member(wedding_id));

DROP POLICY IF EXISTS "Couples can create budget items" ON public.budget_items;
DROP POLICY IF EXISTS "Couples can delete budget items" ON public.budget_items;
DROP POLICY IF EXISTS "Couples can update budget items" ON public.budget_items;
DROP POLICY IF EXISTS "Only couples can view budget" ON public.budget_items;

CREATE POLICY "Couples can create budget items" ON public.budget_items FOR INSERT TO authenticated WITH CHECK (is_couple_in_wedding(wedding_id));
CREATE POLICY "Couples can delete budget items" ON public.budget_items FOR DELETE TO authenticated USING (is_couple_in_wedding(wedding_id));
CREATE POLICY "Couples can update budget items" ON public.budget_items FOR UPDATE TO authenticated USING (is_couple_in_wedding(wedding_id));
CREATE POLICY "Only couples can view budget" ON public.budget_items FOR SELECT TO authenticated USING (is_couple_in_wedding(wedding_id));

DROP POLICY IF EXISTS "Couples can create gifts" ON public.gifts;
DROP POLICY IF EXISTS "Couples can delete gifts" ON public.gifts;
DROP POLICY IF EXISTS "Couples can update gifts" ON public.gifts;
DROP POLICY IF EXISTS "Only couples can view gifts" ON public.gifts;

CREATE POLICY "Couples can create gifts" ON public.gifts FOR INSERT TO authenticated WITH CHECK (is_couple_in_wedding(wedding_id));
CREATE POLICY "Couples can delete gifts" ON public.gifts FOR DELETE TO authenticated USING (is_couple_in_wedding(wedding_id));
CREATE POLICY "Couples can update gifts" ON public.gifts FOR UPDATE TO authenticated USING (is_couple_in_wedding(wedding_id));
CREATE POLICY "Only couples can view gifts" ON public.gifts FOR SELECT TO authenticated USING (is_couple_in_wedding(wedding_id));

DROP POLICY IF EXISTS "Couples can create announcements" ON public.announcements;
DROP POLICY IF EXISTS "Couples can delete announcements" ON public.announcements;
DROP POLICY IF EXISTS "Couples can update announcements" ON public.announcements;
DROP POLICY IF EXISTS "Members can view announcements" ON public.announcements;

CREATE POLICY "Couples can create announcements" ON public.announcements FOR INSERT TO authenticated WITH CHECK (is_couple_in_wedding(wedding_id));
CREATE POLICY "Couples can delete announcements" ON public.announcements FOR DELETE TO authenticated USING (is_couple_in_wedding(wedding_id));
CREATE POLICY "Couples can update announcements" ON public.announcements FOR UPDATE TO authenticated USING (is_couple_in_wedding(wedding_id));
CREATE POLICY "Members can view announcements" ON public.announcements FOR SELECT TO authenticated USING (is_wedding_member(wedding_id));

DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;

CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT TO authenticated WITH CHECK (id = auth.uid());
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid());
CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT TO authenticated USING (id = auth.uid());