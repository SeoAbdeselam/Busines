-- Drop the existing INSERT policy for weddings
DROP POLICY IF EXISTS "Authenticated users can create weddings" ON public.weddings;

-- Create a simpler policy that just checks if user is authenticated
-- The created_by will be set by the application, but we'll verify it matches auth.uid() via a trigger
CREATE POLICY "Any authenticated user can create weddings" 
ON public.weddings 
FOR INSERT 
TO authenticated
WITH CHECK (true);  -- Allow any authenticated user to create

-- Add a trigger to enforce that created_by matches the current user
CREATE OR REPLACE FUNCTION public.enforce_created_by()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- If created_by is provided and doesn't match auth.uid(), reject
  IF NEW.created_by IS NOT NULL AND NEW.created_by != auth.uid() THEN
    RAISE EXCEPTION 'created_by must match the authenticated user';
  END IF;
  
  -- If created_by is null, set it to auth.uid()
  IF NEW.created_by IS NULL THEN
    NEW.created_by := auth.uid();
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger to enforce created_by before insert
DROP TRIGGER IF EXISTS enforce_wedding_created_by ON public.weddings;
CREATE TRIGGER enforce_wedding_created_by
BEFORE INSERT ON public.weddings
FOR EACH ROW
EXECUTE FUNCTION public.enforce_created_by();