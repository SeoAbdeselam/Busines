-- Remove the enforce_created_by trigger since RLS policy does the same check
DROP TRIGGER IF EXISTS enforce_wedding_created_by ON public.weddings;