-- Enum para categorías de profesionales
CREATE TYPE public.professional_category AS ENUM (
  'photography',
  'video',
  'florist',
  'catering',
  'dj_music',
  'dresses',
  'transport',
  'pastry',
  'jewelry',
  'venues',
  'wedding_planner',
  'makeup_hair',
  'decoration',
  'invitations',
  'other'
);

-- Enum para planes de suscripción
CREATE TYPE public.subscription_plan AS ENUM (
  'free',
  'premium'
);

-- Enum para estado de suscripción
CREATE TYPE public.subscription_status AS ENUM (
  'active',
  'expired',
  'cancelled'
);

-- Enum para estado de contratación
CREATE TYPE public.contract_status AS ENUM (
  'interested',
  'contacted',
  'contracted',
  'completed',
  'cancelled'
);

-- Tabla de profesionales (perfil principal)
CREATE TABLE public.professionals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  business_name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  story TEXT,
  primary_category professional_category NOT NULL,
  secondary_categories professional_category[] DEFAULT '{}',
  location TEXT,
  city TEXT,
  province TEXT,
  phone TEXT,
  email TEXT,
  website TEXT,
  instagram TEXT,
  tiktok TEXT,
  facebook TEXT,
  youtube TEXT,
  logo_url TEXT,
  cover_image_url TEXT,
  is_verified BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  average_rating NUMERIC(3,2) DEFAULT 0,
  total_reviews INTEGER DEFAULT 0,
  total_contracts INTEGER DEFAULT 0,
  views_count INTEGER DEFAULT 0,
  contacts_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabla de suscripciones
CREATE TABLE public.professional_subscriptions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID NOT NULL REFERENCES public.professionals(id) ON DELETE CASCADE,
  plan subscription_plan NOT NULL DEFAULT 'free',
  status subscription_status NOT NULL DEFAULT 'active',
  started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE,
  payment_method TEXT,
  payment_reference TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Galería de profesionales
CREATE TABLE public.professional_gallery (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID NOT NULL REFERENCES public.professionals(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('image', 'video')),
  url TEXT NOT NULL,
  thumbnail_url TEXT,
  title TEXT,
  description TEXT,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Sistema de mensajería profesional-cliente
CREATE TABLE public.professional_conversations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID NOT NULL REFERENCES public.professionals(id) ON DELETE CASCADE,
  wedding_id UUID NOT NULL REFERENCES public.weddings(id) ON DELETE CASCADE,
  client_user_id UUID NOT NULL,
  last_message_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  professional_unread INTEGER DEFAULT 0,
  client_unread INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(professional_id, wedding_id)
);

CREATE TABLE public.professional_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  conversation_id UUID NOT NULL REFERENCES public.professional_conversations(id) ON DELETE CASCADE,
  sender_type TEXT NOT NULL CHECK (sender_type IN ('client', 'professional')),
  sender_id UUID NOT NULL,
  content TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Contrataciones de profesionales
CREATE TABLE public.professional_contracts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID NOT NULL REFERENCES public.professionals(id) ON DELETE CASCADE,
  wedding_id UUID NOT NULL REFERENCES public.weddings(id) ON DELETE CASCADE,
  client_user_id UUID NOT NULL,
  status contract_status NOT NULL DEFAULT 'interested',
  service_description TEXT,
  estimated_cost NUMERIC DEFAULT 0,
  actual_cost NUMERIC,
  deposit_amount NUMERIC,
  deposit_paid BOOLEAN DEFAULT FALSE,
  service_date DATE,
  notes TEXT,
  task_id UUID REFERENCES public.tasks(id) ON DELETE SET NULL,
  budget_item_id UUID REFERENCES public.budget_items(id) ON DELETE SET NULL,
  contracted_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(professional_id, wedding_id)
);

-- Reseñas verificadas
CREATE TABLE public.professional_reviews (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID NOT NULL REFERENCES public.professionals(id) ON DELETE CASCADE,
  contract_id UUID NOT NULL REFERENCES public.professional_contracts(id) ON DELETE CASCADE UNIQUE,
  wedding_id UUID NOT NULL REFERENCES public.weddings(id) ON DELETE CASCADE,
  reviewer_user_id UUID NOT NULL,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  title TEXT,
  content TEXT,
  response TEXT,
  response_at TIMESTAMP WITH TIME ZONE,
  is_verified BOOLEAN DEFAULT TRUE,
  is_published BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Triggers para updated_at
CREATE TRIGGER update_professionals_updated_at
  BEFORE UPDATE ON public.professionals
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_professional_subscriptions_updated_at
  BEFORE UPDATE ON public.professional_subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_professional_contracts_updated_at
  BEFORE UPDATE ON public.professional_contracts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_professional_reviews_updated_at
  BEFORE UPDATE ON public.professional_reviews
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at();

-- Índices para búsqueda y rendimiento
CREATE INDEX idx_professionals_category ON public.professionals(primary_category);
CREATE INDEX idx_professionals_city ON public.professionals(city);
CREATE INDEX idx_professionals_slug ON public.professionals(slug);
CREATE INDEX idx_professionals_active ON public.professionals(is_active) WHERE is_active = true;
CREATE INDEX idx_professional_gallery_professional ON public.professional_gallery(professional_id);
CREATE INDEX idx_professional_contracts_wedding ON public.professional_contracts(wedding_id);
CREATE INDEX idx_professional_contracts_professional ON public.professional_contracts(professional_id);
CREATE INDEX idx_professional_reviews_professional ON public.professional_reviews(professional_id);
CREATE INDEX idx_professional_messages_conversation ON public.professional_messages(conversation_id);

-- Enable RLS
ALTER TABLE public.professionals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.professional_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.professional_gallery ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.professional_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.professional_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.professional_contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.professional_reviews ENABLE ROW LEVEL SECURITY;

-- Función helper para verificar si es profesional
CREATE OR REPLACE FUNCTION public.is_professional(p_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.professionals
    WHERE user_id = p_user_id
  );
$$;

-- Función helper para verificar si profesional tiene plan premium
CREATE OR REPLACE FUNCTION public.professional_has_premium(p_professional_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.professional_subscriptions
    WHERE professional_id = p_professional_id
    AND plan = 'premium'
    AND status = 'active'
    AND (expires_at IS NULL OR expires_at > now())
  );
$$;

-- Función para obtener ID del profesional por user_id
CREATE OR REPLACE FUNCTION public.get_professional_id(p_user_id uuid)
RETURNS uuid
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id FROM public.professionals WHERE user_id = p_user_id LIMIT 1;
$$;

-- RLS Policies para professionals
-- Perfiles públicos visibles para todos (activos)
CREATE POLICY "Public profiles are viewable"
ON public.professionals FOR SELECT
USING (is_active = true);

-- Profesional puede ver su propio perfil aunque esté inactivo
CREATE POLICY "Professionals can view own profile"
ON public.professionals FOR SELECT
USING (user_id = auth.uid());

-- Profesional puede actualizar su perfil
CREATE POLICY "Professionals can update own profile"
ON public.professionals FOR UPDATE
USING (user_id = auth.uid());

-- Profesional puede crear su perfil
CREATE POLICY "Users can create professional profile"
ON public.professionals FOR INSERT
WITH CHECK (user_id = auth.uid());

-- RLS para suscripciones
CREATE POLICY "Professionals can view own subscriptions"
ON public.professional_subscriptions FOR SELECT
USING (professional_id = get_professional_id(auth.uid()));

CREATE POLICY "Professionals can manage own subscriptions"
ON public.professional_subscriptions FOR INSERT
WITH CHECK (professional_id = get_professional_id(auth.uid()));

CREATE POLICY "Professionals can update own subscriptions"
ON public.professional_subscriptions FOR UPDATE
USING (professional_id = get_professional_id(auth.uid()));

-- RLS para galería
CREATE POLICY "Gallery items are public"
ON public.professional_gallery FOR SELECT
USING (true);

CREATE POLICY "Professionals can manage own gallery"
ON public.professional_gallery FOR INSERT
WITH CHECK (professional_id = get_professional_id(auth.uid()));

CREATE POLICY "Professionals can update own gallery"
ON public.professional_gallery FOR UPDATE
USING (professional_id = get_professional_id(auth.uid()));

CREATE POLICY "Professionals can delete own gallery"
ON public.professional_gallery FOR DELETE
USING (professional_id = get_professional_id(auth.uid()));

-- RLS para conversaciones
CREATE POLICY "Participants can view conversations"
ON public.professional_conversations FOR SELECT
USING (
  client_user_id = auth.uid() 
  OR professional_id = get_professional_id(auth.uid())
);

CREATE POLICY "Clients can start conversations"
ON public.professional_conversations FOR INSERT
WITH CHECK (client_user_id = auth.uid());

CREATE POLICY "Participants can update conversations"
ON public.professional_conversations FOR UPDATE
USING (
  client_user_id = auth.uid() 
  OR professional_id = get_professional_id(auth.uid())
);

-- RLS para mensajes
CREATE POLICY "Conversation participants can view messages"
ON public.professional_messages FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.professional_conversations c
    WHERE c.id = conversation_id
    AND (c.client_user_id = auth.uid() OR c.professional_id = get_professional_id(auth.uid()))
  )
);

CREATE POLICY "Participants can send messages"
ON public.professional_messages FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.professional_conversations c
    WHERE c.id = conversation_id
    AND (c.client_user_id = auth.uid() OR c.professional_id = get_professional_id(auth.uid()))
  )
);

CREATE POLICY "Participants can mark messages read"
ON public.professional_messages FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM public.professional_conversations c
    WHERE c.id = conversation_id
    AND (c.client_user_id = auth.uid() OR c.professional_id = get_professional_id(auth.uid()))
  )
);

-- RLS para contratos
CREATE POLICY "Participants can view contracts"
ON public.professional_contracts FOR SELECT
USING (
  client_user_id = auth.uid() 
  OR professional_id = get_professional_id(auth.uid())
);

CREATE POLICY "Clients can create contracts"
ON public.professional_contracts FOR INSERT
WITH CHECK (client_user_id = auth.uid());

CREATE POLICY "Participants can update contracts"
ON public.professional_contracts FOR UPDATE
USING (
  client_user_id = auth.uid() 
  OR professional_id = get_professional_id(auth.uid())
);

-- RLS para reseñas
CREATE POLICY "Published reviews are public"
ON public.professional_reviews FOR SELECT
USING (is_published = true);

CREATE POLICY "Contract owners can create reviews"
ON public.professional_reviews FOR INSERT
WITH CHECK (
  reviewer_user_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM public.professional_contracts c
    WHERE c.id = contract_id
    AND c.client_user_id = auth.uid()
    AND c.status = 'completed'
  )
);

CREATE POLICY "Reviewers can update own reviews"
ON public.professional_reviews FOR UPDATE
USING (reviewer_user_id = auth.uid());

CREATE POLICY "Professionals can respond to reviews"
ON public.professional_reviews FOR UPDATE
USING (professional_id = get_professional_id(auth.uid()));

-- Permisos para roles
GRANT SELECT ON public.professionals TO anon;
GRANT SELECT ON public.professional_gallery TO anon;
GRANT SELECT ON public.professional_reviews TO anon;

GRANT ALL ON public.professionals TO authenticated;
GRANT ALL ON public.professional_subscriptions TO authenticated;
GRANT ALL ON public.professional_gallery TO authenticated;
GRANT ALL ON public.professional_conversations TO authenticated;
GRANT ALL ON public.professional_messages TO authenticated;
GRANT ALL ON public.professional_contracts TO authenticated;
GRANT ALL ON public.professional_reviews TO authenticated;