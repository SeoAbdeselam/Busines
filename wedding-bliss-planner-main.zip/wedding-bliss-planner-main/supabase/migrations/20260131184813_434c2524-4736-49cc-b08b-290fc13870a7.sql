-- Force GRANT permissions again
GRANT SELECT, INSERT, UPDATE, DELETE ON public.weddings TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.wedding_memberships TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.guests TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.guest_groups TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.wedding_tables TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.budget_items TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.gifts TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.announcements TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT SELECT ON public.weddings TO anon;

-- Verify and ensure triggers exist
DROP TRIGGER IF EXISTS enforce_wedding_created_by ON public.weddings;
CREATE TRIGGER enforce_wedding_created_by
BEFORE INSERT ON public.weddings
FOR EACH ROW
EXECUTE FUNCTION public.enforce_created_by();

DROP TRIGGER IF EXISTS on_wedding_created ON public.weddings;
CREATE TRIGGER on_wedding_created
AFTER INSERT ON public.weddings
FOR EACH ROW
EXECUTE FUNCTION public.handle_new_wedding();