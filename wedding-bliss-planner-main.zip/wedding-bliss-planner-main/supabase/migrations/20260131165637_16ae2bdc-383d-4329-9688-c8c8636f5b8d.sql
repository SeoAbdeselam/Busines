-- The issue is that the trigger handle_new_wedding runs with SECURITY DEFINER
-- but when it tries to insert into wedding_memberships, the RLS policy checks
-- auth.uid() which is null in the trigger context (or different from created_by).
-- 
-- Solution: Allow the trigger to bypass RLS by granting it proper context
-- OR by making the wedding_memberships INSERT policy more permissive for 
-- the trigger's use case.

-- First, let's update the wedding_memberships INSERT policy to handle the 
-- trigger case. The trigger inserts with user_id = created_by of the wedding.
-- We need to allow this when it comes from the trigger.

-- Drop the existing policy
DROP POLICY IF EXISTS "Couples can add members" ON public.wedding_memberships;

-- Create a new, simpler policy that allows:
-- 1. Couples to add members to their weddings
-- 2. Users to add themselves as members (for guest access flow)
-- 3. The trigger to insert the initial couple membership
CREATE POLICY "Members can be added" 
ON public.wedding_memberships 
FOR INSERT 
TO authenticated
WITH CHECK (
  -- Allow if user is adding themselves
  user_id = auth.uid()
  OR
  -- Allow if user is already a couple in this wedding (adding other members)
  is_couple_in_wedding(wedding_id)
);

-- Now the issue is the trigger runs as postgres (via SECURITY DEFINER)
-- but RLS is only applied to authenticated role.
-- The trigger should work because it has SECURITY DEFINER which bypasses RLS.
-- 
-- Let's verify the trigger can insert by checking if it's the trigger that's failing
-- Actually, looking at the error, it says "weddings" table, not wedding_memberships.
-- So the issue might be something else...

-- Let's check if there's an issue with the weddings foreign key constraint
-- The created_by column references profiles(id) which requires the profile to exist

-- Also let's add a policy that allows the trigger to work:
-- We need to make sure wedding_memberships can be inserted from triggers
GRANT ALL ON public.wedding_memberships TO postgres;