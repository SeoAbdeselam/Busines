-- Fix the overly permissive INSERT policy on weddings
-- Replace WITH CHECK (true) with proper validation

DROP POLICY IF EXISTS "Authenticated users can create weddings" ON public.weddings;

-- Create a proper INSERT policy that validates the user is setting themselves as creator
CREATE POLICY "Authenticated users can create weddings" 
ON public.weddings 
FOR INSERT 
TO authenticated
WITH CHECK (created_by = auth.uid());