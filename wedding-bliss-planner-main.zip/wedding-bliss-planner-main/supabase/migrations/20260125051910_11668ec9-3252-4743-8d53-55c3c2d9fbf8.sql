-- =============================================
-- LOBA BALL - WEDDING PLANNING SAAS
-- Multi-tenant architecture with strict isolation
-- =============================================

-- 1. Create role enum for wedding memberships
CREATE TYPE public.wedding_role AS ENUM ('couple', 'guest');

-- 2. Create RSVP status enum
CREATE TYPE public.rsvp_status AS ENUM ('pending', 'confirmed', 'declined');

-- =============================================
-- BASE TABLES
-- =============================================

-- Profiles table (linked to auth.users)
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  phone TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Weddings table (main tenant entity)
CREATE TABLE public.weddings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  wedding_date DATE,
  location TEXT,
  cover_image_url TEXT,
  primary_color TEXT DEFAULT '#C4A35A',
  secondary_color TEXT DEFAULT '#E8D4D4',
  wedding_code TEXT NOT NULL UNIQUE,
  created_by UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Wedding memberships (role per wedding - NOT global)
CREATE TABLE public.wedding_memberships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  wedding_id UUID NOT NULL REFERENCES public.weddings(id) ON DELETE CASCADE,
  role wedding_role NOT NULL DEFAULT 'guest',
  invited_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, wedding_id)
);

-- Guest groups (family, friends, work, etc.)
CREATE TABLE public.guest_groups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL REFERENCES public.weddings(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Tables for seating arrangement
CREATE TABLE public.wedding_tables (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL REFERENCES public.weddings(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  capacity INTEGER NOT NULL DEFAULT 8,
  position_x REAL,
  position_y REAL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Guests (can be linked to a user or standalone)
CREATE TABLE public.guests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL REFERENCES public.weddings(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  guest_group_id UUID REFERENCES public.guest_groups(id) ON DELETE SET NULL,
  table_id UUID REFERENCES public.wedding_tables(id) ON DELETE SET NULL,
  linked_guest_id UUID REFERENCES public.guests(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  rsvp_status rsvp_status NOT NULL DEFAULT 'pending',
  plus_ones INTEGER NOT NULL DEFAULT 0,
  dietary_notes TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Budget items (PRIVATE - only for couple)
CREATE TABLE public.budget_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL REFERENCES public.weddings(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  name TEXT NOT NULL,
  estimated_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  actual_amount DECIMAL(10,2) DEFAULT 0,
  is_paid BOOLEAN NOT NULL DEFAULT false,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Gifts (PRIVATE - only for couple)
CREATE TABLE public.gifts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL REFERENCES public.weddings(id) ON DELETE CASCADE,
  guest_id UUID REFERENCES public.guests(id) ON DELETE SET NULL,
  guest_group_id UUID REFERENCES public.guest_groups(id) ON DELETE SET NULL,
  description TEXT,
  amount DECIMAL(10,2),
  is_monetary BOOLEAN NOT NULL DEFAULT true,
  received_at DATE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Announcements (couple -> guests communication)
CREATE TABLE public.announcements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wedding_id UUID NOT NULL REFERENCES public.weddings(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  is_global BOOLEAN NOT NULL DEFAULT true,
  target_group_id UUID REFERENCES public.guest_groups(id) ON DELETE SET NULL,
  created_by UUID NOT NULL REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =============================================
-- HELPER FUNCTIONS (SECURITY DEFINER)
-- =============================================

-- Check if user is a member of a wedding
CREATE OR REPLACE FUNCTION public.is_wedding_member(p_wedding_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.wedding_memberships
    WHERE user_id = auth.uid() AND wedding_id = p_wedding_id
  );
$$;

-- Check if user is a couple (admin) in a wedding
CREATE OR REPLACE FUNCTION public.is_couple_in_wedding(p_wedding_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.wedding_memberships
    WHERE user_id = auth.uid() AND wedding_id = p_wedding_id AND role = 'couple'
  );
$$;

-- Check if user is the creator/owner of a wedding
CREATE OR REPLACE FUNCTION public.is_wedding_owner(p_wedding_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.weddings
    WHERE id = p_wedding_id AND created_by = auth.uid()
  );
$$;

-- Get wedding ID by code (for guest login)
CREATE OR REPLACE FUNCTION public.get_wedding_by_code(p_code TEXT)
RETURNS UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id FROM public.weddings WHERE wedding_code = UPPER(p_code);
$$;

-- =============================================
-- ENABLE ROW LEVEL SECURITY
-- =============================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.weddings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wedding_memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.guest_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wedding_tables ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.guests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.budget_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

-- =============================================
-- RLS POLICIES - PROFILES
-- =============================================

CREATE POLICY "Users can view own profile"
  ON public.profiles FOR SELECT
  USING (id = auth.uid());

CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (id = auth.uid());

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (id = auth.uid());

-- =============================================
-- RLS POLICIES - WEDDINGS
-- =============================================

CREATE POLICY "Members can view their weddings"
  ON public.weddings FOR SELECT
  USING (public.is_wedding_member(id));

CREATE POLICY "Authenticated users can create weddings"
  ON public.weddings FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL AND created_by = auth.uid());

CREATE POLICY "Couples can update their weddings"
  ON public.weddings FOR UPDATE
  USING (public.is_couple_in_wedding(id));

CREATE POLICY "Owner can delete wedding"
  ON public.weddings FOR DELETE
  USING (public.is_wedding_owner(id));

-- =============================================
-- RLS POLICIES - WEDDING MEMBERSHIPS
-- =============================================

CREATE POLICY "Members can view memberships in their weddings"
  ON public.wedding_memberships FOR SELECT
  USING (public.is_wedding_member(wedding_id));

CREATE POLICY "Couples can add members"
  ON public.wedding_memberships FOR INSERT
  WITH CHECK (public.is_couple_in_wedding(wedding_id) OR (auth.uid() IS NOT NULL AND user_id = auth.uid()));

CREATE POLICY "Couples can update memberships"
  ON public.wedding_memberships FOR UPDATE
  USING (public.is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can remove members"
  ON public.wedding_memberships FOR DELETE
  USING (public.is_couple_in_wedding(wedding_id) OR user_id = auth.uid());

-- =============================================
-- RLS POLICIES - GUEST GROUPS
-- =============================================

CREATE POLICY "Members can view guest groups"
  ON public.guest_groups FOR SELECT
  USING (public.is_wedding_member(wedding_id));

CREATE POLICY "Couples can create guest groups"
  ON public.guest_groups FOR INSERT
  WITH CHECK (public.is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can update guest groups"
  ON public.guest_groups FOR UPDATE
  USING (public.is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can delete guest groups"
  ON public.guest_groups FOR DELETE
  USING (public.is_couple_in_wedding(wedding_id));

-- =============================================
-- RLS POLICIES - WEDDING TABLES
-- =============================================

CREATE POLICY "Members can view tables"
  ON public.wedding_tables FOR SELECT
  USING (public.is_wedding_member(wedding_id));

CREATE POLICY "Couples can create tables"
  ON public.wedding_tables FOR INSERT
  WITH CHECK (public.is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can update tables"
  ON public.wedding_tables FOR UPDATE
  USING (public.is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can delete tables"
  ON public.wedding_tables FOR DELETE
  USING (public.is_couple_in_wedding(wedding_id));

-- =============================================
-- RLS POLICIES - GUESTS
-- =============================================

CREATE POLICY "Members can view guests"
  ON public.guests FOR SELECT
  USING (public.is_wedding_member(wedding_id));

CREATE POLICY "Couples can add guests"
  ON public.guests FOR INSERT
  WITH CHECK (public.is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples and linked users can update guests"
  ON public.guests FOR UPDATE
  USING (public.is_couple_in_wedding(wedding_id) OR user_id = auth.uid());

CREATE POLICY "Couples can delete guests"
  ON public.guests FOR DELETE
  USING (public.is_couple_in_wedding(wedding_id));

-- =============================================
-- RLS POLICIES - BUDGET ITEMS (PRIVATE - COUPLES ONLY)
-- =============================================

CREATE POLICY "Only couples can view budget"
  ON public.budget_items FOR SELECT
  USING (public.is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can create budget items"
  ON public.budget_items FOR INSERT
  WITH CHECK (public.is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can update budget items"
  ON public.budget_items FOR UPDATE
  USING (public.is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can delete budget items"
  ON public.budget_items FOR DELETE
  USING (public.is_couple_in_wedding(wedding_id));

-- =============================================
-- RLS POLICIES - GIFTS (PRIVATE - COUPLES ONLY)
-- =============================================

CREATE POLICY "Only couples can view gifts"
  ON public.gifts FOR SELECT
  USING (public.is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can create gifts"
  ON public.gifts FOR INSERT
  WITH CHECK (public.is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can update gifts"
  ON public.gifts FOR UPDATE
  USING (public.is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can delete gifts"
  ON public.gifts FOR DELETE
  USING (public.is_couple_in_wedding(wedding_id));

-- =============================================
-- RLS POLICIES - ANNOUNCEMENTS
-- =============================================

CREATE POLICY "Members can view announcements"
  ON public.announcements FOR SELECT
  USING (public.is_wedding_member(wedding_id));

CREATE POLICY "Couples can create announcements"
  ON public.announcements FOR INSERT
  WITH CHECK (public.is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can update announcements"
  ON public.announcements FOR UPDATE
  USING (public.is_couple_in_wedding(wedding_id));

CREATE POLICY "Couples can delete announcements"
  ON public.announcements FOR DELETE
  USING (public.is_couple_in_wedding(wedding_id));

-- =============================================
-- TRIGGERS
-- =============================================

-- Auto-create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name');
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Auto-add creator as couple when wedding is created
CREATE OR REPLACE FUNCTION public.handle_new_wedding()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.wedding_memberships (user_id, wedding_id, role)
  VALUES (NEW.created_by, NEW.id, 'couple');
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_wedding_created
  AFTER INSERT ON public.weddings
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_wedding();

-- Update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_weddings_updated_at BEFORE UPDATE ON public.weddings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_guest_groups_updated_at BEFORE UPDATE ON public.guest_groups
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_wedding_tables_updated_at BEFORE UPDATE ON public.wedding_tables
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_guests_updated_at BEFORE UPDATE ON public.guests
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_budget_items_updated_at BEFORE UPDATE ON public.budget_items
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_gifts_updated_at BEFORE UPDATE ON public.gifts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_announcements_updated_at BEFORE UPDATE ON public.announcements
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- =============================================
-- INDEXES FOR PERFORMANCE
-- =============================================

CREATE INDEX idx_wedding_memberships_user ON public.wedding_memberships(user_id);
CREATE INDEX idx_wedding_memberships_wedding ON public.wedding_memberships(wedding_id);
CREATE INDEX idx_guests_wedding ON public.guests(wedding_id);
CREATE INDEX idx_guests_group ON public.guests(guest_group_id);
CREATE INDEX idx_guests_table ON public.guests(table_id);
CREATE INDEX idx_guests_user ON public.guests(user_id);
CREATE INDEX idx_budget_items_wedding ON public.budget_items(wedding_id);
CREATE INDEX idx_gifts_wedding ON public.gifts(wedding_id);
CREATE INDEX idx_announcements_wedding ON public.announcements(wedding_id);
CREATE INDEX idx_weddings_code ON public.weddings(wedding_code);