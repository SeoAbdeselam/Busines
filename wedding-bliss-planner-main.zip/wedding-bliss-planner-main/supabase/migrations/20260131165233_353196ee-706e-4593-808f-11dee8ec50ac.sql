-- Grant permissions on all tables to authenticated users
GRANT SELECT, INSERT, UPDATE, DELETE ON public.weddings TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.wedding_memberships TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.guests TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.guest_groups TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.wedding_tables TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.budget_items TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.gifts TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.announcements TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;

-- Grant anon select for specific public data if needed
GRANT SELECT ON public.weddings TO anon;