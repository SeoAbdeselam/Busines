-- Enable RLS on task_templates (read-only public templates)
ALTER TABLE public.task_templates ENABLE ROW LEVEL SECURITY;

-- Anyone authenticated can read templates
CREATE POLICY "Authenticated users can view templates" 
ON public.task_templates FOR SELECT 
TO authenticated
USING (true);